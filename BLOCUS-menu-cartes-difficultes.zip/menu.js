/* BLOCUS screen navigation. Event delegation survives return-to-menu DOM restoration. */
(() => {
  const overlay = document.getElementById('overlay');
  if (!overlay) return;
  const home = () => document.getElementById('menu-home-view');
  const online = () => document.getElementById('online-menu-view');
  const title = () => document.getElementById('menu-title-screen');
  const options = () => document.getElementById('menu-options-screen');
  const ranking = () => document.getElementById('menu-ranking-screen');
  let returnScreen = 'title';
  function hideScreens() {
    [title(), home(), online(), options(), ranking()].forEach(el => { if (el) el.hidden = true; });
    overlay.classList.remove('menu-preparing');
  }
  function show(screen) {
    hideScreens();
    if (screen === 'title') { title().hidden = false; }
    else if (screen === 'prepare') { home().hidden = false; overlay.classList.add('menu-preparing'); }
    else if (screen === 'online') { returnScreen = 'prepare'; online().hidden = false; }
    else if (screen === 'options') { returnScreen = 'title'; options().hidden = false; }
    else if (screen === 'ranking') { returnScreen = 'title'; ranking().hidden = false; refreshRanking(); }
    const first = overlay.querySelector(`#${({title:'menu-title-screen',prepare:'menu-home-view',online:'online-menu-view',options:'menu-options-screen',ranking:'menu-ranking-screen'})[screen]} button:not([disabled])`);
    first?.focus({preventScroll:true});
  }
  function refreshRanking() {
    const src = document.getElementById('local-ranking-list');
    const dest = document.getElementById('menu-ranking-list');
    if (src && dest) dest.innerHTML = src.innerHTML || '<p class="ranking-empty">Aucune partie enregistrée pour le moment.</p>';
  }
  document.addEventListener('click', event => {
    const action = event.target.closest('[data-title-action]');
    if (action) {
      const kind = action.dataset.titleAction;
      if (kind === 'play') show('prepare');
      if (kind === 'tutorial') {
        show('prepare');
        const tutorial = document.querySelector('#menu-home-view [data-mode="tutorial"]');
        tutorial?.click();
        document.getElementById('start')?.click();
      }
      if (kind === 'options') show('options');
      if (kind === 'ranking') show('ranking');
      return;
    }
    if (event.target.closest('[data-secondary-back]')) { show(returnScreen); return; }
    if (event.target.closest('#open-online-menu')) { returnScreen = 'prepare'; show('online'); return; }
    if (event.target.closest('#close-online-menu')) { show(returnScreen); return; }
  });
  document.addEventListener('keydown', event => {
    if (event.code !== 'Escape') return;
    if (online() && !online().hidden) { event.preventDefault(); show(returnScreen); }
    else if (options() && !options().hidden || ranking() && !ranking().hidden) { event.preventDefault(); show('title'); }
    else if (home() && !home().hidden) { event.preventDefault(); show('title'); }
  }, true);
  document.getElementById('menu-fullscreen')?.addEventListener('change', async event => {
    try { if (event.target.checked) await document.documentElement.requestFullscreen(); else if (document.fullscreenElement) await document.exitFullscreen(); }
    catch { event.target.checked = Boolean(document.fullscreenElement); }
  });
  document.getElementById('menu-reduced-motion')?.addEventListener('change', event => document.documentElement.classList.toggle('reduced-motion', event.target.checked));
  document.getElementById('menu-text-size')?.addEventListener('input', event => document.documentElement.style.setProperty('--menu-text-size', `${event.target.value}px`));
  document.getElementById('menu-muted')?.addEventListener('change', event => { document.documentElement.dataset.menuMuted = String(event.target.checked); });
  document.getElementById('menu-music-volume')?.addEventListener('input', event => { document.documentElement.dataset.menuMusicVolume = event.target.value; });
  document.getElementById('menu-sfx-volume')?.addEventListener('input', event => { document.documentElement.dataset.menuSfxVolume = event.target.value; });
  // The game restores overlay contents after a match; return to the title without replacing listeners.
  const observer = new MutationObserver(() => {
    if (overlay && !overlay.classList.contains('hidden') && !document.getElementById('menu-title-screen')) return;
    if (overlay && !overlay.classList.contains('hidden') && title() && home() && !overlay.dataset.menuInitialized) {
      overlay.dataset.menuInitialized = '1'; show('title');
    }
  });
  observer.observe(overlay, {childList:true,subtree:false});
  // Restore initial title on load and preserve game menu after a return from gameplay.
  show('title');
})();
