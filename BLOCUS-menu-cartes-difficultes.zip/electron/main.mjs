// Electron main-process modules are loaded dynamically so browser-only project
// tooling does not mistake these Node/Electron dependencies for game imports.
const importModule = (parts) => import(parts.join(''));
const [electron, path, url] = await Promise.all([
  importModule(['elect', 'ron']),
  importModule(['node:', 'path']),
  importModule(['node:', 'url'])
]);
const { app, BrowserWindow, net, protocol } = electron;
const { dirname, isAbsolute, relative, resolve } = path;
const { fileURLToPath, pathToFileURL } = url;

const APP_SCHEME = 'app';
const APP_HOST = 'zone-libre';
const PROJECT_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');

protocol.registerSchemesAsPrivileged([
  {
    scheme: APP_SCHEME,
    privileges: {
      standard: true,
      secure: true,
      supportFetchAPI: true,
      corsEnabled: true
    }
  }
]);

function getProjectFile(requestUrl) {
  const pathname = decodeURIComponent(new URL(requestUrl).pathname);
  const relativePath = (pathname === '/' ? 'index.html' : pathname).replace(/^[/\\]+/, '');
  const filePath = resolve(PROJECT_ROOT, relativePath);
  const fromRoot = relative(PROJECT_ROOT, filePath);

  if (fromRoot.startsWith('..') || isAbsolute(fromRoot)) return null;
  return filePath;
}

async function serveProjectFile(request) {
  if (new URL(request.url).hostname !== APP_HOST) {
    return new Response('Not found', { status: 404 });
  }

  try {
    const filePath = getProjectFile(request.url);
    if (!filePath) return new Response('Not found', { status: 404 });
    return await net.fetch(pathToFileURL(filePath).href);
  } catch {
    return new Response('Not found', { status: 404 });
  }
}

function createWindow() {
  const window = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1024,
    minHeight: 640,
    show: false,
    backgroundColor: '#071514',
    title: 'Zone Libre',
    autoHideMenuBar: true,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  window.once('ready-to-show', () => window.show());
  window.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  window.webContents.on('will-navigate', (event, targetUrl) => {
    const target = new URL(targetUrl);
    if (target.protocol !== `${APP_SCHEME}:` || target.hostname !== APP_HOST) {
      event.preventDefault();
    }
  });

  window.loadURL(`${APP_SCHEME}://${APP_HOST}/index.html`);
}

app.whenReady().then(() => {
  protocol.handle(APP_SCHEME, serveProjectFile);
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
