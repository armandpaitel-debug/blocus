const canvas = document.querySelector('#game');
const ctx = canvas.getContext('2d', { alpha: false });
// Désactiver le lissage = drawImage nettement plus rapide (surtout foules + sol).
ctx.imageSmoothingEnabled = false;
const W = 1920;
const H = 1080;
const WORLD_W_CAMP = 5200;
const WORLD_H_CAMP = 3200;
const WORLD_W_SQUAT = 7600;
const WORLD_H_SQUAT = 7000;
// Dynamique : taille camp par défaut, agrandi seulement en mode squat
let WORLD_W = WORLD_W_CAMP;
let WORLD_H = WORLD_H_CAMP;
const CAMP_X = 2600;
const CAMP_Y = 1600;
const MAX_WAVES = 30;
const MAX_PLAYERS = 4;
const REINFORCEMENT_WAVES = new Set([5, 10, 15, 20, 30]);
const TEMPORARY_WEAPON_DURATION = 30;
const WEAPON_DROP_LIFETIME = 32;
const LOOT_DROP_LIFETIME = 24;
const PLAYER_BUFF_DURATION = 10;
const INVULN_DROP_DURATION = 5;
const LOOT_DROP_CHANCE = 0.12;
const WATER_CANNON_SPLASH_RADIUS = 270;
const F4_GRENADE_FUSE = 3;
const F4_GRENADE_RADIUS = 185;
const POLICE_COUNT_MULTIPLIER = 1; // 2× moins de flics de manière générale
/** Multi × joueurs : 1j→×1, 2j→×2, 3j→×3, 4j→×4 (en plus du multiplicateur de base). */
function getPolicePlayerScale() {
    // Seuls J1 et les joueurs encore reliés à une manette comptent pour l'équilibrage.
    const players = state?.players || [];
    return Math.max(1, players.filter((player) => player.id === 0 || (player.gamepad && !player.eliminated)).length);
}
function getDifficultyPoliceMult() {
    const d = state?.difficulty || 'normal';
    if (d === 'easy') return 0.75;
    if (d === 'hard') return 1.25;
    return 1;
}
function getPoliceScale() {
    return POLICE_COUNT_MULTIPLIER * getPolicePlayerScale() * getDifficultyPoliceMult();
}
const ENEMY_HP_MULTIPLIER = 0.5;
const PREPARATION_DURATION = 60;
const MOVEMENT_SPEED_MULTIPLIER = 1.5;
// Optimisation grandes foules : le déplacement reste fluide, mais les décisions IA
// et les relations entre unités ne sont pas recalculées 60 fois/seconde.
const ENEMY_AI_INTERVAL = 0.16;
const ENEMY_SUPPORT_INTERVAL = 0.70;
let enemyAiCursor = 0;
const ENEMY_DRAW_MARGIN = 100;
const CROWD_AI_BUDGET = 32;
// Au-delà de ce seuil on allège ombres / barres de vie, mais les sprites restent toujours.
const CROWD_LIGHT_FX_LIMIT = 40;
const MAX_PARTICLES = 40;
const MAX_BLOOD_STAINS = 20;
const MAX_FLOATERS = 16;
const LYCEE_ASSAULT_ROADS = [1010, 2697, 4180];
const LYCEE_ROUTE_CLEAR_Y = 1635;
const ENEMY_TARGET_RANGES = { player: 420, ally: 360, shack: 430, barricade: 520 };
const BARRICADE_BLOCKING_ENEMIES = new Set(['officer', 'flashball', 'canine', 'shield_crs', 'water_cannon', 'quad', 'moto']);
const SPECIAL_ENEMY_LABELS = {
    shield_crs: 'CRS BOUCLIER',
    flashball: 'BRIGADE FLASHBALL',
    water_cannon: 'CAMION LANCE-EAU',
    infiltrator: 'AGENT INFILTRÉ',
    bac: 'BAC EN CIVIL',
    canine: 'BRIGADE CANINE',
    dog: 'CHIEN POLICIER',
    moto: 'BRAV-M',
    quad: 'FLIC EN QUAD',
    drone: 'DRONE REPÉREUR',
    megaphone: 'NÉGOCIATEUR',
    sniper: 'TIREUR LBD',
    grenadier: 'LANCE-GRENADES F4',
    demineur: 'ROBOT FLASHBANG',
    flamethrower: 'CRS NETTOYEUR',
    bonusVan: 'CAMION DE RENFORTS',
    macron: 'MACRON'
};
const POLICE_REPORT_LABELS = {
    officer: 'Flics de ligne',
    shield_crs: 'CRS boucliers',
    flashball: 'Brigade flashball',
    water_cannon: 'Camions lance-eau',
    infiltrator: 'Agents infiltrés',
    bac: 'BAC',
    canine: 'Maîtres-chiens',
    dog: 'Chiens policiers',
    moto: 'BRAV-M',
    quad: 'Flics en quad',
    drone: 'Drones',
    megaphone: 'Négociateurs',
    sniper: 'Tireurs LBD',
    grenadier: 'Lance-grenades F4',
    demineur: 'Robots flashbang',
    flamethrower: 'CRS nettoyeurs',
    van: 'Camions de renforts',
    bonusVan: 'Camions bonus',
    tank: 'Chars',
    helicopter: 'Hélicoptères',
    macron: 'Macron'
};
const camera = { x: 0, y: 0, zoom: 1 };
const CAMERA_MIN_ZOOM = 0.35; // clamp anti-lag (évite zoom trop bas en coop sur grand monde)
const CAMERA_MAX_ZOOM = 1;
const CAMERA_COOP_MARGIN = 420;

const assetPaths = {
    terrain: 'assets/grass-bright.webp',
    player: 'assets/cute-survivor.webp',
    player1: 'assets/player-1.png',
    player2: 'assets/player-2.png',
    player3: 'assets/player-3.png',
    player4: 'assets/player-4.png',
    officer: 'assets/cute-officer.webp',
    riotOfficer: 'assets/riot-officer.webp',
    flashball: 'assets/police-flashball.webp',
    infiltrator: 'assets/police-infiltrator.webp',
    bac: 'assets/cute-bac-officer.webp',
    barricadeWorn: 'assets/cute-barricade-worn.webp',
    barricadeRuined: 'assets/cute-barricade-ruined.webp',
    dogHandler: 'assets/police-dog-handler.webp',
    dog: 'assets/police-dog.webp',
    moto: 'assets/brav-m-motorcycle.webp',
    quad: 'assets/police-quad.webp',
    drone: 'assets/police-drone.webp',
    megaphone: 'assets/police-megaphone.webp',
    sniper: 'assets/police-sniper.webp',
    demineur: 'assets/police-demineur.webp',
    flamethrower: 'assets/police-flamethrower.webp',
    waterCannon: 'assets/water-cannon-truck.webp',
    barricade: 'assets/cute-barricade.webp',
    shack: 'assets/cute-camp-shack.webp',
    resource: 'assets/cute-resource-crate.webp',
    waste: 'assets/cute-waste-pile.webp',
    core: 'assets/cute-camp-core.webp',
    van: 'assets/cute-police-van.webp',
    bonusVan: 'assets/police-van.webp',
    tank: 'assets/cute-police-tank.webp',
    helicopter: 'assets/cute-police-helicopter.webp',
    treehouse: 'assets/treehouse-watchtower.webp',
    medicCabin: 'assets/medic-cabin.webp',
    medic: 'assets/field-medic.webp',
    lyceeBackground: 'assets/lycee-street-map.svg',
    lyceeGate: 'assets/lycee-school-gate.webp',
    lyceeBins: 'assets/lycee-bin-barricade.webp',
    lyceeCdi: 'assets/lycee-cdi-building.webp',
    lyceeClassroom: 'assets/lycee-classroom-building.webp',
    lyceeInfirmary: 'assets/lycee-infirmary-building.webp',
    lyceeNeighbor: 'assets/lycee-angry-neighbor.webp',
    lyceeWarrior: 'assets/lycee-warrior-blackbloc.webp',
    lyceeCollector: 'assets/lycee-collector-supervisor.webp',
    warrior: 'assets/warrior-skin.png',
    riverCurrent: 'assets/river-current-tile.webp',
    riverBridge: 'assets/river-wooden-footbridge.webp',
    mapFactory: 'assets/Usine.png',
    mapVillage: 'assets/village.png',
    mapForest: 'assets/istockphoto-166010730-1024x1024.jpg',
    hedgeWall: 'assets/hedge-wall.png',
    bloodStain: 'assets/blood-stain.png',
    resourceWood: 'assets/resource-wood.png',
    resourceStone: 'assets/resource-stone.png',
    resourceScrap: 'assets/resource-scrap.png',
    resourceFuel: 'assets/resource-fuel.png',
    resourceGlass: 'assets/resource-glass.png',
    squatFloor: 'assets/squat-floor-v2.png',
    squatFire: 'assets/squat-fire.png',
    squatDecor: 'assets/squat-decor-v2.png',
    squatTorch: 'assets/squat-torch-v2.png',
    macron: 'assets/macron.webp',
    oeuf: 'assets/oeuf.png',
    grenadier: 'assets/f4-grenadier.webp'
};

// Bâtiments peints sur le fond de la carte Lycée, convertis en coordonnées monde.
// Les rectangles couvrent les empreintes des maisons, en laissant les rues et la cour libres.
const LYCEE_BUILDING_ZONES = [
    // Empreintes des bâtiments uniquement — bord sud resserré pour laisser les trottoirs du nord marchables
    { left: 40, right: 780, top: 0, bottom: 1280 },
    { left: 1340, right: 2440, top: 120, bottom: 920 },
    { left: 2950, right: 3910, top: 120, bottom: 920 },
    { left: 4420, right: WORLD_W - 20, top: 0, bottom: 1280 },
    { left: 40, right: 800, top: 1800, bottom: 2800 },
    { left: 4400, right: WORLD_W - 20, top: 1800, bottom: 2800 }
];

function isOnLyceeAssaultRoad(x, tolerance = 95) {
    return LYCEE_ASSAULT_ROADS.some((roadX) => Math.abs(x - roadX) <= tolerance);
}

function isLyceeBuildingBlocked(x, y, radius = 0) {
    // Uniquement les empreintes des bâtiments dessinés (maisons / blocs).
    // On peut marcher partout ailleurs, y compris au nord entre les maisons.
    return LYCEE_BUILDING_ZONES.some((zone) => {
        const closestX = Math.max(zone.left, Math.min(zone.right, x));
        const closestY = Math.max(zone.top, Math.min(zone.bottom, y));
        const dx = x - closestX;
        const dy = y - closestY;
        return dx * dx + dy * dy < radius * radius;
    });
}

function resolveLyceeBuildingMove(entity, nextX, nextY) {
    const radius = entity.radius || 0;
    const collides = (x, y) => isLyceeBuildingBlocked(x, y, radius);
    if (!collides(nextX, nextY)) return { x: nextX, y: nextY };

    // Résolution axe par axe : bloque uniquement les bâtiments, permet de longer les murs proprement.
    let x = entity.x;
    let y = entity.y;
    if (!collides(nextX, y)) x = nextX;
    if (!collides(x, nextY)) y = nextY;
    return { x, y };
}

function findLyceeSafeSpawn(x, y, radius) {
    // Spawns au nord : rester sur les routes d'assaut pour ne pas apparaître dans une maison.
    if (y < LYCEE_ROUTE_CLEAR_Y) {
        return { x: lyceeRoadForX(x), y: Math.max(35, Math.min(LYCEE_ROUTE_CLEAR_Y - 20, y)) };
    }
    if (!isLyceeBuildingBlocked(x, y, radius)) return { x, y };
    for (let distance = 50; distance <= 600; distance += 50) {
        for (let step = 0; step < 16; step++) {
            const angle = step * Math.PI / 8;
            const candidateX = Math.max(radius + 40, Math.min(WORLD_W - radius - 40, x + Math.cos(angle) * distance));
            const candidateY = Math.max(radius + 40, Math.min(WORLD_H - radius - 40, y + Math.sin(angle) * distance));
            if (!isLyceeBuildingBlocked(candidateX, candidateY, radius)) return { x: candidateX, y: candidateY };
        }
    }
    // Repli sur l'un des axes routiers du nord plutôt que derrière un bâtiment.
    return { x: lyceeRoadForX(x), y: Math.max(35, Math.min(LYCEE_ROUTE_CLEAR_Y, y)) };
}

function lyceeRoadForX(x) {
    return LYCEE_ASSAULT_ROADS.reduce((best, roadX) =>
        Math.abs(roadX - x) < Math.abs(best - x) ? roadX : best,
    LYCEE_ASSAULT_ROADS[0]);
}

function lyceeRoadSpawn(lane = Math.floor(Math.random() * LYCEE_ASSAULT_ROADS.length), y = -90 - Math.random() * 120) {
    const roadX = LYCEE_ASSAULT_ROADS[((lane % LYCEE_ASSAULT_ROADS.length) + LYCEE_ASSAULT_ROADS.length) % LYCEE_ASSAULT_ROADS.length];
    return { x: roadX, y };
}

// Mode Rivière : un anneau d'eau autour du camp, traversable par trois ponts radiaux.
const RIVER_RING_R = 980;
const RIVER_WATER_HALF = 155;
// Distance dont un collecteur continue au-delà de la berge après un pont, avant de viser sa ressource.
const RIVER_CROSS_EXTRA = 45;
const RIVER_BRIDGE_LENGTH = 460;
const RIVER_BRIDGE_WIDTH = 300;
const RIVER_BRIDGES = [
    { x: CAMP_X, y: CAMP_Y - RIVER_RING_R, w: RIVER_BRIDGE_LENGTH, h: RIVER_BRIDGE_WIDTH, angle: -Math.PI / 2 },
    { x: CAMP_X - 720, y: CAMP_Y + 680, w: RIVER_BRIDGE_LENGTH, h: RIVER_BRIDGE_WIDTH, angle: Math.atan2(680, -720) },
    { x: CAMP_X + 720, y: CAMP_Y + 680, w: RIVER_BRIDGE_LENGTH, h: RIVER_BRIDGE_WIDTH, angle: Math.atan2(680, 720) }
];
function riverBridgeZones() {
    return RIVER_BRIDGES;
}
function isOnRiverBridge(x, y) {
    for (const b of riverBridgeZones()) {
        const dx = x - b.x;
        const dy = y - b.y;
        const c = Math.cos(-b.angle);
        const s = Math.sin(-b.angle);
        const lx = dx * c - dy * s;
        const ly = dx * s + dy * c;
        // Zone très large : couvre toute la traversée d'eau + approches des deux côtés
        if (Math.abs(lx) <= b.w * 0.5 + 210 && Math.abs(ly) <= b.h * 0.5 + 50) return true;
    }
    return false;
}
function isInRiverWater(x, y) {
    if (!state || state.map !== 'river') return false;
    const d = Math.hypot(x - CAMP_X, y - CAMP_Y);
    if (d < RIVER_RING_R - RIVER_WATER_HALF || d > RIVER_RING_R + RIVER_WATER_HALF) return false;
    return !isOnRiverBridge(x, y);
}
function nearestRiverBridge(x, y) {
    let best = null;
    let bestD = Infinity;
    for (const b of riverBridgeZones()) {
        const d = Math.hypot(b.x - x, b.y - y);
        if (d < bestD) {
            bestD = d;
            best = b;
        }
    }
    return best;
}
/** extra > 0 = côté EXTÉRIEUR (hors camp), extra < 0 = côté INTÉRIEUR (camp).
 *  |extra| = marge au-delà de l'extrémité du pont. Sans le signe, un extra négatif
 *  restait du même côté (distance = w/2 + extra restait positive) → oscillation
 *  et impossibilité de traverser pour collecteurs / flics. */
function riverBridgeApproach(bridge, extra = 120, lateral = 0) {
    const ux = Math.cos(bridge.angle);
    const uy = Math.sin(bridge.angle);
    const side = extra >= 0 ? 1 : -1;
    const distance = side * (bridge.w * 0.5 + Math.abs(extra));
    return {
        x: bridge.x + ux * distance - uy * lateral,
        y: bridge.y + uy * distance + ux * lateral
    };
}
function riverBridgeEntryForSide(bridge, isOuter) {
    // Approche côté concerné, sur la terre ferme (au-delà de l'eau)
    return riverBridgeApproach(bridge, isOuter ? 170 : -170);
}
function riverBridgeExitForSide(bridge, isOuter) {
    // Sortie LOIN du centre de l'autre côté (évite l'oscillation au milieu du pont)
    return riverBridgeApproach(bridge, isOuter ? 170 : -170);
}
/** Les unités au sol peuvent longer la berge puis traverser par un pont. */
function resolveRiverMove(entity, nextX, nextY, canFly = false) {
    if (canFly || !state) return { x: nextX, y: nextY };
    if (state.map === 'lycee') return resolveLyceeBuildingMove(entity, nextX, nextY);
    if (state.map === 'maze') return resolveMazeMove(entity, nextX, nextY, canFly);
    if (state.map === 'squat') return resolveSquatMove(entity, nextX, nextY, canFly);
    if (state.map !== 'river') return { x: nextX, y: nextY };
    // Destination hors de l'eau (ou sur un pont) : OK
    if (!isInRiverWater(nextX, nextY)) return { x: nextX, y: nextY };

    // Proche d'un pont : coller à l'axe et avancer le long du pont
    const bridge = nearestRiverBridge(entity.x, entity.y);
    if (bridge) {
        const c = Math.cos(-bridge.angle);
        const s = Math.sin(-bridge.angle);
        const cosA = Math.cos(bridge.angle);
        const sinA = Math.sin(bridge.angle);
        const dx = entity.x - bridge.x, dy = entity.y - bridge.y;
        const curLx = dx * c - dy * s;
        const curLy = dx * s + dy * c;
        // Zone d'attraction large autour du pont
        if (Math.abs(curLx) <= bridge.w * 0.5 + 180 && Math.abs(curLy) <= bridge.h * 0.5 + 80) {
            const ndx = nextX - bridge.x, ndy = nextY - bridge.y;
            let lx = ndx * c - ndy * s;
            let ly = ndx * s + ndy * c;
            // Forcer dans le rectangle du pont élargi
            lx = Math.max(-bridge.w * 0.5 - 200, Math.min(bridge.w * 0.5 + 200, lx));
            ly = Math.max(-bridge.h * 0.5 - 30, Math.min(bridge.h * 0.5 + 30, ly));
            const px = bridge.x + lx * cosA - ly * sinA;
            const py = bridge.y + lx * sinA + ly * cosA;
            if (!isInRiverWater(px, py)) return { x: px, y: py };
            // Fallback : rester sur l'axe (ly≈0)
            const px2 = bridge.x + lx * cosA;
            const py2 = bridge.y + lx * sinA;
            if (!isInRiverWater(px2, py2)) return { x: px2, y: py2 };
        }
    }

    // Glisser le long de la berge
    const currentDistance = Math.hypot(entity.x - CAMP_X, entity.y - CAMP_Y);
    const nextAngle = Math.atan2(nextY - CAMP_Y, nextX - CAMP_X);
    const shoreRadius = currentDistance >= RIVER_RING_R
        ? RIVER_RING_R + RIVER_WATER_HALF + 12
        : RIVER_RING_R - RIVER_WATER_HALF - 12;
    const slideX = CAMP_X + Math.cos(nextAngle) * shoreRadius;
    const slideY = CAMP_Y + Math.sin(nextAngle) * shoreRadius;
    if (!isInRiverWater(slideX, slideY)) return { x: slideX, y: slideY };
    return { x: entity.x, y: entity.y };
}
const weapons = {
    slingshot: { label: 'LANCE-PIERRE', wave: 0, cost: { stone: 1 }, damage: 35, speed: 760, cooldown: 0.32, radius: 9, color: '#e0dccb' },
    sling: { label: 'FRONDE', wave: 2, cost: { wood: 1, stone: 1 }, damage: 62, speed: 980, cooldown: 0.48, radius: 12, color: '#d5b36a' },
    molotov: { label: 'COCKTAIL MOLOTOV', wave: 3, cost: { wood: 2, fuel: 1, glass: 1 }, damage: 76, speed: 580, cooldown: 0.9, radius: 13, color: '#ff7137', splash: 125 },
    barre: { label: 'BARRE DE FER', wave: 1, craftCost: { wood: 1, scrap: 3 }, cost: {}, damage: 32, speed: 0, cooldown: 0.62, radius: 92, color: '#b9c8c7', melee: true },
    fireworks: { label: 'FEUX D’ARTIFICES', wave: 4, cost: { wood: 1, fuel: 1, glass: 1 }, damage: 112, speed: 640, cooldown: 1.15, radius: 11, color: '#ff6fb5', splash: 155, firework: true },
    policeFlashball: { label: 'FLASHBALL RÉCUPÉRÉ', wave: 0, cost: {}, damage: 125, speed: 890, cooldown: 0.38, radius: 13, color: '#ffdd76', temporary: true },
    policeLbd: { label: 'LBD RÉCUPÉRÉ', wave: 0, cost: {}, damage: 245, speed: 1120, cooldown: 0.72, radius: 15, color: '#ff5060', temporary: true }
};
const resourceInfo = {
    wood: { label: 'BOIS', short: 'bois', color: '#d89f55', prompt: 'FOUILLER BOIS', gain: '+1 BOIS' },
    scrap: { label: 'FERRAILLE', short: 'ferraille', color: '#9cc5bd', prompt: 'FOUILLER FERRAILLE', gain: '+1 FERRAILLE' },
    stone: { label: 'PIERRES', short: 'pierre', color: '#b7b7aa', prompt: 'FOUILLER PIERRES', gain: '+2 PIERRES' },
    fuel: { label: 'ESSENCE', short: 'essence', color: '#ef944d', prompt: 'RÉCUPÉRER ESSENCE', gain: '+1 ESSENCE' },
    glass: { label: 'VERRE', short: 'verre', color: '#75d3d2', prompt: 'RÉCUPÉRER VERRE', gain: '+1 VERRE' }
};
// Les réparations des barricades et des cabanes ne consomment aucune ressource.
const repairDuration = 1.35;
const repairRange = 118;
const repairAmount = 68;
const WORKERS_PER_SHACK = 2;
const GUARDS_PER_SHACK = 2;
const MEDICS_PER_SHACK = 1;
const WORKER_RECRUIT_TIME = 9;
const GUARD_RECRUIT_TIME = 12;
const MEDIC_RECRUIT_TIME = 10;
const WORKER_HARVEST_TIME = 0.8;
const CABIN_MAX_LEVEL = 3;
const MEDIC_HEAL_RANGE = 980;
const MEDIC_HEAL_INTERVAL = 0.7;
const CABIN_UPGRADE_RANGE = 190;
const PLAYER_MAX_HP = 120;
const PLAYER_REVIVE_RANGE = 112;
const PLAYER_REVIVE_DURATION = 2.2;
const PLAYER_BLEEDOUT_DURATION = 28;
const PLAYER_LEVEL_THRESHOLDS = [0, 5, 50, 200, 500, 1500, 4000, 10000, 20000, 30000];
const PLAYER_POWER_DEFS = {
    harvest: { label: 'RAMASSAGE +10 % RAPIDE', short: 'Ramassage des ressources 10 % plus rapide' },
    cabinDiscount: { label: 'CABANES -10 %', short: 'Cabanes et constructions d’habitation 10 % moins chères' },
    speed: { label: 'VITESSE +10 %', short: 'Vitesse de déplacement +10 %' },
    life: { label: 'VIE +10 %', short: 'Vie maximale +10 %' },
    resources: { label: '+10 DE CHAQUE RESSOURCE', short: 'Ajoute immédiatement 10 bois, pierre, ferraille, essence et verre au stock commun' },
    bomb: { label: 'ÉMEUTE RÉVOLUTIONNAIRE', short: 'Déclenche une émeute qui neutralise les policiers présents, sans crédit de niveau' },
    warriors: { label: '+10 GUERRIERS', short: 'Fait apparaître 10 guerriers alliés autour du joueur' }
};
const PLAYER_POWER_KEYS = Object.keys(PLAYER_POWER_DEFS);

const WATCHTOWER_RANGE = 620;
const WATCHTOWER_COOLDOWN = 1.15;
const images = {};
for (const [name, src] of Object.entries(assetPaths)) {
    const image = new Image();
    image.crossOrigin = 'anonymous';
    image.src = src;
    images[name] = image;
}

const music = new Audio('assets/audio/night-resistance.mp3');
music.loop = true;
music.volume = 0.38;
const buildSound = new Audio('assets/audio/makeshift-build.mp3');
buildSound.volume = 0.65;
let audioContext;
let muted = false;

const input = {
    keys: new Set(),
    mouseX: W / 2,
    mouseY: H / 2,
    screenMouseX: W / 2,
    screenMouseY: H / 2,
    pointerDown: false,
    pointerInside: true,
    codes: new Set()
};
let state;
let lastTime = performance.now();
let running = false;
let enemyUpdateAccumulator = 0;
let selectedMode = 'normal';
let selectedMap = 'camp';
let lyceeUnlocked = true; // débloqué par défaut
let toastTimer = 0;
let arsenalOpen = false;
let controlsOpen = false;
const gamepadButtonState = new Map();
const powerChoiceButtonState = new Map();
const gamepadPlayerSlots = new Map();
// Si la partie démarre au clavier/souris, J1 est réservé au clavier/souris.
// Une manette qui arrive ensuite prend toujours J2, puis J3, puis J4.
let primaryInputMode = 'gamepad';

const ui = {
    wood: document.querySelector('#wood'),
    scrap: document.querySelector('#scrap'),
    stone: document.querySelector('#stone'),
    fuel: document.querySelector('#fuel'),
    glass: document.querySelector('#glass'),
    phase: document.querySelector('#phase'),
    clock: document.querySelector('#clock'),
    score: document.querySelector('#score'),
    campText: document.querySelector('#campText'),
    campMeter: document.querySelector('#campMeter'),
    toast: document.querySelector('#toast'),
    waveAlert: document.querySelector('#wave-alert'),
    waveAlertTitle: document.querySelector('#waveAlertTitle'),
    waveAlertClock: document.querySelector('#waveAlertClock'),
    waveAlertAgents: document.querySelector('#waveAlertAgents'),
    waveAlertVehicles: document.querySelector('#waveAlertVehicles'),
    waveAlertRoute: document.querySelector('#waveAlertRoute'),
    bonusObjective: document.querySelector('#bonus-objective'),
    bonusObjectiveDistance: document.querySelector('#bonusObjectiveDistance'),
    overlay: document.querySelector('#overlay'),
    arsenal: document.querySelector('#arsenal'),
    arsenalToggle: document.querySelector('#arsenal-toggle'),
    weaponWave: document.querySelector('#weaponWave'),
    allyCount: document.querySelector('#allyCount'),
    workerCount: document.querySelector('#workerCount'),
    medicCount: document.querySelector('#medicCount'),
    playerInventoryList: document.querySelector('#player-inventory-list'),
    controls: document.querySelector('#controls-menu'),
    controlsToggle: document.querySelector('#controls-toggle'),
    fullscreen: document.querySelector('#fullscreen'),
    pauseOverlay: document.querySelector('#pause-overlay'),
    resume: document.querySelector('#resume'),
    returnMenu: document.querySelector('#return-menu'),
    start: document.querySelector('#start'),
    weaponButtons: [...document.querySelectorAll('.weapon')],
    tutorialOverlay: document.querySelector('#tutorial-overlay'),
    tutorialKicker: document.querySelector('#tutorial-kicker'),
    tutorialTitle: document.querySelector('#tutorial-title'),
    tutorialDetail: document.querySelector('#tutorial-detail'),
    tutorialOk: document.querySelector('#tutorial-ok')
};

const GAME_MODES = {
    tutorial: { label: 'TUTORIEL' },
    easy: { label: 'EASY' },
    normal: { label: 'NORMAL' },
    hard: { label: 'HARD' }
};
const MAPS = {
    camp: { label: 'CAMP' },
    river: { label: 'RIVIÈRE' },
    lycee: { label: 'LYCÉE' },
    maze: { label: 'LABYRINTHE' },
    squat: { label: 'OUVERTURE DE SQUAT' }
};

// ─── Mode Tutoriel : objectifs guidés + présentation de chaque type de flic ───
const TUTORIAL_STEPS = [
    {
        id: 'shoot',
        title: 'INTRODUCTION · APPRENDRE À TIRER',
        detail: 'Cliquez ou appuyez sur ESPACE pour tirer avec le lance-pierre. Déplacez-vous avec WASD / ZQSD. Tirez 3 fois pour continuer.',
        check: (s) => s.tutorial.shotsFired >= 3,
        onEnter: (s) => {
            showToast('TUTORIEL · Cliquez ou ESPACE pour tirer (3 fois)');
            s.tutorial.shotsFired = 0;
        }
    },
    {
        id: 'kill1',
        title: 'OBJECTIF 1 · ÉLIMINER LE POLICIER',
        detail: 'NOUVEAU FLIC — FLIC DE LIGNE : peu de PV, avance lentement, attaque uniquement au corps-à-corps. Un seul arrive. Éliminez-le.',
        check: (s) => (s.battleStats.policeKilled.officer || 0) >= 1 && s.enemies.length === 0,
        onEnter: (s) => {
            showToast('FLIC DE LIGNE · Lent, peu de PV, contact');
            spawnTutorialEnemies(['officer'], 1);
        }
    },
    {
        id: 'levels',
        title: 'SYSTÈME DE NIVEAUX',
        detail: 'Chaque policier éliminé compte pour le niveau d’équipe. Au niveau 2 (5 éliminations), puis 3 (50), etc., vous choisissez un pouvoir (ramassage plus rapide, dégâts, etc.). Les alliés qui tuent comptent aussi. Le premier niveau arrive bientôt — choisissez bien !',
        check: (s) => s.tutorial.levelsAck,
        onEnter: (s) => {
            showToast('Niveaux · 5 kills = niveau 2 · pouvoirs à choisir');
        },
        // Validé uniquement par OK (voir dismissTutorialModal)
        ackOnOk: true
    },
    {
        id: 'build_shack',
        title: 'OBJECTIF 2 · CABANE RESSOURCE',
        detail: 'Ramassez les ressources : approchez une pile au sol et maintenez E (fouiller / ramasser). Puis appuyez sur H et cliquez pour placer une CABANE COLLECTE (18 bois + 10 ferraille). Elle recrute des collecteurs automatiques.',
        check: (s) => s.buildings.some(b => b.type === 'shack' && !b.starter),
        onEnter: (s) => {
            const inv = s.sharedResources || s.players[0].inventory;
            inv.wood = Math.max(inv.wood || 0, 25);
            inv.scrap = Math.max(inv.scrap || 0, 15);
            inv.stone = Math.max(inv.stone || 0, 8);
            showToast('E près d’une pile pour ramasser · H pour placer la cabane');
        }
    },
    {
        id: 'kill_bac',
        title: 'OBJECTIF 3 · ÉLIMINER 5 BAC',
        detail: 'NOUVEAU FLIC — BAC EN CIVIL : très rapide, charge en mêlée, gros dégâts. Macron et certains ennemis pondent des ŒUFS BLEUS qui éclosent en BAC. Éliminez 5 BAC.',
        check: (s) => (s.battleStats.policeKilled.bac || 0) >= 5 && s.enemies.length === 0,
        onEnter: (s) => {
            showToast('BAC · Ultra-rapides, charges, œufs bleus');
            spawnTutorialEnemies(['bac'], 5);
        }
    },
    {
        id: 'build_guard',
        title: 'OBJECTIF 4 · CABANE GUERRIÈRE',
        detail: 'Appuyez sur G puis cliquez pour construire une CABANE GUERRIÈRE (22 bois + 12 ferraille). Elle recrute des guerriers alliés qui combattent à vos côtés.',
        check: (s) => s.buildings.some(b => b.type === 'guardShack' && !b.starter),
        onEnter: (s) => {
            const inv = s.sharedResources || s.players[0].inventory;
            inv.wood = Math.max(inv.wood || 0, 30);
            inv.scrap = Math.max(inv.scrap || 0, 20);
            showToast('G pour cabane guerrière · Placez-la près du camp');
        }
    },
    {
        id: 'kill20',
        title: 'OBJECTIF 5 · ÉLIMINER 20 POLICIERS',
        detail: 'NOUVEAUX FLICS dans cette vague :\n• FLASHBALL — tire à distance, étourdit\n• TIREUR LBD — sniper immobile, gros dégâts\n• LANCE-GRENADES F4 — lance des grenades explosives\n+ flics de ligne. Éliminez 20 ennemis.',
        check: (s) => {
            const total = Object.values(s.battleStats.policeKilled || {}).reduce((a, b) => a + b, 0);
            return total >= 20 + (s.tutorial.killsBefore || 0) && s.enemies.length === 0;
        },
        onEnter: (s) => {
            s.tutorial.killsBefore = Object.values(s.battleStats.policeKilled || {}).reduce((a, b) => a + b, 0);
            showToast('FLASHBALL · LBD · F4 + flics de ligne');
            spawnTutorialEnemies(['officer', 'officer', 'officer', 'flashball', 'sniper', 'grenadier', 'officer', 'flashball', 'officer', 'sniper', 'officer', 'grenadier', 'officer', 'flashball', 'officer', 'officer', 'sniper', 'officer', 'flashball', 'officer'], 20);
        }
    },
    {
        id: 'craft_weapon',
        title: 'OBJECTIF 6 · FABRIQUER UNE ARME',
        detail: 'Vous êtes considéré en vague 10 : toutes les armes sont débloquées. Ouvrez l’atelier (TAB) ou appuyez sur 2 (Fronde), 3 (Molotov), 4 (Barre de fer) ou 5 (Feux d’artifice) pour FABRIQUER une arme. Il faut vraiment la fabriquer (pas seulement le lance-pierre) pour continuer.',
        check: (s) => {
            const p = s.players[0];
            if (!p?.craftedWeapons) return false;
            return ['sling', 'molotov', 'barre', 'fireworks'].some((w) => p.craftedWeapons[w]);
        },
        onEnter: (s) => {
            const inv = s.sharedResources || s.players[0].inventory;
            inv.wood = Math.max(inv.wood || 0, 15);
            inv.stone = Math.max(inv.stone || 0, 12);
            inv.scrap = Math.max(inv.scrap || 0, 12);
            inv.fuel = Math.max(inv.fuel || 0, 6);
            inv.glass = Math.max(inv.glass || 0, 6);
            showToast('TAB ou 2/3/4/5 · fabriquez une arme pour valider');
        }
    },
    {
        id: 'kill30',
        title: 'OBJECTIF 7 · ÉLIMINER 30 POLICIERS',
        detail: 'NOUVEAUX FLICS :\n• CRS BOUCLIER — très résistant, bloque les tirs\n• MAÎTRE-CHIEN + CHIEN — le chien fonce très vite\n• BRAV-M (moto) et QUAD — rapides, drive-by\n• DRONE — repère, vole\n• NÉGOCIATEUR — soutient les autres\n• CHAR (tank) — très blindé, lents mais dévastateurs\nÉliminez 30 ennemis.',
        check: (s) => {
            const total = Object.values(s.battleStats.policeKilled || {}).reduce((a, b) => a + b, 0);
            return total >= 30 + (s.tutorial.killsBefore || 0) && s.enemies.length === 0;
        },
        onEnter: (s) => {
            s.tutorial.killsBefore = Object.values(s.battleStats.policeKilled || {}).reduce((a, b) => a + b, 0);
            showToast('BOUCLIERS · CHIENS · MOTO · QUAD · DRONE · TANK');
            const mix = [];
            for (let i = 0; i < 12; i++) mix.push('officer');
            mix.push('shield_crs', 'shield_crs', 'canine', 'canine', 'moto', 'quad', 'drone', 'megaphone', 'tank', 'officer', 'officer', 'canine', 'moto', 'quad', 'officer', 'shield_crs', 'drone', 'officer');
            spawnTutorialEnemies(mix, 30);
        }
    },
    {
        id: 'build_medic',
        title: 'OBJECTIF 8 · CABANE MÉDIC',
        detail: 'Appuyez sur N puis cliquez pour construire une CABANE MÉDIC (20 bois + 12 ferraille + 4 pierres). Elle soigne vos alliés et vous-même à proximité.',
        check: (s) => s.buildings.some(b => b.type === 'medicShack' && !b.starter),
        onEnter: (s) => {
            const inv = s.sharedResources || s.players[0].inventory;
            inv.wood = Math.max(inv.wood || 0, 30);
            inv.scrap = Math.max(inv.scrap || 0, 20);
            inv.stone = Math.max(inv.stone || 0, 10);
            showToast('N pour cabane médic · Placez-la au centre du camp');
        }
    },
    {
        id: 'kill40',
        title: 'OBJECTIF 9 · ÉLIMINER 40 POLICIERS',
        detail: 'NOUVEAUX FLICS :\n• CRS NETTOYEUR (flamme) — lance du feu au sol\n• ROBOT FLASHBANG — s’approche et explose / flash\n• CAMION LANCE-EAU — zone d’eau qui ralentit et blesse\n+ tous les types déjà vus. Éliminez 40 ennemis.',
        check: (s) => {
            const total = Object.values(s.battleStats.policeKilled || {}).reduce((a, b) => a + b, 0);
            return total >= 40 + (s.tutorial.killsBefore || 0) && s.enemies.length === 0;
        },
        onEnter: (s) => {
            s.tutorial.killsBefore = Object.values(s.battleStats.policeKilled || {}).reduce((a, b) => a + b, 0);
            showToast('FLAMME · ROBOT · LANCE-EAU + tous types');
            const mix = [];
            for (let i = 0; i < 15; i++) mix.push('officer');
            for (let i = 0; i < 5; i++) mix.push('bac');
            mix.push('flashball', 'flashball', 'sniper', 'grenadier', 'flamethrower', 'demineur', 'water_cannon', 'shield_crs', 'canine', 'moto', 'quad', 'drone', 'megaphone', 'tank', 'officer', 'bac', 'flashball', 'sniper', 'grenadier', 'officer');
            spawnTutorialEnemies(mix, 40);
        }
    },
    {
        id: 'build_treehouse',
        title: 'OBJECTIF 10 · TOUR ARBORICOLE',
        detail: 'Appuyez sur T puis cliquez pour construire une TOUR ARBORICOLE (26 bois + 16 ferraille + 4 pierres). Elle tire automatiquement sur les ennemis à portée.',
        check: (s) => s.buildings.some(b => b.type === 'treehouse' && !b.starter),
        onEnter: (s) => {
            const inv = s.sharedResources || s.players[0].inventory;
            inv.wood = Math.max(inv.wood || 0, 40);
            inv.scrap = Math.max(inv.scrap || 0, 25);
            inv.stone = Math.max(inv.stone || 0, 10);
            showToast('T pour tour arboricole · Défense automatique');
        }
    },
    {
        id: 'survive',
        title: 'OBJECTIF FINAL · SURVIVRE À L’ASSAUT',
        detail: 'NOUVEAU — MACRON : boss ultra-résistant, très rapide, pond des ŒUFS BLEUS (BAC). Une armée massive l’accompagne (tanks, flashball, LBD, F4…). Éliminez Macron et nettoyez la zone.',
        check: (s) => (s.battleStats.policeKilled.macron || 0) >= 1 && s.enemies.length === 0,
        onEnter: (s) => {
            showToast('MACRON ARRIVE ! Boss + armée');
            spawnTutorialEnemies(['macron'], 1);
            const mix = [];
            for (let i = 0; i < 20; i++) mix.push('officer');
            for (let i = 0; i < 8; i++) mix.push('bac');
            mix.push('tank', 'tank', 'flashball', 'flashball', 'sniper', 'grenadier', 'water_cannon', 'flamethrower', 'shield_crs', 'canine', 'moto', 'quad');
            setTimeout(() => { if (state && state.difficulty === 'tutorial') spawnTutorialEnemies(mix, mix.length); }, 4000);
        }
    },
    {
        id: 'done',
        title: 'TUTORIEL TERMINÉ !',
        detail: 'Bravo ! Tous les types de flics et les constructions de base sont connus. Consultez le POULAILLER ([M] Commandes) pour revoir chaque unité. Lancez une partie normale.',
        check: () => false,
        onEnter: (s) => {
            showToast('TUTORIEL RÉUSSI · Retour menu dans 8 s');
            s.victory = true;
            setTimeout(() => { if (state && state.difficulty === 'tutorial') endGame(true); }, 8000);
        }
    }
];

function spawnTutorialEnemies(types, count) {
    if (!state) return;
    const list = Array.isArray(types) ? types : [types];
    for (let i = 0; i < count; i++) {
        const type = list[i % list.length];
        const angle = (i / count) * Math.PI * 2 + Math.random() * 0.4;
        const dist = 900 + Math.random() * 400;
        const x = Math.max(80, Math.min(WORLD_W - 80, CAMP_X + Math.cos(angle) * dist));
        const y = Math.max(80, Math.min(WORLD_H - 80, CAMP_Y + Math.sin(angle) * dist));
        queueEnemySpawn(type, x, y, 'camp', 0);
    }
}

function showTutorialModal(step) {
    if (!state || !step) return;
    state.tutorial.waitingOk = true;
    state.paused = true;
    input.pointerDown = false;
    if (ui.tutorialKicker) ui.tutorialKicker.textContent = 'TUTORIEL';
    if (ui.tutorialTitle) ui.tutorialTitle.textContent = step.title;
    if (ui.tutorialDetail) ui.tutorialDetail.textContent = step.detail;
    if (ui.tutorialOverlay) {
        ui.tutorialOverlay.classList.remove('hidden');
        ui.tutorialOverlay.setAttribute('aria-hidden', 'false');
    }
    // Fermer la pause classique si elle était ouverte
    ui.pauseOverlay?.classList.add('hidden');
    ui.pauseOverlay?.setAttribute('aria-hidden', 'true');
    if (ui.bonusObjective) {
        ui.bonusObjective.classList.remove('hidden');
        ui.bonusObjective.innerHTML = `<b>${step.title}</b><span>${step.detail}</span>`;
    }
    try { music.pause(); } catch (_) {}
}

function dismissTutorialModal() {
    if (!state || !state.tutorial || !state.tutorial.waitingOk) return;
    state.tutorial.waitingOk = false;
    state.paused = false;
    input.pointerDown = false;
    if (ui.tutorialOverlay) {
        ui.tutorialOverlay.classList.add('hidden');
        ui.tutorialOverlay.setAttribute('aria-hidden', 'true');
    }
    lastTime = performance.now();
    if (!muted) try { music.play().catch(() => {}); } catch (_) {}
    const step = TUTORIAL_STEPS[state.tutorial.step];
    if (step && !state.tutorial.enteredStep) {
        state.tutorial.enteredStep = true;
        if (step.onEnter) step.onEnter(state);
    }
    // Étapes purement informatives (ex. système de niveaux) : OK valide l’objectif
    if (step?.ackOnOk) {
        state.tutorial.levelsAck = true;
    }
}

function beginTutorialStep(index) {
    if (!state || !state.tutorial) return;
    state.tutorial.step = index;
    state.tutorial.enteredStep = false;
    const step = TUTORIAL_STEPS[index];
    if (!step) return;
    updateTutorialUI();
    showTutorialModal(step);
}

function advanceTutorial() {
    if (!state || state.difficulty !== 'tutorial' || !state.tutorial) return;
    if (state.tutorial.waitingOk) return;
    const step = TUTORIAL_STEPS[state.tutorial.step];
    if (!step || !step.check) return;
    if (step.check(state)) {
        const nextIndex = state.tutorial.step + 1;
        if (nextIndex < TUTORIAL_STEPS.length) {
            beginTutorialStep(nextIndex);
        }
    }
}

function updateTutorialUI() {
    if (!state || state.difficulty !== 'tutorial' || !state.tutorial) return;
    const step = TUTORIAL_STEPS[state.tutorial.step];
    if (!step) return;
    if (ui.bonusObjective) {
        ui.bonusObjective.classList.remove('hidden');
        ui.bonusObjective.innerHTML = `<b>${step.title}</b><span>${step.detail}</span>`;
    }
}

// ─── Ouverture de squat : 9 salles en parcours serpent (formes variées) ───
const SQUAT_ROOM_W = 1800, SQUAT_ROOM_H = 1300;
// shapes: rect | round | oval | corridor | triangle | ring
// Couloirs 2→3 (vers triangle) et 3→4 allongés ; les autres gardent l'écart d'origine.
const SQUAT_ROOMS = [
  {id:0,x:1400,y:900, shape:'rect'},
  {id:1,x:3800,y:900, shape:'round'},
  {id:2,x:6200,y:900, shape:'triangle'},
  {id:3,x:6200,y:3600, shape:'rect'},
  {id:4,x:3800,y:3600, shape:'ring'}, // salle annulaire : centre inaccessible
  {id:5,x:1400,y:3600, shape:'round'},
  {id:6,x:1400,y:5400, shape:'oval'},
  {id:7,x:3800,y:5400, shape:'rect'},
  {id:8,x:6200,y:5400, shape:'round'}
];
const SQUAT_DOORS = [
  {id:1,a:0,b:1,orientation:'h',x:2600,y:900},
  {id:2,a:1,b:2,orientation:'h',x:5000,y:900},
  {id:3,a:2,b:3,orientation:'v',x:6200,y:2250},
  {id:4,a:3,b:4,orientation:'h',x:5000,y:3600},
  {id:5,a:4,b:5,orientation:'h',x:2600,y:3600},
  {id:6,a:5,b:6,orientation:'v',x:1400,y:4500},
  {id:7,a:6,b:7,orientation:'h',x:2600,y:5400},
  {id:8,a:7,b:8,orientation:'h',x:5000,y:5400}
];
// Décors au sol pré-placés (positions relatives dans chaque salle)
// Spritesheet 5×3 (assets illustrés haute qualité)
const SQUAT_DECOR_COLS = 5;
const SQUAT_DECOR_ROWS = 3;
// Indices: 0 barrel, 1 broken, 2 urn, 3 chest, 4 pillar,
//          5 crate, 6 bookshelf, 7 rubble, 8 torch, 9 gold,
//          10 table, 11 gate, 12 ivy, 13 rug, 14 broken pillar
const SQUAT_DECOR_LAYOUT = [
  // TOUS les décors purement décoratifs sont collés aux BORDS de salle (centre libre pour le combat)
  // Piliers coins
  {i:4, ox:-700, oy:-500, dw:100, dh:120},
  {i:4, ox: 700, oy:-500, dw:100, dh:120},
  {i:4, ox:-700, oy: 480, dw:100, dh:120},
  {i:4, ox: 700, oy: 480, dw:100, dh:120},
  // Tonneaux coins
  {i:0, ox:-620, oy:-380, dw:85, dh:95},
  {i:0, ox: 640, oy: 400, dw:85, dh:95},
  {i:1, ox: 620, oy:-400, dw:90, dh:100},
  // Urne / caisse / table le long des murs
  {i:2, ox:-680, oy: 200, dw:70, dh:85},
  {i:5, ox:-550, oy: 480, dw:90, dh:90},
  {i:10, ox: 550, oy:-480, dw:110, dh:90},
  // Gravats + pilier brisé contre les murs
  {i:7, ox: 650, oy: 200, dw:120, dh:100},
  {i:14, ox:-650, oy:-150, dw:95, dh:110},
  // Lierre collé aux murs
  {i:12, ox:-720, oy: 0, dw:110, dh:130},
  {i:12, ox: 720, oy:-30, dw:110, dh:130},
  // Tapis contre le mur sud (plus au centre)
  {i:13, ox: 0, oy: 480, dw:150, dh:100},
];
const SQUAT_DECOR_BY_ROOM = {
  0: [ // trésor le long des murs, pas au centre
    {i:3, ox:-500, oy:-420, dw:140, dh:120},
    {i:9, ox:-620, oy:-300, dw:110, dh:90},
    {i:9, ox: 600, oy: 400, dw:100, dh:80},
    {i:2, ox: 680, oy:-350, dw:65, dh:80},
  ],
  1: [
    {i:6, ox:-680, oy:-200, dw:120, dh:150},
    {i:10, ox: 650, oy: 420, dw:100, dh:85},
    {i:0, ox: 680, oy: 200, dw:80, dh:90},
  ],
  2: [
    {i:6, ox: 680, oy:-350, dw:120, dh:150},
    {i:3, ox:-650, oy: 400, dw:120, dh:100},
    {i:11, ox: 0, oy: 500, dw:100, dh:110},
  ],
  3: [
    {i:6, ox:-700, oy: 0, dw:120, dh:150},
    {i:6, ox: 700, oy: 0, dw:120, dh:150},
    {i:7, ox: 0, oy: 500, dw:130, dh:100},
  ],
};

const SQUAT_FIRE_COLS = 6, SQUAT_FIRE_ROWS = 4;
// Caches pré-rendus (sol+murs+décors) — évite de re-scaler les images chaque frame
let squatRoomCaches = null;   // [{canvas, x, y}]
let squatCorridorCaches = null; // [{canvas, x, y}]
let squatCacheReady = false;

const SQUAT_FIRE_FW = Math.floor(1408 / 6); // 234 — taille entière obligatoire sinon le sprite "défile"
const SQUAT_FIRE_FH = Math.floor(768 / 4); // 192

function pointInSquatRoomShape(room, x, y) {
  const dx = x - room.x;
  const dy = y - room.y;
  const hw = SQUAT_ROOM_W / 2;
  const hh = SQUAT_ROOM_H / 2;
  // Seuils très larges aux portes (surtout verticales triangle→rect) pour coller aux couloirs longs.
  const doorway = SQUAT_DOORS.some(d => (d.a === room.id || d.b === room.id) && (d.orientation === 'h'
    ? Math.abs(d.y - room.y) < 1 && Math.abs(dy) < 180 && Math.abs(dx) >= hw - 220 && Math.abs(dx) <= hw + 280
    : Math.abs(d.x - room.x) < 1 && Math.abs(dx) < 220 && Math.abs(dy) >= hh - 250 && Math.abs(dy) <= hh + 400));
  if (doorway) return true;
  if (room.shape === 'round') return (dx*dx)/(hw*hw*0.92*0.92) + (dy*dy)/(hh*hh*0.92*0.92) <= 1;
  if (room.shape === 'oval') return (dx*dx)/(hw*hw*0.98*0.98) + (dy*dy)/(hh*hh*0.72*0.72) <= 1;
  if (room.shape === 'corridor') return (Math.abs(dx) <= hw*0.95 && Math.abs(dy) <= 180) || (Math.abs(dx) <= 220 && Math.abs(dy) <= hh*0.95);
  if (room.shape === 'triangle') {
    // Triangle pointe vers le nord ; collision identique au sol visible.
    const halfAtY = hw * ((dy + hh) / (2 * hh));
    return dy >= -hh && dy <= hh && Math.abs(dx) <= halfAtY;
  }
  if (room.shape === 'ring') {
    const outer = (dx*dx)/(hw*hw*0.94*0.94) + (dy*dy)/(hh*hh*0.94*0.94);
    const inner = (dx*dx)/(hw*hw*0.48*0.48) + (dy*dy)/(hh*hh*0.48*0.48);
    return outer <= 1 && inner >= 1;
  }
  return Math.abs(dx) <= hw && Math.abs(dy) <= hh;
}
function squatRoomForPoint(x,y) {
  return SQUAT_ROOMS.find(r => pointInSquatRoomShape(r, x, y)) || null;
}
function squatCorridorForPoint(x,y) {
  for (const d of SQUAT_DOORS) {
    const a = SQUAT_ROOMS[d.a], b = SQUAT_ROOMS[d.b];
    // Porte 2 (salle 2 ronde → salle 3 triangle) : allonger jusqu'au centre du triangle
    // (la forme pointe réduit la zone jouable ; le couloir standard s'arrêtait trop tôt).
    if (d.id === 2) {
      const left = Math.min(a.x, b.x) + SQUAT_ROOM_W / 2 - 180;
      const right = Math.max(a.x, b.x); // jusqu'au centre de la salle triangle
      if (x >= left && x <= right && Math.abs(y - d.y) < 160) return d;
      continue;
    }
    // Porte 3 (salle 3 triangle → salle 4) : couloir long centre→centre
    if (d.id === 3) {
      const top = Math.min(a.y, b.y);
      const bottom = Math.max(a.y, b.y);
      if (y >= top && y <= bottom && Math.abs(x - d.x) < 280) return d;
      continue;
    }
    // Autres couloirs : style d'origine (chevauchement modéré)
    if (d.orientation === 'h') {
      if (x >= Math.min(a.x,b.x)+SQUAT_ROOM_W/2-180 && x <= Math.max(a.x,b.x)-SQUAT_ROOM_W/2+180 && Math.abs(y-d.y) < 130) return d;
    } else {
      if (y >= Math.min(a.y,b.y)+SQUAT_ROOM_H/2-180 && y <= Math.max(a.y,b.y)-SQUAT_ROOM_H/2+180 && Math.abs(x-d.x) < 130) return d;
    }
  }
  return null;
}
function squatPointAllowed(x,y,radius=20) {
  const room=squatRoomForPoint(x,y);
  if (room) return room.id < (state?.squatUnlocked || 1);
  const corridor=squatCorridorForPoint(x,y);
  if (!corridor || !corridor.open) return false;
  return true;
}
function resolveSquatMove(entity,nx,ny,canFly=false) {
  if (!state || state.map!=='squat') return {x:nx,y:ny};
  if (canFly) return {x:nx,y:ny};
  const unlocked = state.squatUnlocked || 1;
  let x=entity.x, y=entity.y;
  const roomX = squatRoomForPoint(nx, y);
  if (roomX) { if (roomX.id < unlocked) x = nx; }
  else { const c = squatCorridorForPoint(nx, y); if (c && c.open) x = nx; }
  const roomY = squatRoomForPoint(x, ny);
  if (roomY) { if (roomY.id < unlocked) y = ny; }
  else { const c = squatCorridorForPoint(x, ny); if (c && c.open) y = ny; }
  return {x,y};
}
function squatDoorApproachDistance(player, door) {
  const room = SQUAT_ROOMS[door.a];
  let thresholdX = door.x, thresholdY = door.y;
  if (door.orientation === 'h') {
    thresholdX = room.x + (SQUAT_ROOMS[door.b].x > room.x ? 1 : -1) * SQUAT_ROOM_W / 2;
  } else {
    thresholdY = room.y + (SQUAT_ROOMS[door.b].y > room.y ? 1 : -1) * SQUAT_ROOM_H / 2;
  }
  return Math.hypot(player.x - thresholdX, player.y - thresholdY);
}
function openNearbySquatDoor(player) {
  if (!state || state.map!=='squat') return false;
  const currentRoom = squatRoomForPoint(player.x, player.y);
  const door = SQUAT_DOORS.find(d => !d.open && d.a === currentRoom?.id && squatDoorApproachDistance(player, d) < 320);
  if (!door) return false;
  const cost=door.id*10;
  const keys=['wood','stone','scrap','fuel','glass'];
  if (keys.some(k=>(state.sharedResources[k]||0)<cost)) {
    if (!door.lastToastTime || state.time-door.lastToastTime>1.5) { showToast(`PORTE ${door.id} · IL FAUT ${cost} DE CHAQUE RESSOURCE`); door.lastToastTime=state.time; }
    return true;
  }
  for (const k of keys) state.sharedResources[k]-=cost;
  door.open=true;
  state.squatUnlocked=Math.max(state.squatUnlocked||1,door.b+1);
  populateSquatRoom(door.b);
  showToast(`PORTE ${door.id} OUVERTE · -${cost} DE CHAQUE RESSOURCE`);
  if (door.id===8) { state.victory=true; state.gameOver=true; endGame(true); showToast('OUVERTURE DE SQUAT · LES 9 SALLES SONT OUVERTES !'); }
  updateUI();
  return true;
}
function populateSquatRoom(idx) {
  if (!state || state.map !== 'squat' || state.squatPopulated?.has(idx)) return;
  if (!state.squatPopulated) state.squatPopulated = new Set();
  state.squatPopulated.add(idx);
  const room=SQUAT_ROOMS[idx];
  const types=['wood','stone','scrap','fuel','glass'];
  let offsets = [[-520,-320],[0,-320],[520,-320],[-520,320],[520,320]];
  if (room.shape === 'triangle') offsets = [[-190,-250],[-120,80],[0,300],[120,80],[190,-250]];
  if (room.shape === 'corridor') offsets = [[-650,0],[-325,0],[0,0],[325,0],[650,0]];
  if (room.shape === 'ring') offsets = [[-550,0],[0,-400],[550,0],[0,400],[-400,-250]];
  types.forEach((type,t)=>{
    const [ox,oy]=offsets[t];
    state.nodes.push({x:room.x+ox,y:room.y+oy,type,amount:(idx+2)*18,cooldown:0,radius:58,assignedWorker:null,roomId:idx});
  });
  // Les deux premières salles servent à l'exploration. Dès la salle 3,
  // on fournit une cabane de chaque type ; chaque salle suivante ajoute
  // une tourelle de salle, sans empiler des dizaines de cabanes.
  if (idx < 2) return;
  const buildingList = ['guardShack', 'shack', 'medicShack', 'treehouse'];
  buildingList.push('treehouse');
  // Bâtiments toujours placés sur les parties réellement praticables.
  let placements = [[-520, -250], [0, -250], [520, -250], [-300, 250], [300, 250]];
  if (room.shape === 'triangle') placements = [[-220,-160],[-110,120],[0,300],[110,120],[220,-160]];
  if (room.shape === 'corridor') placements = [[-650,0],[-325,0],[0,0],[325,0],[650,0]];
  if (room.shape === 'ring') placements = [[-560,0],[0,-410],[560,0],[0,410],[-400,-280]];
  buildingList.forEach((type, n) => {
    const [ox, oy] = placements[n];
    const x = room.x + ox;
    const y = room.y + oy;
    const building = {type,x,y,radius:buildingRadius(type),hp:240,maxHp:240,burning:false,production:0,recruitTimer:0,workerCount:0,guardCount:0,medicCount:0,towerCooldown:0,level:1,ownerId:0,starter:true,squatRoomId:idx,roomTurret:type==='treehouse' && n===4};
    state.buildings.push(building);
    if (type === 'shack') { const w = spawnWorker(x+45,y+60,building); if (w) w.squatRoomId = idx; }
    else if (type === 'guardShack') { const a = spawnAlly(x+45,y+60,building,false); if (a) a.squatRoomId = idx; }
    else if (type === 'medicShack') { const m = spawnMedic(x+45,y+60,building); if (m) m.squatRoomId = idx; }
  });
}

function buildSquatCaches() {
  const floorImg = images.squatFloor;
  const decorImg = images.squatDecor;
  if (!floorImg?.complete || !floorImg.naturalWidth) return false;
  const hasDecor = decorImg?.complete && decorImg.naturalWidth;
  const pad = 40;
  const SCALE = 0.6; // qualité assets illustrés, toujours léger
  squatRoomCaches = [];
  for (const room of SQUAT_ROOMS) {
    const rw = SQUAT_ROOM_W + pad * 2;
    const rh = SQUAT_ROOM_H + pad * 2;
    const off = document.createElement('canvas');
    off.width = Math.ceil(rw * SCALE);
    off.height = Math.ceil(rh * SCALE);
    const o = off.getContext('2d');
    o.scale(SCALE, SCALE);
    // Fond transparent : seule la forme réelle de la salle recouvre le sol/couloir.
    o.clearRect(0, 0, rw, rh);
    // Toutes les surfaces visibles correspondent à la zone réellement praticable.
    // Les anciennes formes ovales/croix laissaient des zones visuellement noires mais traversables.
    const shape = room.shape || 'rect';
    const cx = pad + SQUAT_ROOM_W / 2;
    const cy = pad + SQUAT_ROOM_H / 2;
    o.save();
    o.beginPath();
    if (shape === 'round') {
      o.ellipse(cx, cy, SQUAT_ROOM_W / 2 * 0.92, SQUAT_ROOM_H / 2 * 0.92, 0, 0, Math.PI * 2);
    } else if (shape === 'oval') {
      o.ellipse(cx, cy, SQUAT_ROOM_W / 2 * 0.98, SQUAT_ROOM_H / 2 * 0.72, 0, 0, Math.PI * 2);
    } else if (shape === 'corridor') {
      const hw = SQUAT_ROOM_W / 2 * 0.95, hh = 180;
      const vw = 220, vh = SQUAT_ROOM_H / 2 * 0.95;
      o.rect(cx - hw, cy - hh, hw * 2, hh * 2);
      o.rect(cx - vw, cy - vh, vw * 2, vh * 2);
    } else if (shape === 'triangle') {
      o.moveTo(cx, cy - SQUAT_ROOM_H / 2);
      o.lineTo(cx + SQUAT_ROOM_W / 2, cy + SQUAT_ROOM_H / 2);
      o.lineTo(cx - SQUAT_ROOM_W / 2, cy + SQUAT_ROOM_H / 2);
      o.closePath();
      // Seuil élargi au sud : la pointe du triangle ne doit pas créer de goulot invisible.
      o.rect(cx - 120, cy + SQUAT_ROOM_H / 2 - 5, 240, 180);
    } else if (shape === 'ring') {
      o.ellipse(cx, cy, SQUAT_ROOM_W / 2 * 0.94, SQUAT_ROOM_H / 2 * 0.94, 0, 0, Math.PI * 2);
      o.ellipse(cx, cy, SQUAT_ROOM_W / 2 * 0.48, SQUAT_ROOM_H / 2 * 0.48, 0, 0, Math.PI * 2, true);
    } else {
      o.rect(cx - SQUAT_ROOM_W / 2, cy - SQUAT_ROOM_H / 2, SQUAT_ROOM_W, SQUAT_ROOM_H);
    }
    o.clip(shape === 'ring' ? 'evenodd' : 'nonzero');
    o.drawImage(floorImg, pad, pad, SQUAT_ROOM_W, SQUAT_ROOM_H);
    o.restore();
    // Contours alignés sur la forme réelle de la salle
    o.strokeStyle = '#2a2b29';
    o.lineWidth = 36;
    o.beginPath();
    if (shape === 'round') {
      o.ellipse(cx, cy, SQUAT_ROOM_W / 2 * 0.92, SQUAT_ROOM_H / 2 * 0.92, 0, 0, Math.PI * 2);
    } else if (shape === 'oval') {
      o.ellipse(cx, cy, SQUAT_ROOM_W / 2 * 0.98, SQUAT_ROOM_H / 2 * 0.72, 0, 0, Math.PI * 2);
    } else if (shape === 'corridor') {
      const hw = SQUAT_ROOM_W / 2 * 0.95, hh = 180;
      const vw = 220, vh = SQUAT_ROOM_H / 2 * 0.95;
      o.rect(cx - hw, cy - hh, hw * 2, hh * 2);
      o.rect(cx - vw, cy - vh, vw * 2, vh * 2);
    } else if (shape === 'triangle') {
      o.moveTo(cx, cy - SQUAT_ROOM_H / 2);
      o.lineTo(cx + SQUAT_ROOM_W / 2, cy + SQUAT_ROOM_H / 2);
      o.lineTo(cx - SQUAT_ROOM_W / 2, cy + SQUAT_ROOM_H / 2);
      o.closePath();
      // Seuil élargi au sud : la pointe du triangle ne doit pas créer de goulot invisible.
      o.rect(cx - 120, cy + SQUAT_ROOM_H / 2 - 5, 240, 180);
    } else if (shape === 'ring') {
      o.ellipse(cx, cy, SQUAT_ROOM_W / 2 * 0.94, SQUAT_ROOM_H / 2 * 0.94, 0, 0, Math.PI * 2);
      o.ellipse(cx, cy, SQUAT_ROOM_W / 2 * 0.48, SQUAT_ROOM_H / 2 * 0.48, 0, 0, Math.PI * 2, true);
    } else {
      o.rect(cx - SQUAT_ROOM_W / 2, cy - SQUAT_ROOM_H / 2, SQUAT_ROOM_W, SQUAT_ROOM_H);
    }
    o.stroke();
    if (hasDecor) {
      // Les sprites de décor restent strictement sur le sol praticable : jamais dans le noir extérieur.
      o.save();
      o.beginPath();
      if (shape === 'round') {
        o.ellipse(cx, cy, SQUAT_ROOM_W / 2 * 0.92, SQUAT_ROOM_H / 2 * 0.92, 0, 0, Math.PI * 2);
      } else if (shape === 'oval') {
        o.ellipse(cx, cy, SQUAT_ROOM_W / 2 * 0.98, SQUAT_ROOM_H / 2 * 0.72, 0, 0, Math.PI * 2);
      } else if (shape === 'corridor') {
        const hw = SQUAT_ROOM_W / 2 * 0.95, hh = 180;
        const vw = 220, vh = SQUAT_ROOM_H / 2 * 0.95;
        o.rect(cx - hw, cy - hh, hw * 2, hh * 2);
        o.rect(cx - vw, cy - vh, vw * 2, vh * 2);
      } else if (shape === 'triangle') {
        o.moveTo(cx, cy - SQUAT_ROOM_H / 2);
        o.lineTo(cx + SQUAT_ROOM_W / 2, cy + SQUAT_ROOM_H / 2);
        o.lineTo(cx - SQUAT_ROOM_W / 2, cy + SQUAT_ROOM_H / 2);
        o.closePath();
      } else if (shape === 'ring') {
        o.ellipse(cx, cy, SQUAT_ROOM_W / 2 * 0.94, SQUAT_ROOM_H / 2 * 0.94, 0, 0, Math.PI * 2);
        o.ellipse(cx, cy, SQUAT_ROOM_W / 2 * 0.48, SQUAT_ROOM_H / 2 * 0.48, 0, 0, Math.PI * 2, true);
      } else {
        o.rect(cx - SQUAT_ROOM_W / 2, cy - SQUAT_ROOM_H / 2, SQUAT_ROOM_W, SQUAT_ROOM_H);
      }
      o.clip(shape === 'ring' ? 'evenodd' : 'nonzero');
      const CW = Math.floor(decorImg.naturalWidth / SQUAT_DECOR_COLS);
      const CH = Math.floor(decorImg.naturalHeight / SQUAT_DECOR_ROWS);
      const drawProp = (d) => {
        const col = d.i % SQUAT_DECOR_COLS;
        const row = Math.floor(d.i / SQUAT_DECOR_COLS);
        const sx = col * CW, sy = row * CH;
        const dx = pad + SQUAT_ROOM_W / 2 + d.ox;
        const dy = pad + SQUAT_ROOM_H / 2 + d.oy;
        o.drawImage(decorImg, sx, sy, CW, CH, dx - d.dw / 2, dy - d.dh / 2, d.dw, d.dh);
      };
      for (const d of SQUAT_DECOR_LAYOUT) drawProp(d);
      const extra = SQUAT_DECOR_BY_ROOM[room.id];
      if (extra) for (const d of extra) drawProp(d);
      o.restore();
    }
    o.fillStyle = 'rgba(10,10,9,0.55)';
    o.fillRect(pad + SQUAT_ROOM_W / 2 - 100, pad + 40, 200, 40);
    o.fillStyle = '#e8dcc0';
    o.font = 'bold 26px Orbitron, sans-serif';
    o.textAlign = 'center';
    o.fillText('SALLE ' + (room.id + 1), pad + SQUAT_ROOM_W / 2, pad + 68);
    squatRoomCaches.push({
      canvas: off,
      roomId: room.id,
      x: room.x - SQUAT_ROOM_W / 2 - pad,
      y: room.y - SQUAT_ROOM_H / 2 - pad,
      w: rw, h: rh
    });
  }
  // Couloirs : style d'origine sauf porte 3 (salle 2→3) qui reste longue
  squatCorridorCaches = [];
  for (const d of SQUAT_DOORS) {
    const a = SQUAT_ROOMS[d.a], b = SQUAT_ROOMS[d.b];
    let cx, cy, cw, ch;
    if (d.id === 2) {
      // Couloir horizontal allongé jusqu'au centre de la salle triangle (salle 3)
      cx = Math.min(a.x, b.x) + SQUAT_ROOM_W / 2 - 180;
      cy = d.y - 150;
      cw = Math.max(a.x, b.x) - cx; // s'arrête au centre du triangle
      ch = 300;
    } else if (d.id === 3) {
      // Long couloir vertical salle 3 → 4
      cx = d.x - 240; cy = Math.min(a.y, b.y);
      cw = 480; ch = Math.abs(b.y - a.y);
    } else if (d.orientation === 'h') {
      cx = Math.min(a.x, b.x) + SQUAT_ROOM_W / 2 - 180;
      cy = d.y - 120; cw = Math.abs(b.x - a.x) - SQUAT_ROOM_W + 360; ch = 240;
    } else {
      cx = d.x - 120; cy = Math.min(a.y, b.y) + SQUAT_ROOM_H / 2 - 180;
      cw = 240; ch = Math.abs(b.y - a.y) - SQUAT_ROOM_H + 360;
    }
    const off = document.createElement('canvas');
    off.width = Math.max(1, Math.ceil(cw));
    off.height = Math.max(1, Math.ceil(ch));
    const o = off.getContext('2d');
    o.drawImage(floorImg, 0, 0, floorImg.naturalWidth, floorImg.naturalHeight, 0, 0, cw, ch);
    o.fillStyle = '#1a1b1a';
    if (d.orientation === 'h') {
      o.fillRect(0, 0, cw, 18);
      o.fillRect(0, ch - 18, cw, 18);
    } else {
      o.fillRect(0, 0, 18, ch);
      o.fillRect(cw - 18, 0, 18, ch);
    }
    squatCorridorCaches.push({ canvas: off, doorId: d.id, x: cx, y: cy, w: cw, h: ch });
  }
  squatCacheReady = true;
  return true;
}

function setupSquatMap() {
  SQUAT_DOORS.forEach(d => { d.open = false; delete d.lastToastTime; });
  state.squatUnlocked = 1;
  state.squatPopulated = new Set();
  state.nodes = [];
  state.buildings = [];
  state.workers = [];
  state.allies = [];
  state.medics = [];
  squatCacheReady = false;
  squatRoomCaches = null;
  squatCorridorCaches = null;
  populateSquatRoom(0);
}
/** Spawn point dans les salles ouvertes, prioritaire près du joueur */
function squatWaveSpawnPoint() {
  // Spawn uniquement dans les salles/couloirs ouverts (jamais hors zone jouable)
  const unlocked = Math.max(1, state.squatUnlocked || 1);
  const from = unlocked <= 1 ? 0 : Math.max(0, unlocked - 2);
  const frontier = SQUAT_ROOMS.slice(from, unlocked);
  const room = frontier[Math.floor(Math.random() * frontier.length)] || SQUAT_ROOMS[0];
  const margin = 120;
  for (let attempt = 0; attempt < 40; attempt++) {
    const x = room.x - SQUAT_ROOM_W / 2 + margin + Math.random() * (SQUAT_ROOM_W - 2 * margin);
    const y = room.y - SQUAT_ROOM_H / 2 + margin + Math.random() * (SQUAT_ROOM_H - 2 * margin);
    if (pointInSquatRoomShape(room, x, y)) return { x, y };
  }
  // Fallback centre de salle (toujours valide pour toutes les formes)
  return { x: room.x, y: room.y };
}



// Labyrinthe grand : grille de haies (murs = true). Entrée NORD ↔ sortie SUD.
const MAZE_CELL = 80;
const MAZE_COLS = 61; // impair pour allées centrées
const MAZE_ROWS = 39;
let MAZE_ORIGIN_X = (WORLD_W - MAZE_COLS * MAZE_CELL) / 2;
let MAZE_ORIGIN_Y = (WORLD_H - MAZE_ROWS * MAZE_CELL) / 2;
let mazeGrid = null; // [row][col] true = mur
let mazeExit = null; // { x, y, w, h }
let mazeEntrance = null; // { x, y }

function buildMazeGrid() {
    MAZE_ORIGIN_X = (WORLD_W - MAZE_COLS * MAZE_CELL) / 2;
    MAZE_ORIGIN_Y = (WORLD_H - MAZE_ROWS * MAZE_CELL) / 2;
    const rows = MAZE_ROWS;
    const cols = MAZE_COLS;
    const grid = Array.from({ length: rows }, () => Array(cols).fill(true));
    const carve = (r, c) => {
        if (r < 0 || r >= rows || c < 0 || c >= cols) return;
        grid[r][c] = false;
    };
    // Recursive backtracker sur cellules impaires (labyrinthe parfait dense)
    const stack = [];
    const startR = 1;
    const startC = Math.floor(cols / 2);
    carve(startR, startC);
    stack.push([startR, startC]);
    const dirs = [[0, 2], [0, -2], [2, 0], [-2, 0]];
    while (stack.length) {
        const [r, c] = stack[stack.length - 1];
        const shuffled = dirs.map((d) => d).sort(() => Math.random() - 0.5);
        let carved = false;
        for (const [dr, dc] of shuffled) {
            const nr = r + dr;
            const nc = c + dc;
            if (nr > 0 && nr < rows - 1 && nc > 0 && nc < cols - 1 && grid[nr][nc]) {
                carve(r + (dr >> 1), c + (dc >> 1));
                carve(nr, nc);
                stack.push([nr, nc]);
                carved = true;
                break;
            }
        }
        if (!carved) stack.pop();
    }
    const midC = Math.floor(cols / 2);
    // Salles variées : rondes, ovales, rectangles, couloirs
    const carveRoom = (centerR, centerC, shape) => {
        if (shape === 'round') {
            const rad = 3 + Math.floor(Math.random() * 2);
            for (let r = centerR - rad; r <= centerR + rad; r++) {
                for (let c = centerC - rad; c <= centerC + rad; c++) {
                    if ((r - centerR) * (r - centerR) + (c - centerC) * (c - centerC) <= rad * rad + 0.5) {
                        if (r > 0 && r < rows - 1 && c > 0 && c < cols - 1) carve(r, c);
                    }
                }
            }
        } else if (shape === 'oval') {
            const rx = 4 + Math.floor(Math.random() * 2);
            const ry = 2 + Math.floor(Math.random() * 2);
            for (let r = centerR - ry; r <= centerR + ry; r++) {
                for (let c = centerC - rx; c <= centerC + rx; c++) {
                    if (((r - centerR) / ry) ** 2 + ((c - centerC) / rx) ** 2 <= 1.05) {
                        if (r > 0 && r < rows - 1 && c > 0 && c < cols - 1) carve(r, c);
                    }
                }
            }
        } else if (shape === 'rect') {
            const hw = 3 + Math.floor(Math.random() * 3);
            const hh = 2 + Math.floor(Math.random() * 2);
            for (let r = centerR - hh; r <= centerR + hh; r++) {
                for (let c = centerC - hw; c <= centerC + hw; c++) {
                    if (r > 0 && r < rows - 1 && c > 0 && c < cols - 1) carve(r, c);
                }
            }
        } else if (shape === 'corridor') {
            // Couloir en L ou droit
            const len = 6 + Math.floor(Math.random() * 5);
            const horiz = Math.random() > 0.5;
            for (let i = -len; i <= len; i++) {
                if (horiz) {
                    if (centerC + i > 0 && centerC + i < cols - 1) carve(centerR, centerC + i);
                    if (centerC + i > 0 && centerC + i < cols - 1) carve(centerR + 1, centerC + i);
                } else {
                    if (centerR + i > 0 && centerR + i < rows - 1) carve(centerR + i, centerC);
                    if (centerR + i > 0 && centerR + i < rows - 1) carve(centerR + i, centerC + 1);
                }
            }
            // Branche perpendiculaire
            const branch = 3 + Math.floor(Math.random() * 3);
            for (let i = 0; i <= branch; i++) {
                if (horiz) {
                    if (centerR + i < rows - 1) carve(centerR + i, centerC);
                    if (centerR + i < rows - 1) carve(centerR + i, centerC + 1);
                } else {
                    if (centerC + i < cols - 1) carve(centerR, centerC + i);
                    if (centerC + i < cols - 1) carve(centerR + 1, centerC + i);
                }
            }
        }
    };
    const roomShapes = ['round', 'oval', 'rect', 'corridor', 'round', 'rect', 'oval', 'corridor'];
    const roomCenters = [
        [9, midC], [19, midC], [29, midC],
        [12, 12], [12, cols - 13], [26, 14], [26, cols - 15],
        [19, 20], [19, cols - 21]
    ];
    for (let i = 0; i < roomCenters.length; i++) {
        carveRoom(roomCenters[i][0], roomCenters[i][1], roomShapes[i % roomShapes.length]);
    }
    // Entrée NORD (bord haut)
    for (let c = midC - 1; c <= midC + 1; c++) {
        carve(0, c);
        carve(1, c);
        carve(2, c);
    }
    // Sortie SUD (bord bas) — opposée
    for (let c = midC - 1; c <= midC + 1; c++) {
        carve(rows - 1, c);
        carve(rows - 2, c);
        carve(rows - 3, c);
    }
    // Chemin garanti entrée → sortie sur la colonne centrale (percée progressive)
    for (let r = 0; r < rows; r++) {
        if (r % 2 === 1 || r < 3 || r > rows - 4) carve(r, midC);
    }
    mazeGrid = grid;
    mazeEntrance = {
        x: MAZE_ORIGIN_X + midC * MAZE_CELL + MAZE_CELL / 2,
        y: MAZE_ORIGIN_Y + 1.5 * MAZE_CELL
    };
    mazeExit = {
        x: MAZE_ORIGIN_X + midC * MAZE_CELL + MAZE_CELL / 2,
        y: MAZE_ORIGIN_Y + (rows - 1.2) * MAZE_CELL,
        w: MAZE_CELL * 3.2,
        h: MAZE_CELL * 1.8
    };
    return grid;
}

function worldToMazeCell(x, y) {
    const c = Math.floor((x - MAZE_ORIGIN_X) / MAZE_CELL);
    const r = Math.floor((y - MAZE_ORIGIN_Y) / MAZE_CELL);
    return { r, c };
}

function isMazeWall(x, y, radius = 0) {
    if (!mazeGrid || !state || state.map !== 'maze') return false;
    // Teste plusieurs points autour du rayon pour bloquer proprement
    const samples = radius <= 0
        ? [[x, y]]
        : [
            [x, y],
            [x - radius * 0.7, y],
            [x + radius * 0.7, y],
            [x, y - radius * 0.7],
            [x, y + radius * 0.7]
        ];
    for (const [px, py] of samples) {
        const { r, c } = worldToMazeCell(px, py);
        if (r < 0 || c < 0 || r >= MAZE_ROWS || c >= MAZE_COLS) return true; // hors grille = mur
        if (mazeGrid[r][c]) return true;
    }
    return false;
}

function isMazeOpen(x, y) {
    if (!mazeGrid) return true;
    const { r, c } = worldToMazeCell(x, y);
    if (r < 0 || c < 0 || r >= MAZE_ROWS || c >= MAZE_COLS) return false;
    return !mazeGrid[r][c];
}

function resolveMazeMove(entity, nextX, nextY, canFly = false) {
    if (canFly || !state || state.map !== 'maze') return { x: nextX, y: nextY };
    const radius = entity.radius || 20;
    if (!isMazeWall(nextX, nextY, radius)) return { x: nextX, y: nextY };
    let x = entity.x;
    let y = entity.y;
    if (!isMazeWall(nextX, y, radius)) x = nextX;
    if (!isMazeWall(x, nextY, radius)) y = nextY;
    return { x, y };
}

function randomMazeOpenPoint(margin = 40) {
    if (!mazeGrid) return { x: CAMP_X, y: CAMP_Y };
    for (let i = 0; i < 80; i++) {
        const r = 1 + Math.floor(Math.random() * (MAZE_ROWS - 2));
        const c = 1 + Math.floor(Math.random() * (MAZE_COLS - 2));
        if (!mazeGrid[r][c]) {
            return {
                x: MAZE_ORIGIN_X + c * MAZE_CELL + MAZE_CELL / 2,
                y: MAZE_ORIGIN_Y + r * MAZE_CELL + MAZE_CELL / 2
            };
        }
    }
    return { x: CAMP_X, y: CAMP_Y };
}
const LOCAL_LEADERBOARD_KEY = 'zoneLibre_localLeaderboard_v1';
let modeButtons = [...document.querySelectorAll('.mode-card[data-mode]')];
let mapButtons = [...document.querySelectorAll('.mode-card[data-map]')];
// Snapshot du menu principal (cartes + difficultés) pour pouvoir le restaurer après un game over.
const mainMenuHTML = ui.overlay ? ui.overlay.innerHTML : '';

function refreshMenuButtons() {
    modeButtons = [...document.querySelectorAll('.mode-card[data-mode]')];
    mapButtons = [...document.querySelectorAll('.mode-card[data-map]')];
    ui.start = document.querySelector('#start');
    for (const button of modeButtons) {
        button.addEventListener('click', () => selectStartMode(button.dataset.mode));
    }
    for (const button of mapButtons) {
        button.addEventListener('click', () => selectMap(button.dataset.map));
    }
    ui.start?.addEventListener('click', () => startGame(selectedMode, 'keyboardMouse'));
}

function selectStartMode(mode) {
    if (!GAME_MODES[mode]) return;
    selectedMode = mode;
    for (const button of modeButtons) {
        const selected = button.dataset.mode === mode;
        button.classList.toggle('selected', selected);
        button.setAttribute('aria-pressed', String(selected));
    }
    updateStartButton();
}

function selectMap(map) {
    if (!MAPS[map]) return;
    if (map === 'lycee' && !lyceeUnlocked) {
        showToast('MODE LYCÉE VERROUILLÉ · GAGNEZ UNE PARTIE POUR LE DÉBLOQUER');
        return;
    }
    selectedMap = map;
    for (const button of mapButtons) {
        const selected = button.dataset.map === map;
        button.classList.toggle('selected', selected);
        button.setAttribute('aria-pressed', String(selected));
    }
    updateStartButton();
    updateMapThemeUI();
}

function updateStartButton() {
    const mapLabel = MAPS[selectedMap]?.label || 'CAMP';
    const modeLabel = GAME_MODES[selectedMode]?.label || 'NORMAL';
    ui.start.textContent = `${mapLabel} · ${modeLabel} · COMMENCER`;
}

function readLocalLeaderboard() {
    try {
        const stored = JSON.parse(localStorage.getItem(LOCAL_LEADERBOARD_KEY) || '[]');
        if (!Array.isArray(stored)) return [];
        return stored
            .filter((entry) => entry && Number.isFinite(Number(entry.score)))
            .sort((a, b) => Number(b.score) - Number(a.score) || Number(b.wave || 0) - Number(a.wave || 0))
            .slice(0, 10);
    } catch {
        return [];
    }
}

function leaderboardRows(entries, currentId = null) {
    if (!entries.length) return '<p class="ranking-empty">Aucune partie enregistrée pour l’instant.</p>';
    return entries.slice(0, 5).map((entry, index) => {
        const mapLabel = MAPS[entry.map]?.label || 'CAMP';
        const modeLabel = GAME_MODES[entry.difficulty]?.label || 'NORMAL';
        const players = Math.max(1, Math.min(MAX_PLAYERS, Number(entry.players) || 1));
        const score = Math.max(0, Math.floor(Number(entry.score) || 0)).toLocaleString('fr-FR');
        const current = entry.id === currentId;
        return `<div class="ranking-row${current ? ' current' : ''}"><span class="ranking-place">#${index + 1}</span><span class="ranking-meta">${mapLabel} · ${modeLabel} · ${players} J · V${Math.max(0, Number(entry.wave) || 0)}</span><b>${score}</b></div>`;
    }).join('');
}

function updateLeaderboardPreview() {
    const list = document.querySelector('#local-ranking-list');
    if (!list) return;
    list.innerHTML = leaderboardRows(readLocalLeaderboard());
}

function saveLocalRun() {
    // Le tutoriel sert à apprendre : il ne pollue pas le classement des vraies parties.
    if (state?.difficulty === 'tutorial') {
        const entries = readLocalLeaderboard();
        return { entries, record: null, rank: 0 };
    }
    const record = {
        id: `${Date.now()}-${Math.floor(Math.random() * 1_000_000)}`,
        score: Math.max(0, Math.floor(state.score)),
        wave: state.wave,
        survival: Math.floor(state.survival),
        map: state.map,
        difficulty: state.difficulty,
        players: state.players.length,
        victory: Boolean(state.victory),
        date: new Date().toISOString()
    };
    const entries = [...readLocalLeaderboard(), record]
        .sort((a, b) => Number(b.score) - Number(a.score) || Number(b.wave || 0) - Number(a.wave || 0))
        .slice(0, 10);
    try {
        localStorage.setItem(LOCAL_LEADERBOARD_KEY, JSON.stringify(entries));
    } catch {
        // La partie reste jouable si le navigateur bloque le stockage local.
    }
    return { entries, record, rank: entries.findIndex((entry) => entry.id === record.id) + 1 };
}

function updateMapThemeUI() {
    const lycee = selectedMap === 'lycee';
    const labels = lycee
        ? {
            barricade: ['[B] POUBELLES', '4 bois · 1 ferraille · protection renforcée'],
            shack: ['[H] CDI', '18 bois · 10 ferraille · recrute des collecteurs'],
            guardShack: ['[G] SALLE DE CLASSE', '22 bois · 12 ferraille · 4 pierres'],
            medicShack: ['[N] INFIRMERIE', '20 bois · 12 ferraille · 4 pierres'],
            treehouse: ['[T] VOISINS VÉNÈRES', '26 bois · 16 ferraille · 4 pierres · tirs auto']
        }
        : {
            barricade: ['[B] BARRICADE', '4 bois · 1 ferraille'],
            shack: ['[H] CABANE COLLECTE', '18 bois · 10 ferraille · 2→4 collecteurs'],
            guardShack: ['[G] CABANE GUERRIÈRE', '22 bois · 12 ferraille · 2→4 guerriers'],
            medicShack: ['[N] CABANE MÉDIC', '20 bois · 12 ferraille · 4 pierres'],
            treehouse: ['[T] TOUR ARBORICOLE', '26 bois · 16 ferraille · 4 pierres']
        };
    for (const [type, [title, detail]] of Object.entries(labels)) {
        const button = document.querySelector(`.build[data-build="${type}"]`);
        if (button) button.innerHTML = `${title}<span>${detail}</span>`;
    }
    const lyceeCard = document.querySelector('#map-lycee small');
    if (lyceeCard) lyceeCard.textContent = 'Rue mignonne, maisons et porte de lycée ; défense par deux longues lignes de poubelles.';
    updateLeaderboardPreview();
}

function updateLyceeButton() {
    const btn = document.getElementById('map-lycee');
    if (!btn) return;
    btn.querySelector('strong').textContent = 'LYCÉE';
    btn.querySelector('small').textContent = 'Quartier de rue mignon, porte du lycée et deux longues lignes de poubelles à défendre.';
    btn.classList.remove('locked');
}

function createPlayer(id, x, y) {
    return {
        id,
        label: `JOUEUR ${id + 1}`,
        color: ['#67dfb0', '#75cfff', '#ffb36b', '#e69bff'][id],
        outfitColor: ['#214f43', '#24547a', '#7a4b22', '#66357b'][id],
        outfitAccent: ['#8ff0b0', '#75cfff', '#ffb36b', '#e69bff'][id],
        outfitStyle: id === 0 ? 'gilet' : id === 1 ? 'capuche' : id === 2 ? 'gilet' : 'veste',
        x,
        y,
        radius: 29,
        speed: 285 * MOVEMENT_SPEED_MULTIPLIER,
        hp: PLAYER_MAX_HP,
        maxHp: PLAYER_MAX_HP,
        damageCooldown: 0,
        speedBoostTime: 0,
        invulnerabilityTime: 0,
        permanentInvulnerability: false,
        stun: 0,
        slow: 0,
        blind: 0,
        marked: 0,
        harvest: 0,
        harvestNode: null,
        repairTarget: null,
        repairProgress: 0,
        repairBlocked: false,
        inventory: { wood: 30, scrap: 20, stone: 20, fuel: 0, glass: 0 },
        stats: { policeKilled: 0, resourcesGathered: 0, cabinsRepaired: 0, barricadesRepaired: 0 },
        level: 1,
        nextLevelKills: PLAYER_LEVEL_THRESHOLDS[1],
        chosenPowers: [],
        pendingPowerLevel: null,
        harvestPower: 0,
        cabinDiscount: 0,
        speedPower: 0,
        lifePower: 0,
        weapon: 'slingshot',
        lastWeapon: 'slingshot',
        weaponCooldown: 0,
        craftedWeapons: { slingshot: true, sling: false, molotov: false, barre: false, fireworks: false, policeFlashball: false, policeLbd: false },
        temporaryWeapon: null,
        temporaryWeaponTime: 0,
        temporaryPreviousWeapon: null,
        selectedBuild: null,
        facingX: 1,
        facingY: 0,
        gamepad: null,
        previousBuildButton: false,
        gamepadBuildMenuOpen: false,
        gamepadBuildStickReady: false,
        buildAimDistance: 190,
        suppressGamepadFireUntilRelease: false,
        previousWeaponButton: false,
        previousInteractButton: false,
        previousIgniteButton: false,
        previousCancelButton: false,
        previousUpgradeButton: false,
        arsenalOpen: false,
        arsenalIndex: 0,
        arsenalStickReady: true,
        arsenalNavCooldown: 0,
        prevArsenalDpadRight: false,
        prevArsenalDpadLeft: false,
        prevArsenalDpadDown: false,
        prevArsenalDpadUp: false,
        previousConfirmWeapon: false,
        downed: false,
        downedTimer: 0,
        eliminated: false,
        reviveTarget: null,
        reviveProgress: 0
    };
}

function ensurePlayer(id) {
    if (id < 0 || id >= MAX_PLAYERS) return null;
    // Nouveau joueur : spawn à côté du joueur 1 (position actuelle)
    const anchor = state.players[0] || { x: CAMP_X, y: CAMP_Y + 225 };
    while (state.players.length <= id) {
        const nextId = state.players.length;
        const offsetAngle = (nextId * 1.7) + nextId;
        const ox = Math.cos(offsetAngle) * (40 + nextId * 18);
        const oy = Math.sin(offsetAngle) * (40 + nextId * 18);
        let sx = anchor.x + ox;
        let sy = anchor.y + oy;
        // Labyrinthe : rester sur une case libre près du J1
        if (state.map === 'maze' && isMazeWall(sx, sy, 28)) {
            sx = anchor.x;
            sy = anchor.y;
        }
        const player = createPlayer(nextId, sx, sy);
        if (state.sharedResources) player.inventory = state.sharedResources;
        state.players.push(player);
        if (nextId > 0) showToast(`JOUEUR ${nextId + 1} A REJOINT · SPAWN SUR J1`);
    }
    return state.players[id];
}

function generateResourceNodes() {
    const types = [
        'wood', 'wood', 'wood', 'wood', 'wood', 'wood', 'wood',
        'scrap', 'scrap', 'scrap', 'scrap', 'scrap', 'scrap',
        'stone', 'stone', 'stone', 'stone', 'stone', 'stone',
        'fuel', 'fuel',
        'glass', 'glass', 'glass'
    ];
    for (let index = types.length - 1; index > 0; index--) {
        const swapIndex = Math.floor(Math.random() * (index + 1));
        [types[index], types[swapIndex]] = [types[swapIndex], types[index]];
    }

    const nodes = [];
    for (let index = 0; index < types.length; index++) {
        let position = null;
        for (let attempt = 0; attempt < 1800 && !position; attempt++) {
            const x = 135 + Math.random() * (WORLD_W - 270);
            const y = 135 + Math.random() * (WORLD_H - 270);
            const minNodeGap = attempt < 900 ? 200 : attempt < 1450 ? 165 : 135;
            const tooCloseToCamp = distance({ x, y }, state.player) < 245 || distance({ x, y }, state.core) < 210;
            const tooCloseToBuilding = state.buildings.some((building) =>
                distance({ x, y }, building) < building.radius + 47 + 28
            );
            const insideLyceeBuilding = state.map === 'lycee' && isLyceeBuildingBlocked(x, y, 75);
            const insideMazeWall = state.map === 'maze' && isMazeWall(x, y, 40);
            const insideRiverWater = state.map === 'river' && isInRiverWater(x, y);
            const tooCloseToNode = nodes.some((node) => distance({ x, y }, node) < minNodeGap);
            if (!tooCloseToCamp && !tooCloseToBuilding && !insideLyceeBuilding && !insideMazeWall && !insideRiverWater && !tooCloseToNode) position = { x, y };
        }

        if (!position) {
            // Keep resource generation reliable even on unusually crowded layouts.
            for (let attempt = 0; attempt < 1800 && !position; attempt++) {
                let x, y;
                if (state.map === 'maze') {
                    const p = randomMazeOpenPoint();
                    x = p.x; y = p.y;
                } else {
                    x = 135 + Math.random() * (WORLD_W - 270);
                    y = 135 + Math.random() * (WORLD_H - 270);
                }
                const clearOfBuildings = state.buildings.every((building) =>
                    distance({ x, y }, building) >= building.radius + 47 + 16
                );
                const clearOfLyceeBuildings = state.map !== 'lycee' || !isLyceeBuildingBlocked(x, y, 63);
                const clearOfMaze = state.map !== 'maze' || !isMazeWall(x, y, 40);
                const clearOfNodes = nodes.every((node) => distance({ x, y }, node) >= 105);
                if (clearOfBuildings && clearOfLyceeBuildings && clearOfMaze && clearOfNodes) position = { x, y };
            }
        }

        if (!position) {
            position = state.map === 'maze'
                ? randomMazeOpenPoint()
                : { x: 135 + Math.random() * (WORLD_W - 270), y: 135 + Math.random() * (WORLD_H - 270) };
        }
        nodes.push({
            ...position,
            type: types[index],
            amount: 8 + (index % 4) * 2,
            cooldown: 0,
            radius: 47,
            assignedWorker: null
        });
    }
    return nodes;
}

function resetGame(difficulty = 'normal', map = 'camp') {
    const mode = GAME_MODES[difficulty] ? difficulty : 'normal';
    // Taille monde : camp/rivière/lycée/labyrinthe = taille d'origine ; squat = grand
    if (map === 'squat') {
        WORLD_W = WORLD_W_SQUAT;
        WORLD_H = WORLD_H_SQUAT;
    } else {
        WORLD_W = WORLD_W_CAMP;
        WORLD_H = WORLD_H_CAMP;
    }
    if (map === 'maze') buildMazeGrid();
    else { mazeGrid = null; mazeExit = null; mazeEntrance = null; }
    if (map === 'squat') SQUAT_DOORS.forEach(d => d.open = false);
    // Labyrinthe / squat : pas de longue préparation
    const prep = (map === 'maze' || map === 'squat') ? 0.5 : PREPARATION_DURATION;
    state = {
        difficulty: mode,
        map: map || 'camp',
        time: 0,
        prepTime: prep,
        survival: 0,
        score: 0,
        nextWave: prep,
        wave: 0,
        waveAlert: null,
        bonusVan: null,
        bonusVanNextWave: 4 + Math.floor(Math.random() * 3),
        bonusVanSpawnTime: null,
        players: [createPlayer(0, map === 'squat' ? SQUAT_ROOMS[0].x : CAMP_X, map === 'squat' ? SQUAT_ROOMS[0].y : (map === 'lycee' ? WORLD_H - 420 : CAMP_Y) + (map === 'maze' ? 0 : 225))],
        sharedResources: null,
        powerQueue: [],
        powerChoices: null,
        core: map === 'lycee'
            ? { x: CAMP_X, y: WORLD_H - 280, radius: 140, hp: 480, maxHp: 480, label: 'PORTE DU LYCÉE' }
            : map === 'maze'
                ? { x: CAMP_X, y: CAMP_Y, radius: 80, hp: 9999, maxHp: 9999, label: 'SORTIE' }
                : { x: CAMP_X, y: CAMP_Y, radius: 125, hp: 420, maxHp: 420, label: 'CAMP' },
        nodes: [],
        buildings: [],
        enemies: [],
        weaponDrops: [],
        lootDrops: [],
        allies: [],
        workers: [],
        medics: [],
        battleStats: { policeKilled: {}, medicsFallen: 0, collectorsFallen: 0, warriorsFallen: 0, cabinsBuilt: 0, barricadesBuilt: 0 },
        projectiles: [],
        eggs: [],
        fireZones: [],
        gasZones: [],
        waterZones: [],
        explosionZones: [],
        bloodStains: [],
        particles: [],
        floaters: [],
        paused: false,
        gameOver: false,
        victory: false,
        uiRefreshTimer: 0,
        supportGridTimer: 0,
        supportGrid: new Map(),
        enemyGrid: new Map(),
        allyGrid: new Map(),
        barricadeGrid: new Map(),
        cabinGrid: new Map(),
        barricadeList: [],
        enemySpawnQueue: [],
        lastFrameDt: 0.016,
        tutorial: null
    };
    if (mode === 'tutorial') {
        state.tutorial = { step: 0, shotsFired: 0, killsBefore: 0, waitingOk: false, enteredStep: false, levelsAck: false };
        state.prepTime = 2;
        state.nextWave = 99999; // désactive les vagues normales
        state.wave = 10; // armes avancées débloquées (fronde, molotov, etc.)
    }
    state.sharedResources = state.players[0].inventory;
    for (const player of state.players) player.inventory = state.sharedResources;
    state.player = state.players[0];
    Object.defineProperties(state, {
        resources: { get() { return this.sharedResources; } },
        selectedBuild: { get() { return this.players[0].selectedBuild; }, set(value) { this.players[0].selectedBuild = value; } },
        weapon: { get() { return this.players[0].weapon; }, set(value) { this.players[0].weapon = value; } },
        lastWeapon: { get() { return this.players[0].lastWeapon; }, set(value) { this.players[0].lastWeapon = value; } },
        weaponCooldown: { get() { return this.players[0].weaponCooldown; }, set(value) { this.players[0].weaponCooldown = value; } },
        craftedWeapons: { get() { return this.players[0].craftedWeapons; } },
        repairTarget: { get() { return this.players[0].repairTarget; }, set(value) { this.players[0].repairTarget = value; } },
        repairProgress: { get() { return this.players[0].repairProgress; }, set(value) { this.players[0].repairProgress = value; } },
        repairBlocked: { get() { return this.players[0].repairBlocked; }, set(value) { this.players[0].repairBlocked = value; } }
    });
    if (map === 'maze') {
        // Départ à l'ENTRÉE (nord), sortie à l'opposé (sud)
        const startX = mazeEntrance ? mazeEntrance.x : CAMP_X;
        const startY = mazeEntrance ? mazeEntrance.y : CAMP_Y;
        state.players[0].x = startX;
        state.players[0].y = startY;
        state.player.x = startX;
        state.player.y = startY;
        if (mazeExit) {
            state.core.x = mazeExit.x;
            state.core.y = mazeExit.y;
            state.core.radius = 70;
            state.core.label = 'SORTIE';
        }
        showToast('LABYRINTHE · ENTRÉE NORD → SORTIE SUD · LES FLICS ARRIVENT');
    } else if (map === 'squat') {
        setupSquatMap();
        state.core.x = SQUAT_ROOMS[0].x;
        state.core.y = SQUAT_ROOMS[0].y;
        state.core.label = 'SQUAT';
        showToast('OUVERTURE DE SQUAT · OUVREZ LES 9 SALLES');
    } else if (mode === 'normal' && map !== 'lycee' && map !== 'squat' && map !== 'maze') {
        // Rivière : barricades INSIDE l'île (sinon r>=980 = extérieur → flics ne prennent pas les ponts)
        const innerSafe = map === 'river' ? (RIVER_RING_R - RIVER_WATER_HALF - 80) : null;
        const perimeter = innerSafe
            ? { left: CAMP_X - innerSafe, right: CAMP_X + innerSafe, top: CAMP_Y - innerSafe, bottom: CAMP_Y + innerSafe }
            : { left: 560, right: WORLD_W - 560, top: 560, bottom: WORLD_H - 560 };
        const addStarterBarricade = (x, y) => {
            state.buildings.push({ type: 'barricade', x, y, radius: 65, hp: 300, maxHp: 300, burning: false, production: 0, starter: true, ownerId: 0 });
        };
        const step = map === 'river' ? 130 : 155;
        const horizontalSections = Math.ceil((perimeter.right - perimeter.left) / step);
        for (let index = 0; index <= horizontalSections; index++) {
            const x = perimeter.left + (perimeter.right - perimeter.left) * index / horizontalSections;
            addStarterBarricade(x, perimeter.top);
            addStarterBarricade(x, perimeter.bottom);
        }
        const verticalSections = Math.ceil((perimeter.bottom - perimeter.top) / step);
        for (let index = 1; index < verticalSections; index++) {
            const y = perimeter.top + (perimeter.bottom - perimeter.top) * index / verticalSections;
            addStarterBarricade(perimeter.left, y);
            addStarterBarricade(perimeter.right, y);
        }
    } else if (mode === 'easy' && map !== 'lycee' && map !== 'maze' && map !== 'squat') {
        // Cabanes de départ
        const starterCabins = [
            ['shack', CAMP_X - 400, CAMP_Y - 280], ['shack', CAMP_X + 400, CAMP_Y - 280],
            ['guardShack', CAMP_X - 400, CAMP_Y], ['guardShack', CAMP_X + 400, CAMP_Y],
            ['medicShack', CAMP_X - 400, CAMP_Y + 280], ['medicShack', CAMP_X + 400, CAMP_Y + 280]
        ];
        for (const [type, x, y] of starterCabins) {
            const cabin = {
                type, x, y, radius: buildingRadius(type), hp: 220, maxHp: 220,
                burning: false, production: 0, recruitTimer: 0, workerCount: 0,
                guardCount: 0, medicCount: 0, towerCooldown: 0, level: 1, ownerId: 0
            };
            state.buildings.push(cabin);
            const coreGain = cabinCoreBonus(cabin);
            state.core.maxHp += coreGain;
            state.core.hp += coreGain;
            if (type === 'shack') spawnWorker(x + 34, y + 72, cabin);
            if (type === 'guardShack') spawnAlly(x + 34, y + 72, cabin, false);
            if (type === 'medicShack') spawnMedic(x + 34, y + 72, cabin);
        }
        // Barricades : en rivière, uniquement à l'intérieur de l'île
        const innerSafe = map === 'river' ? (RIVER_RING_R - RIVER_WATER_HALF - 80) : null;
        const perimeter = innerSafe
            ? { left: CAMP_X - innerSafe, right: CAMP_X + innerSafe, top: CAMP_Y - innerSafe, bottom: CAMP_Y + innerSafe }
            : { left: 560, right: WORLD_W - 560, top: 560, bottom: WORLD_H - 560 };
        const addStarterBarricade = (x, y) => {
            state.buildings.push({ type: 'barricade', x, y, radius: 65, hp: 300, maxHp: 300, burning: false, production: 0, starter: true, ownerId: 0 });
        };
        const step = map === 'river' ? 130 : 155;
        const horizontalSections = Math.ceil((perimeter.right - perimeter.left) / step);
        for (let index = 0; index <= horizontalSections; index++) {
            const x = perimeter.left + (perimeter.right - perimeter.left) * index / horizontalSections;
            addStarterBarricade(x, perimeter.top);
            addStarterBarricade(x, perimeter.bottom);
        }
        const verticalSections = Math.ceil((perimeter.bottom - perimeter.top) / step);
        for (let index = 1; index < verticalSections; index++) {
            const y = perimeter.top + (perimeter.bottom - perimeter.top) * index / verticalSections;
            addStarterBarricade(perimeter.left, y);
            addStarterBarricade(perimeter.right, y);
        }
    }

    // Map Lycée : règles selon difficulté
    if (map === 'lycee') {
        const lyceeY = WORLD_H - 280;
        const isHard = mode === 'hard';
        const isEasy = mode === 'easy';

        if (!isHard) {
            // Cabanes de départ (pas en hard)
            const starterCabins = [
                ['shack', CAMP_X - 500, lyceeY - 185], ['shack', CAMP_X + 500, lyceeY - 185],
                ['guardShack', CAMP_X - 720, lyceeY + 25], ['guardShack', CAMP_X + 720, lyceeY + 25],
                ['medicShack', CAMP_X - 250, lyceeY - 5], ['medicShack', CAMP_X + 250, lyceeY - 5],
                ['treehouse', CAMP_X, lyceeY - 150]
            ];
            // Easy : 2× plus de tourelles (voisins vénères)
            if (isEasy) {
                starterCabins.push(
                    ['treehouse', CAMP_X - 350, lyceeY - 220],
                    ['treehouse', CAMP_X + 350, lyceeY - 220]
                );
            }
            for (const [type, x, y] of starterCabins) {
                const cabin = {
                    type, x, y,
                    radius: buildingRadius(type),
                    hp: 240, maxHp: 240,
                    burning: false, production: 0, recruitTimer: 0,
                    workerCount: 0, guardCount: 0, medicCount: 0,
                    towerCooldown: 0, level: 1, ownerId: 0,
                    starter: true
                };
                state.buildings.push(cabin);
                const coreGain = cabinCoreBonus(cabin);
                state.core.maxHp += coreGain;
                state.core.hp += coreGain;
                if (type === 'shack') spawnWorker(x + 34, y + 72, cabin);
                if (type === 'guardShack') spawnAlly(x + 34, y + 72, cabin, false);
                if (type === 'medicShack') spawnMedic(x + 34, y + 72, cabin);
            }

            // Deux rangées de poubelles (pas en hard)
            const barrierRadius = 122;
            const barrierSections = Math.ceil((WORLD_W - 260) / 236);
            const barrierRows = [WORLD_H - 900, WORLD_H - 730];
            for (const y of barrierRows) {
                for (let index = 0; index <= barrierSections; index++) {
                    const x = 130 + (WORLD_W - 260) * index / barrierSections;
                    state.buildings.push({
                        type: 'barricade', x, y, radius: barrierRadius,
                        hp: 380, maxHp: 380, burning: false, production: 0,
                        starter: true, ownerId: 0
                    });
                }
            }
        }

        // ~100 alliés de départ pour le mode Lycée (toutes difficultés, y compris hard)
        for (let i = 0; i < 100; i++) {
            const angle = (i / 100) * Math.PI * 2 + Math.random() * 0.3;
            const dist = 90 + Math.random() * 280;
            const ax = CAMP_X + Math.cos(angle) * dist;
            const ay = lyceeY + Math.sin(angle) * dist * 0.7 - 60;
            spawnAlly(ax, ay, null, i % 4 === 0);
        }
        if (isHard) {
            showToast('HARD · 100 GUERRIERS · PAS DE CONSTRUCTION NI POUBELLES');
        } else if (isEasy) {
            showToast('EASY · 100 ALLIÉS · 3 TOURELLES · 2 LIGNES DE POUBELLES');
        } else {
            showToast('100 ALLIÉS DÉFENDENT LE LYCÉE · 2 LIGNES DE POUBELLES');
        }
    }
    if (map === 'squat') {
        // Les nodes sont déjà placés par setupSquatMap / populateSquatRoom
    } else {
        state.nodes = generateResourceNodes();
    }
    updateCamera();
    updatePointerWorld();
    setArsenalOpen(false);
    setControlsOpen(false);
    updateUI();
}

function resize() {
    const scale = Math.min(innerWidth / W, innerHeight / H);
    canvas.style.width = `${W * scale}px`;
    canvas.style.height = `${H * scale}px`;
}
window.addEventListener('resize', resize);
resize();

function pointerPosition(event) {
    const rect = canvas.getBoundingClientRect();
    return {
        x: (event.clientX - rect.left) * W / rect.width,
        y: (event.clientY - rect.top) * H / rect.height
    };
}

function updatePointerWorld() {
    input.mouseX = camera.x + input.screenMouseX / camera.zoom;
    input.mouseY = camera.y + input.screenMouseY / camera.zoom;
}

const keyboardLayouts = [
    null,
    { up: 'ArrowUp', down: 'ArrowDown', left: 'ArrowLeft', right: 'ArrowRight', interact: 'Enter', fire: 'ControlRight', build: 'KeyV' },
    { up: 'KeyI', down: 'KeyK', left: 'KeyJ', right: 'KeyL', interact: 'KeyO', fire: 'KeyP', build: 'KeyY' },
    { up: 'Numpad8', down: 'Numpad5', left: 'Numpad4', right: 'Numpad6', interact: 'Numpad0', fire: 'NumpadEnter', build: 'NumpadAdd' }
];
const BUILD_TYPES = ['barricade', 'shack', 'guardShack', 'medicShack', 'treehouse'];
const WEAPON_CYCLE_ORDER = ['slingshot', 'sling', 'molotov', 'barre', 'fireworks', 'policeFlashball', 'policeLbd'];

function keyboardSlotForCode(code) {
    return keyboardLayouts.findIndex((layout, index) => index > 0 && layout && Object.values(layout).includes(code));
}

function gamepadButtonPressed(pad, index) {
    return Boolean(pad?.buttons?.[index]?.pressed);
}

function pollGamepads() {
    const pads = [...(navigator.getGamepads?.() || [])]
        .filter(Boolean)
        .sort((a, b) => a.index - b.index);
    const connectedIndices = new Set(pads.map((pad) => pad.index));
    for (const index of gamepadPlayerSlots.keys()) {
        if (!connectedIndices.has(index)) {
            const departedSlot = gamepadPlayerSlots.get(index);
            gamepadPlayerSlots.delete(index);
            gamepadButtonState.delete(index);
            if (departedSlot > 0 && state?.players?.[departedSlot]) {
                state.players[departedSlot].gamepad = null;
                state.players[departedSlot].eliminated = true;
                state.players[departedSlot].hp = 0;
            }
        }
    }

    const usedPlayerSlots = new Set(gamepadPlayerSlots.values());
    const padsByPlayer = new Map();
    for (const pad of pads) {
        let playerId = gamepadPlayerSlots.get(pad.index);
        if (playerId === undefined) {
            // Partie clavier/souris : J1 est réservé, les manettes commencent à J2.
            // Partie lancée à la manette : la première manette peut être J1.
            const preferred = (primaryInputMode === 'keyboardMouse' ? [1, 2, 3] : [0, 1, 2, 3])
                .filter((slot) => slot < MAX_PLAYERS);
            playerId = preferred.find((slot) => !usedPlayerSlots.has(slot));
            if (playerId === undefined) continue;
            gamepadPlayerSlots.set(pad.index, playerId);
            usedPlayerSlots.add(playerId);
            // La connexion seule ne crée pas de joueur : il faut une action volontaire.
        }
        const intentionalButton = pad.buttons.some((button) => button?.pressed);
        if (playerId > 0 && intentionalButton && state?.players) ensurePlayer(playerId);
        padsByPlayer.set(playerId, pad);
    }

    if (state?.powerChoices) {
        const chooserPad = padsByPlayer.get(state.powerChoices.playerId);
        if (chooserPad) {
            const powerIndex = gamepadButtonPressed(chooserPad, 0) ? 0 : gamepadButtonPressed(chooserPad, 2) ? 1 : gamepadButtonPressed(chooserPad, 3) ? 2 : -1;
            const previous = powerChoiceButtonState.get(chooserPad.index) ?? -1;
            if (powerIndex >= 0 && powerIndex !== previous) {
                const key = state.powerChoices.choices[powerIndex];
                chooseCurrentPower(key);
            }
            powerChoiceButtonState.set(chooserPad.index, powerIndex);
        }
    } else {
        powerChoiceButtonState.clear();
    }

    if (state?.players) {
        for (const player of state.players) {
            if (!padsByPlayer.has(player.id) && player.gamepad) {
                player.previousBuildButton = false;
                player.gamepadBuildMenuOpen = false;
                player.gamepadBuildStickReady = false;
                player.suppressGamepadFireUntilRelease = false;
                player.previousWeaponButton = false;
                player.previousInteractButton = false;
                player.previousIgniteButton = false;
                player.previousCancelButton = false;
                player.previousUpgradeButton = false;
            }
            player.gamepad = padsByPlayer.get(player.id) || null;
        }
    }

    let startRequested = false;
    let pauseRequested = false;
    let modeLeftRequested = false;
    let modeRightRequested = false;
    let mapUpRequested = false;
    let mapDownRequested = false;
    // Menu : lire aussi les pads non encore mappés (solo manette avant partie)
    const menuPads = pads.length ? pads : [...padsByPlayer.values()];
    for (const pad of menuPads) {
        const index = pad.index;
        const previous = gamepadButtonState.get(index) || { confirm: false, menu: false, modeLeft: false, modeRight: false, modeUp: false, modeDown: false };
        const confirm = gamepadButtonPressed(pad, 0) || gamepadButtonPressed(pad, 9); // Croix ou Start
        const menu = gamepadButtonPressed(pad, 9);
        const modeLeft = gamepadButtonPressed(pad, 14) || (state?.paused && (pad.axes?.[0] || 0) < -0.55);
        const modeRight = gamepadButtonPressed(pad, 15) || (state?.paused && (pad.axes?.[0] || 0) > 0.55);
        const modeUp = gamepadButtonPressed(pad, 12) || (state?.paused && (pad.axes?.[1] || 0) < -0.55);
        const modeDown = gamepadButtonPressed(pad, 13) || (state?.paused && (pad.axes?.[1] || 0) > 0.55);
        // En menu, Croix / Start lance ; en jeu Start = pause
        if (!running && !state?.gameOver) {
            if (confirm && !previous.confirm) startRequested = true;
        } else {
            if (gamepadButtonPressed(pad, 0) && !previous.confirm) startRequested = true;
            if (menu && !previous.menu) pauseRequested = true;
        }
        if (modeLeft && !previous.modeLeft) modeLeftRequested = true;
        if (modeRight && !previous.modeRight) modeRightRequested = true;
        if (modeUp && !previous.modeUp) mapUpRequested = true;
        if (modeDown && !previous.modeDown) mapDownRequested = true;
        gamepadButtonState.set(index, {
            confirm: gamepadButtonPressed(pad, 0) || gamepadButtonPressed(pad, 9),
            menu,
            modeLeft,
            modeRight,
            modeUp,
            modeDown
        });
    }
    if (!running && !state?.gameOver) {
        const modes = Object.keys(GAME_MODES);
        const maps = Object.keys(MAPS);
        if (modeLeftRequested || modeRightRequested) {
            const direction = modeRightRequested ? 1 : -1;
            const current = modes.indexOf(selectedMode);
            selectStartMode(modes[(current + direction + modes.length) % modes.length]);
        }
        if (mapUpRequested || mapDownRequested) {
            const direction = mapDownRequested ? 1 : -1;
            const current = maps.indexOf(selectedMap);
            const next = maps[(current + direction + maps.length) % maps.length];
            selectMap(next);
            showToast(`CARTE · ${MAPS[next]?.label || next}`);
        }
        if (startRequested) {
            startGame(selectedMode, 'gamepad');
            // Manettes déjà mappées : J1 = 1re manette, J2+ = suivantes
            for (const [playerId, pad] of padsByPlayer) {
                if (playerId > 0 && pad.buttons.some((button) => button?.pressed)) ensurePlayer(playerId);
            }
            // Ré-assigner les pads aux joueurs après reset
            for (const player of state.players) {
                player.gamepad = padsByPlayer.get(player.id) || null;
            }
            const n = Math.max(1, state.players.length);
            showToast(n > 1 ? `${n} JOUEURS PRÊTS` : 'J1 MANETTE · CROIX POUR JOUER');
        }
    } else if (startRequested && state.gameOver) {
        startGame(state.difficulty, primaryInputMode === 'gamepad' ? 'gamepad' : 'keyboardMouse');
    } else if (state?.paused) {
        // Pendant le choix de pouvoir de niveau, ne pas traiter le menu pause
        // (sinon ReferenceError + fermeture intempestive).
        if (!state.powerChoices) {
            // Navigation pause : flèches / stick pour choisir, Croix pour valider
            // mapUp/mapDown = même stick/D-pad que modeUp/modeDown (variables déclarées plus haut)
            if (!state.pauseMenuIndex) state.pauseMenuIndex = 0;
            if (modeLeftRequested || mapUpRequested) state.pauseMenuIndex = 0; // Reprendre
            if (modeRightRequested || mapDownRequested) state.pauseMenuIndex = 1; // Menu principal
            const resumeBtn = document.querySelector('#resume');
            const menuBtn = document.querySelector('#pause-main-menu');
            if (resumeBtn) resumeBtn.classList.toggle('active', state.pauseMenuIndex === 0);
            if (menuBtn) menuBtn.classList.toggle('active', state.pauseMenuIndex === 1);
            if (startRequested) {
                if (state.pauseMenuIndex === 1) {
                    setPaused(false);
                    returnToMainMenu();
                } else {
                    setPaused(false);
                }
            }
        }
    } else if (pauseRequested && running && !state.gameOver) {
        setPaused(!state.paused);
        if (state.paused) state.pauseMenuIndex = 0;
    }
}

function reassignGamepadsForKeyboardPrimary() {
    const pads = [...(navigator.getGamepads?.() || [])]
        .filter(Boolean)
        .sort((a, b) => a.index - b.index);
    gamepadPlayerSlots.clear();
    gamepadButtonState.clear();
    const slots = [1, 2, 3];
    for (let i = 0; i < Math.min(pads.length, slots.length); i++) {
        gamepadPlayerSlots.set(pads[i].index, slots[i]);
    }
}

function startGame(mode = selectedMode, inputSource = 'keyboardMouse') {
    const difficulty = GAME_MODES[mode] ? mode : selectedMode;
    primaryInputMode = inputSource === 'gamepad' ? 'gamepad' : 'keyboardMouse';
    if (primaryInputMode === 'keyboardMouse') reassignGamepadsForKeyboardPrimary();
    selectStartMode(difficulty);
    const mapForGame = difficulty === 'tutorial' ? 'camp' : selectedMap;
    resetGame(difficulty, mapForGame);
    running = true;
    ui.overlay.classList.add('hidden');
    unlockAudio();
    window.ProgressLogger?.logProgress('game_started', { preparationSeconds: 0, difficulty, map: mapForGame });
    if (difficulty === 'tutorial' && state.tutorial) {
        beginTutorialStep(0);
    }
}

function updateCamera(dt = 0.016) {
    const active = state.players.filter((player) => player.hp > 0);
    if (!active.length) {
        camera.zoom = 1;
        camera.x = Math.max(0, Math.min(WORLD_W - W, state.player.x - W / 2));
        camera.y = Math.max(0, Math.min(WORLD_H - H, state.player.y - H / 2));
        return;
    }

    // SOLO : comportement historique, toujours zoom 1:1.
    // Le zoom coop n'est activé que lorsqu'au moins deux joueurs vivants sont réellement présents.
    if (active.length < 2) {
        camera.zoom = 1;
        const focus = active[0];
        camera.x = Math.max(0, Math.min(WORLD_W - W, focus.x - W / 2));
        camera.y = Math.max(0, Math.min(WORLD_H - H, focus.y - H / 2));
        return;
    }

    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (const player of active) {
        minX = Math.min(minX, player.x);
        maxX = Math.max(maxX, player.x);
        minY = Math.min(minY, player.y);
        maxY = Math.max(maxY, player.y);
    }
    const spanX = maxX - minX;
    const spanY = maxY - minY;
    const wantedZoom = Math.min(
        1,
        W / Math.max(1, spanX + CAMERA_COOP_MARGIN * 2),
        H / Math.max(1, spanY + CAMERA_COOP_MARGIN * 2)
    );
    const targetZoom = Math.max(CAMERA_MIN_ZOOM, Math.min(CAMERA_MAX_ZOOM, wantedZoom));
    // Petit lissage uniquement en coop : le solo reste strictement à 1:1.
    const zoomLerp = 1 - Math.exp(-Math.max(0.001, dt) * 8);
    camera.zoom += (targetZoom - camera.zoom) * zoomLerp;
    if (Math.abs(camera.zoom - targetZoom) < 0.001) camera.zoom = targetZoom;

    const viewW = W / camera.zoom;
    const viewH = H / camera.zoom;
    const focusX = (minX + maxX) * 0.5;
    const focusY = (minY + maxY) * 0.5;
    camera.x = Math.max(0, Math.min(Math.max(0, WORLD_W - viewW), focusX - viewW / 2));
    camera.y = Math.max(0, Math.min(Math.max(0, WORLD_H - viewH), focusY - viewH / 2));
}

window.addEventListener('keydown', (event) => {
    const key = event.key.toLowerCase();
    input.keys.add(key);
    input.codes.add(event.code);
    if (event.code === 'Space' || event.code === 'Tab') event.preventDefault();
    // Le multijoueur est exclusivement à la manette : aucune touche ne crée J2-J4.
    const playerSlot = -1;
    if (state?.powerChoices && !event.repeat) {
        const powerKeys = { Digit1: 0, Digit2: 1, Digit3: 2, Numpad1: 0, Numpad2: 1, Numpad3: 2 };
        if (powerKeys[event.code] !== undefined) {
            event.preventDefault();
            const key = state.powerChoices.choices[powerKeys[event.code]];
            if (key) { state.powerChoices.selected = key; renderPowerChoice(); }
            return;
        }
        if (event.code === 'Enter' || event.code === 'NumpadEnter') {
            event.preventDefault();
            if (state.powerChoices.selected) confirmCurrentPower();
            return;
        }
        if (event.code === 'Escape') {
            event.preventDefault();
            showToast('CHOISISSEZ UN POUVOIR OU UTILISEZ LE BOUTON PASSER');
            return;
        }
    }
    if (state?.tutorial?.waitingOk && !event.repeat) {
        if (event.code === 'Enter' || event.code === 'NumpadEnter' || event.code === 'Space') {
            event.preventDefault();
            dismissTutorialModal();
            return;
        }
    }
    if (!running || state.gameOver) {
        if (!running && !state.gameOver && ['1', '2', '3'].includes(event.key)) {
            const modes = ['easy', 'normal', 'hard'];
            selectStartMode(modes[Number(event.key) - 1]);
        }
        return;
    }
    if (event.code === 'Backquote' || key === 'p' || event.code === 'Escape') {
        event.preventDefault();
        if (!event.repeat) togglePause();
        return;
    }
    if (state.paused) return;
    if (event.repeat) return;
    if (event.code === 'Tab') {
        setArsenalOpen(!arsenalOpen);
        return;
    }
    if (key === 'b') selectBuild('barricade');
    if (key === 'h') selectBuild('shack');
    if (key === 'g') selectBuild('guardShack');
    if (key === 'n') selectBuild('medicShack');
    if (key === 't') selectBuild('treehouse');
    if (key === 'u') upgradeNearestCabin();
    if (key === 'f') igniteNearest();
    if (key === 'm') setControlsOpen(!controlsOpen);
    if (['Digit1', 'Numpad1'].includes(event.code)) selectWeaponHotkey('slingshot');
    if (['Digit2', 'Numpad2'].includes(event.code)) selectWeaponHotkey('sling');
    if (['Digit3', 'Numpad3'].includes(event.code)) selectWeaponHotkey('molotov');
    if (['Digit4', 'Numpad4'].includes(event.code)) selectWeaponHotkey('barre');
    if (['Digit5', 'Numpad5'].includes(event.code)) selectWeaponHotkey('fireworks');
});
window.addEventListener('keyup', (event) => {
    input.keys.delete(event.key.toLowerCase());
    input.codes.delete(event.code);
});
canvas.addEventListener('pointerenter', () => {
    input.pointerInside = true;
});
canvas.addEventListener('pointerleave', () => {
    input.pointerInside = false;
    input.pointerDown = false;
});
canvas.addEventListener('pointermove', (event) => {
    input.pointerInside = true;
    const position = pointerPosition(event);
    input.screenMouseX = position.x;
    input.screenMouseY = position.y;
    updatePointerWorld();
});
canvas.addEventListener('pointerdown', (event) => {
    if (!running || state.gameOver || state.paused) return;
    // Clic droit (joueur 1) : fermer le mode construction
    if (event.button === 2) {
        if (state.selectedBuild) {
            selectBuild(null);
            showToast('MODE CONSTRUCTION FERMÉ');
        }
        event.preventDefault();
        return;
    }
    input.pointerDown = true;
    const position = pointerPosition(event);
    input.screenMouseX = position.x;
    input.screenMouseY = position.y;
    updatePointerWorld();
    if (state.selectedBuild) {
        placeBuilding();
        input.pointerDown = false;
    } else {
        throwStone();
    }
});
canvas.addEventListener('contextmenu', (event) => {
    event.preventDefault();
});
window.addEventListener('pointerup', () => { input.pointerDown = false; });
window.addEventListener('pointercancel', () => { input.pointerDown = false; });

function positionBuildBarOutsideGame() {
    const bar = document.getElementById('buildbar');
    if (!bar) return;
    const canvasRect = canvas.getBoundingClientRect();
    const barWidth = 148;
    const gap = 10;
    // Si le viewport offre une marge à droite du canvas, on y place le rail.
    // Sinon il reste collé au bord droit : il ne recouvre jamais le terrain.
    const outsideLeft = canvasRect.right + gap;
    if (outsideLeft + barWidth <= window.innerWidth - 4) {
        bar.style.left = `${outsideLeft}px`;
        bar.style.right = 'auto';
    } else {
        bar.style.left = 'auto';
        bar.style.right = '8px';
    }
}

window.addEventListener('resize', positionBuildBarOutsideGame);
window.addEventListener('fullscreenchange', positionBuildBarOutsideGame);
requestAnimationFrame(positionBuildBarOutsideGame);

let clickableCabinConstruction = false;
for (const button of document.querySelectorAll('.build')) {
    button.addEventListener('click', () => {
        if (!clickableCabinConstruction) return;
        if (!state || state.gameOver || state.paused) return;
        selectBuild(button.dataset.build);
    });
}

for (const button of ui.weaponButtons) {
    button.addEventListener('pointerdown', (event) => {
        if (!arsenalOpen) return;
        event.preventDefault();
        event.stopPropagation();
    });
    button.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        if (!arsenalOpen) return;
        const type = button.dataset.weapon;
        if (!type) return;
        // Dans l'arsenal, cliquer une arme la fabrique si elle est disponible,
        // ou l'équipe si elle a déjà été débloquée. Hors arsenal, même comportement.
        const player = state?.players?.[0] || state?.player;
        if (!player || !weapons[type]) return;
        if (player.craftedWeapons?.[type]) {
            player.weapon = type;
            player.lastWeapon = type;
            player.selectedBuild = null;
            if (player.id === 0) selectWeapon(type);
            showToast(`ARME ÉQUIPÉE : ${weapons[type]?.label || type}`);
        } else {
            craftWeapon(type, player);
        }
    });
}
// Options de commandes accessibles depuis Pause.
const commandOptionsPanel = document.getElementById('command-options');
const commandOptionsButton = document.getElementById('open-command-options');
const clickableConstructionCheckbox = document.getElementById('clickable-cabin-construction');
commandOptionsButton?.addEventListener('click', () => {
    const opening = commandOptionsPanel?.classList.contains('hidden');
    commandOptionsPanel?.classList.toggle('hidden', !opening);
    commandOptionsButton.setAttribute('aria-expanded', String(Boolean(opening)));
});
clickableConstructionCheckbox?.addEventListener('change', () => {
    clickableCabinConstruction = clickableConstructionCheckbox.checked;
    document.querySelectorAll('.build').forEach(button => {
        button.style.pointerEvents = clickableCabinConstruction ? 'auto' : 'none';
        button.style.cursor = clickableCabinConstruction ? 'pointer' : 'default';
        button.setAttribute('aria-disabled', String(!clickableCabinConstruction));
    });
    showToast(clickableCabinConstruction ? 'CONSTRUCTION CLIQUABLE ACTIVÉE' : 'CONSTRUCTION CLIQUABLE DÉSACTIVÉE');
});
ui.resume?.addEventListener('click', () => setPaused(false));
ui.tutorialOk?.addEventListener('click', () => dismissTutorialModal());
document.querySelector('#pause-main-menu')?.addEventListener('click', () => {
    setPaused(false);
    showMainMenu();
    showToast('MENU PRINCIPAL');
});
ui.returnMenu?.addEventListener('click', () => returnToMainMenu());
for (const button of modeButtons) {
    button.addEventListener('click', () => selectStartMode(button.dataset.mode));
}
for (const button of mapButtons) {
    button.addEventListener('click', () => selectMap(button.dataset.map));
}
selectStartMode(selectedMode);
selectMap(selectedMap);
updateLyceeButton();
ui.start.addEventListener('click', () => startGame(selectedMode, 'keyboardMouse'));
document.querySelector('#mute').addEventListener('click', (event) => {
    muted = !muted;
    music.muted = muted;
    buildSound.muted = muted;
    event.currentTarget.textContent = muted ? '×' : '♪';
});

function updateFullscreenButton() {
    const active = document.fullscreenElement === document.querySelector('#game-container');
    if (!ui.fullscreen) return;
    ui.fullscreen.textContent = active ? '×' : '⛶';
    ui.fullscreen.setAttribute('aria-label', active ? 'Quitter le plein écran' : 'Passer en plein écran');
    ui.fullscreen.title = active ? 'Quitter le plein écran' : 'Plein écran';
}

ui.fullscreen?.addEventListener('click', async () => {
    const container = document.querySelector('#game-container');
    try {
        if (document.fullscreenElement) {
            await document.exitFullscreen();
        } else {
            await container.requestFullscreen();
        }
    } catch {
        showToast('PLEIN ÉCRAN NON DISPONIBLE DANS CE NAVIGATEUR');
    }
});
document.addEventListener('fullscreenchange', updateFullscreenButton);
updateFullscreenButton();

function unlockAudio() {
    audioContext ??= new AudioContext();
    audioContext.resume();
    if (!muted) music.play().catch(() => {});
}

function tone(frequency, duration, type = 'sine', volume = 0.04) {
    if (muted || !audioContext) return;
    const oscillator = audioContext.createOscillator();
    const gain = audioContext.createGain();
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime);
    gain.gain.setValueAtTime(volume, audioContext.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + duration);
    oscillator.connect(gain).connect(audioContext.destination);
    oscillator.start();
    oscillator.stop(audioContext.currentTime + duration);
}

function distance(a, b) {
    if (!a || !b || !Number.isFinite(a.x) || !Number.isFinite(a.y) || !Number.isFinite(b.x) || !Number.isFinite(b.y)) {
        return Infinity;
    }
    return Math.hypot(a.x - b.x, a.y - b.y);
}

function formatWeaponCost(cost) {
    const text = Object.entries(cost || {})
        .map(([key, amount]) => `${amount} ${resourceInfo[key]?.short || key}`)
        .join(' + ');
    return text || 'GRATUIT';
}

function setArsenalOpen(open) {
    arsenalOpen = open;
    ui.arsenal.classList.toggle('hidden', !open);
    ui.arsenal.setAttribute('aria-hidden', String(!open));
    ui.arsenalToggle.setAttribute('aria-expanded', String(open));
}

function setControlsOpen(open) {
    controlsOpen = open;
    ui.controls?.classList.toggle('hidden', !open);
    ui.controls?.setAttribute('aria-hidden', String(!open));
    ui.controlsToggle?.setAttribute('aria-expanded', String(open));
}

function setPaused(paused) {
    if (!running || state.gameOver) return;
    // En tutoriel, l’écran d’objectif bloque déjà le jeu : ne pas ouvrir la pause classique par-dessus.
    if (state.tutorial?.waitingOk) {
        if (!paused) dismissTutorialModal();
        return;
    }
    state.paused = paused;
    input.pointerDown = false;
    ui.pauseOverlay?.classList.toggle('hidden', !paused);
    ui.pauseOverlay?.setAttribute('aria-hidden', String(!paused));
    if (paused) {
        music.pause();
    } else {
        lastTime = performance.now();
        if (!muted) music.play().catch(() => {});
    }
}

function togglePause() {
    setPaused(!state.paused);
}

function showMainMenu() {
    running = false;
    if (state) {
        state.paused = false;
        state.gameOver = false;
        if (state.tutorial) state.tutorial.waitingOk = false;
    }
    input.pointerDown = false;
    input.keys.clear();
    input.codes.clear();
    setArsenalOpen(false);
    setControlsOpen(false);
    ui.pauseOverlay?.classList.add('hidden');
    ui.pauseOverlay?.setAttribute('aria-hidden', 'true');
    ui.tutorialOverlay?.classList.add('hidden');
    ui.tutorialOverlay?.setAttribute('aria-hidden', 'true');
    if (ui.overlay && mainMenuHTML) {
        ui.overlay.classList.remove('menu-preparing');
        ui.overlay.dataset.menuInitialized = '';
        ui.overlay.innerHTML = mainMenuHTML;
        attachP2PMenuListeners();
        refreshMenuButtons();
        selectStartMode(selectedMode);
        selectMap(selectedMap === 'lycee' && !lyceeUnlocked ? 'camp' : selectedMap);
        updateLyceeButton();
        updateLeaderboardPreview();
    }
    ui.overlay?.classList.remove('hidden');
    music.pause();
}

function returnToMainMenu() {
    // Accessible depuis la pause OU après un game over (running peut être false).
    if (!state && !ui.overlay) return;
    showMainMenu();
    showToast('MENU PRINCIPAL · CHOISISSEZ UNE CARTE');
}

function selectBuild(type) {
    if (type) {
        if (state.selectedBuild === type) {
            state.selectedBuild = null;
            state.weapon = state.lastWeapon || 'slingshot';
        } else {
            if (state.weapon) state.lastWeapon = state.weapon;
            state.selectedBuild = type;
        }
    } else {
        state.selectedBuild = null;
        state.weapon = state.lastWeapon || 'slingshot';
    }
    for (const button of document.querySelectorAll('.build')) {
        button.classList.toggle('active', button.dataset.build === state.selectedBuild);
    }
    updateUI();
}

function selectWeapon(type) {
    if (!type) {
        selectBuild(null);
        return;
    }
    if (!state.craftedWeapons[type]) {
        if (weapons[type]?.wave > state.wave) showToast(`DÉBLOQUÉ À LA VAGUE ${weapons[type].wave}`);
        else showToast('FABRIQUEZ CETTE ARME À L’ATELIER');
        return;
    }
    state.weapon = type;
    state.lastWeapon = type;
    state.selectedBuild = null;
    for (const button of document.querySelectorAll('.build')) button.classList.remove('active');
    updateUI();
}

function selectWeaponHotkey(type) {
    if (state.craftedWeapons[type]) {
        selectWeapon(type);
        return;
    }
    if (state.wave < weapons[type].wave) {
        selectWeapon(type);
        return;
    }
    craftWeapon(type);
}

function cyclePlayerWeapon(player) {
    const available = WEAPON_CYCLE_ORDER.filter((type) => player.craftedWeapons[type]);
    if (!available.length) return;
    const current = available.indexOf(player.weapon);
    const nextWeapon = available[(current + 1 + available.length) % available.length];
    if (nextWeapon === player.weapon) {
        const cancelledBuild = Boolean(player.selectedBuild);
        player.selectedBuild = null;
        if (player.id === 0 && cancelledBuild) {
            for (const button of document.querySelectorAll('.build')) button.classList.remove('active');
        }
        if (cancelledBuild) updateUI();
        showToast(cancelledBuild
            ? `${player.label} · ${weapons[nextWeapon].label} · MODE COMBAT`
            : `${player.label} · ${weapons[nextWeapon].label} · ARME UNIQUE · FABRIQUEZ-EN D’AUTRES À L’ATELIER`);
        return;
    }
    player.weapon = nextWeapon;
    player.lastWeapon = nextWeapon;
    player.selectedBuild = null;
    if (player.id === 0) {
        for (const button of document.querySelectorAll('.build')) button.classList.remove('active');
    }
    updateUI();
    showToast(`${player.label} · ARME ÉQUIPÉE : ${weapons[nextWeapon].label} · △ ARME SUIVANTE`);
}

function craftWeapon(type, player = state.player) {
    if (!weapons[type] || !player) return false;
    if (player.craftedWeapons[type]) {
        player.weapon = type;
        player.lastWeapon = type;
        if (player.id === 0) selectWeapon(type);
        return true;
    }
    const weapon = weapons[type];
    if (state.wave < weapon.wave) {
        showToast(`${player.label} · VAGUE ${weapon.wave} REQUISE`);
        return false;
    }
    const craftCost = weapon.craftCost || weapon.cost;
    const inv = player.inventory;
    const canCraft = Object.entries(craftCost).every(([key, amount]) => (inv[key] || 0) >= amount);
    if (!canCraft) {
        showToast(`${player.label} · RESSOURCES INSUFFISANTES`);
        return false;
    }
    for (const [key, amount] of Object.entries(craftCost)) inv[key] -= amount;
    player.craftedWeapons[type] = true;
    player.weapon = type;
    player.lastWeapon = type;
    if (player.id === 0) selectWeapon(type);
    buildSound.currentTime = 0;
    if (!muted) buildSound.play().catch(() => {});
    showToast(`${player.label} · ${weapon.label} FABRIQUÉ`);
    state.score += 40;
    return true;
}

function buildingCost(type) {
    return {
        barricade: { wood: 4, scrap: 1 },
        shack: { wood: 18, scrap: 10 },
        guardShack: { wood: 22, scrap: 12, stone: 4 },
        medicShack: { wood: 20, scrap: 12, stone: 4 },
        treehouse: { wood: 26, scrap: 16, stone: 4 }
    }[type] || {};
}

function buildingRadius(type) {
    if (state?.map === 'lycee' && type === 'barricade') return 122;
    return type === 'barricade' ? 65 : type === 'treehouse' ? 100 : 86;
}

function buildingDisplayName(type) {
    if (state?.map === 'lycee') {
        return {
            barricade: 'POUBELLES',
            shack: 'CDI',
            guardShack: 'SALLE DE CLASSE',
            medicShack: 'INFIRMERIE',
            treehouse: 'VOISINS VÉNÈRES'
        }[type] || 'CONSTRUCTION';
    }
    return {
        barricade: 'BARRICADE',
        shack: 'CABANE COLLECTE',
        guardShack: 'CABANE GUERRIÈRE',
        medicShack: 'CABANE MÉDIC',
        treehouse: 'TOUR ARBORICOLE'
    }[type] || 'CONSTRUCTION';
}

function isCabin(type) {
    return type === 'shack' || type === 'guardShack' || type === 'medicShack' || type === 'treehouse';
}

function getCabinStats(type, level = 1) {
    const tier = Math.max(1, Math.min(CABIN_MAX_LEVEL, level || 1));
    if (type === 'shack') {
        return {
            workers: WORKERS_PER_SHACK + tier - 1,
            recruitTime: Math.max(5.5, WORKER_RECRUIT_TIME - (tier - 1) * 1.5),
            workerSpeed: 106 * MOVEMENT_SPEED_MULTIPLIER + (tier - 1) * 28,
            harvestTime: Math.max(0.42, WORKER_HARVEST_TIME - (tier - 1) * 0.16)
        };
    }
    if (type === 'guardShack') {
        return {
            guards: GUARDS_PER_SHACK + tier - 1,
            recruitTime: Math.max(8, GUARD_RECRUIT_TIME - (tier - 1) * 1.5),
            damage: 18 + (tier - 1) * 9,
            range: 285 + (tier - 1) * 35,
            attackInterval: Math.max(0.72, 1.05 - (tier - 1) * 0.14),
            speed: (118 + (tier - 1) * 12) * MOVEMENT_SPEED_MULTIPLIER
        };
    }
    if (type === 'medicShack') {
        return {
            medics: MEDICS_PER_SHACK + tier - 1,
            recruitTime: Math.max(7, MEDIC_RECRUIT_TIME - (tier - 1) * 1.5),
            healRate: 16 + (tier - 1) * 5,
            range: MEDIC_HEAL_RANGE + (tier - 1) * 120,
            speed: (126 + (tier - 1) * 14) * MOVEMENT_SPEED_MULTIPLIER
        };
    }
    if (type === 'treehouse') {
        return {
            range: WATCHTOWER_RANGE + (tier - 1) * 95,
            cooldown: Math.max(0.68, WATCHTOWER_COOLDOWN - (tier - 1) * 0.2),
            damage: 30 + (tier - 1) * 12
        };
    }
    return {};
}

function cabinUpgradeCost(building) {
    if (!building || !isCabin(building.type) || (building.level || 1) >= CABIN_MAX_LEVEL) return null;
    const nextLevel = (building.level || 1) + 1;
    if (building.type === 'treehouse') {
        return nextLevel === 2 ? { wood: 12, scrap: 8, stone: 2 } : { wood: 18, scrap: 12, stone: 4 };
    }
    return nextLevel === 2 ? { wood: 10, scrap: 6, stone: 2 } : { wood: 16, scrap: 10, stone: 4 };
}

function cabinCoreBonus(building) {
    if (!building || !isCabin(building.type)) return 0;
    const level = Math.max(1, building.level || 1);
    const baseBonus = building.type === 'treehouse' ? 65 : 50;
    const upgradeBonus = building.type === 'treehouse' ? 30 : 22;
    return baseBonus + (level - 1) * upgradeBonus;
}

function playerBuildingCost(type, player = state.player) {
    const base = buildingCost(type);
    if (!isCabin(type) || !player?.cabinDiscount) return { ...base };
    return Object.fromEntries(Object.entries(base).map(([key, amount]) => [key, Math.max(1, Math.ceil(amount * (1 - player.cabinDiscount))) ]));
}

function playerUpgradeCost(building, player = state.player) {
    const base = cabinUpgradeCost(building);
    if (!base || !player?.cabinDiscount) return base;
    return Object.fromEntries(Object.entries(base).map(([key, amount]) => [key, Math.max(1, Math.ceil(amount * (1 - player.cabinDiscount))) ]));
}

function formatCost(cost) {
    return Object.entries(cost).map(([key, amount]) => `${amount} ${resourceInfo[key]?.short || key}`).join(' + ');
}

function canAfford(type, player = state.player) {
    return Object.entries(playerBuildingCost(type, player)).every(([key, amount]) => player.inventory[key] >= amount);
}

function placementBlockReason(x, y, type, player = state.player) {
    if (state.map === 'lycee' && state.difficulty === 'hard') return 'CONSTRUCTION INTERDITE EN HARD LYCÉE';
    const radius = buildingRadius(type);
    if (x < 100 || x > WORLD_W - 100 || y < 120 || y > WORLD_H - 90) return 'HORS DU TERRAIN';
    if (state.map === 'maze' && isMazeWall(x, y, radius)) return 'MUR DE HAIE';
    if (state.map !== 'maze' && distance({ x, y }, state.core) < state.core.radius + radius + 20) return 'TROP PRÈS DU CAMP';
    if (distance({ x, y }, player) > 330) return 'HORS DE PORTÉE';
    if (state.buildings.some((building) => distance({ x, y }, building) < radius + building.radius + 20)) return 'ESPACE OCCUPÉ';
    return null;
}

function validPlacement(x, y, type, player = state.player) {
    return !placementBlockReason(x, y, type, player);
}

function getBuildTarget(player) {
    if (player.id === 0 && !player.gamepad && input.pointerInside) return { x: input.mouseX, y: input.mouseY };
    const range = Math.max(120, Math.min(310, player.buildAimDistance || 190));
    return { x: player.x + player.facingX * range, y: player.y + player.facingY * range };
}

function placeBuilding(player = state.player, x = input.mouseX, y = input.mouseY) {
    const type = player.selectedBuild;
    if (!type || player.hp <= 0) return false;
    if (!canAfford(type, player)) {
        const missing = Object.entries(playerBuildingCost(type, player)).find(([key, amount]) => player.inventory[key] < amount);
        showToast(`${player.label} · MANQUE ${missing ? resourceInfo[missing[0]]?.label || missing[0] : 'DE RESSOURCES'}`);
        tone(120, 0.18, 'square');
        return false;
    }
    const blockedReason = placementBlockReason(x, y, type, player);
    if (blockedReason) {
        showToast(`${player.label} · ${blockedReason}`);
        return false;
    }
    const cost = playerBuildingCost(type, player);
    for (const [key, amount] of Object.entries(cost)) player.inventory[key] -= amount;
    const radius = buildingRadius(type);
    state.buildings.push({
        type,
        x,
        y,
        radius,
        hp: type === 'barricade' ? 260 : type === 'treehouse' ? 260 : 220,
        maxHp: type === 'barricade' ? 260 : type === 'treehouse' ? 260 : 220,
        burning: false,
        production: 0,
        recruitTimer: 0,
        workerCount: 0,
        guardCount: 0,
        medicCount: 0,
        towerCooldown: 0,
        level: isCabin(type) ? 1 : 0,
        ownerId: player.id
    });
    const building = state.buildings[state.buildings.length - 1];
    if (isCabin(type)) {
        const coreGain = cabinCoreBonus(building);
        state.core.maxHp += coreGain;
        state.core.hp = Math.min(state.core.maxHp, state.core.hp + coreGain);
        state.battleStats.cabinsBuilt = (state.battleStats.cabinsBuilt || 0) + 1;
    } else if (type === 'barricade') {
        state.battleStats.barricadesBuilt = (state.battleStats.barricadesBuilt || 0) + 1;
    }
    if (type === 'shack') spawnWorker(building.x + 34, building.y + 72, building);
    if (type === 'guardShack') spawnAlly(building.x + 34, building.y + 72, building, false);
    if (type === 'medicShack') spawnMedic(building.x + 34, building.y + 72, building);
    buildSound.currentTime = 0;
    if (!muted) buildSound.play().catch(() => {});
    burst(x, y, '#e2bf7c', 14);
    state.score += 25;
    const label = state.map === 'lycee'
        ? ({ barricade: 'BARRICADE POUBELLES POSÉE', shack: 'CDI INSTALLÉ', guardShack: 'SALLE DE CLASSE INSTALLÉE', medicShack: 'INFIRMERIE INSTALLÉE', treehouse: 'VOISINS VÉNÈRES INSTALLÉS' }[type])
        : type === 'barricade' ? 'BARRICADE POSÉE' : type === 'guardShack' ? 'CABANE GUERRIÈRE INSTALLÉE' : type === 'medicShack' ? 'CABANE MÉDIC INSTALLÉE' : type === 'treehouse' ? 'TOUR ARBORICOLE INSTALLÉE' : 'CABANE COLLECTE INSTALLÉE';
    showToast(`${player.label} · ${label}`);
    player.selectedBuild = null;
    if (player.id === 0) selectBuild(null);
    updateUI();
    return true;
}

function upgradeNearestCabin(player = state.player) {
    const target = state.buildings
        .filter((building) => isCabin(building.type) && building.hp > 0 && distance(building, player) <= CABIN_UPGRADE_RANGE)
        .sort((a, b) => distance(a, player) - distance(b, player))[0];
    if (!target) {
        showToast(`${player.label} · APPROCHEZ-VOUS D’UNE CABANE OU D’UNE TOUR`);
        return;
    }
    const level = target.level || 1;
    if (level >= CABIN_MAX_LEVEL) {
        showToast('CETTE CONSTRUCTION EST AU NIVEAU MAXIMUM');
        return;
    }
    const cost = playerUpgradeCost(target, player);
    const missing = Object.entries(cost).find(([key, amount]) => player.inventory[key] < amount);
    if (missing) {
        showToast(`${player.label} · IL MANQUE ${resourceInfo[missing[0]]?.label || missing[0]}`);
        return;
    }
    for (const [key, amount] of Object.entries(cost)) player.inventory[key] -= amount;
    target.level = level + 1;
    const hpGain = target.type === 'treehouse' ? 35 : 28;
    target.maxHp += hpGain;
    target.hp = Math.min(target.maxHp, target.hp + hpGain);
    const coreGain = target.type === 'treehouse' ? 30 : 22;
    state.core.maxHp += coreGain;
    state.core.hp = Math.min(state.core.maxHp, state.core.hp + coreGain);
    state.score += 35;
    burst(target.x, target.y, '#f4d88b', 22);
    buildSound.currentTime = 0;
    if (!muted) buildSound.play().catch(() => {});
    const label = state.map === 'lycee'
        ? buildingDisplayName(target.type)
        : target.type === 'guardShack' ? 'CABANE GUERRIÈRE' : target.type === 'medicShack' ? 'CABANE MÉDIC' : target.type === 'treehouse' ? 'TOUR ARBORICOLE' : 'CABANE COLLECTE';
    showToast(`${player.label} · ${label} NIVEAU ${target.level} · ${formatCost(cost)}`);
    updateUI();
}

function igniteNearest(player = state.player) {
    const target = state.buildings
        .filter((building) => building.type === 'barricade' && !building.burning && distance(building, player) < 150)
        .sort((a, b) => distance(a, player) - distance(b, player))[0];
    if (!target) {
        showToast(`${player.label} · APPROCHEZ-VOUS D’UNE BARRICADE`);
        return;
    }
    if (player.inventory.wood < 3) {
        showToast(`${player.label} · IL FAUT 3 BOIS`);
        return;
    }
    player.inventory.wood -= 3;
    target.burning = true;
    target.burnTime = 18;
    showToast(`${player.label} · BARRICADE EN FEU`);
    tone(180, 0.35, 'sawtooth', 0.06);
}

function throwStone(player = state.player, targetX = input.mouseX, targetY = input.mouseY) {
    if (player.hp <= 0 || player.repairTarget && player.repairProgress > 0) return;
    const weapon = weapons[player.weapon];
    if (!weapon || player.weaponCooldown > 0) return;
    const canShoot = Object.entries(weapon.cost).every(([key, amount]) => player.inventory[key] >= amount);
    if (!canShoot) {
        const missing = Object.entries(weapon.cost).find(([key, amount]) => player.inventory[key] < amount);
        if (player.id === 0) showToast(missing ? `PLUS DE ${resourceInfo[missing[0]]?.label || 'RESSOURCES'}` : 'MUNITIONS INSUFFISANTES');
        return;
    }
    let dx = targetX - player.x;
    let dy = targetY - player.y;
    let length = Math.hypot(dx, dy);
    if (length < 1) {
        const facingLength = Math.hypot(player.facingX, player.facingY);
        dx = facingLength > 0 ? player.facingX / facingLength : 1;
        dy = facingLength > 0 ? player.facingY / facingLength : 0;
        length = 1;
    }
    player.facingX = dx / length;
    player.facingY = dy / length;
    for (const [key, amount] of Object.entries(weapon.cost)) player.inventory[key] -= amount;
    player.weaponCooldown = weapon.cooldown;
    if (state.difficulty === 'tutorial' && state.tutorial) state.tutorial.shotsFired = (state.tutorial.shotsFired || 0) + 1;
    if (weapon.melee) {
        state.projectiles.push({
            weapon: player.weapon, owner: 'player', playerId: player.id, melee: true,
            x: player.x + dx / length * 46, y: player.y + dy / length * 46, angle: Math.atan2(dy, dx),
            vx: 0, vy: 0, life: 0.18, radius: weapon.radius, color: weapon.color, damage: weapon.damage, hitEnemies: new Set()
        });
    } else {
        state.projectiles.push({
            weapon: player.weapon,
            owner: 'player',
            playerId: player.id,
            x: player.x,
            y: player.y - 18,
            vx: dx / length * weapon.speed,
            vy: dy / length * weapon.speed,
            life: player.weapon === 'molotov' ? 1.7 : weapon.firework ? 1.35 : 1.25,
            radius: weapon.radius,
            color: weapon.color,
            damage: weapon.damage,
            splash: weapon.splash || 0,
            firework: Boolean(weapon.firework)
        });
    }
    tone(weapon.melee ? 170 : weapon.firework ? 680 : weapon === weapons.molotov ? 180 : 420, 0.08, weapon.melee ? 'square' : weapon.firework ? 'sine' : weapon === weapons.molotov ? 'sawtooth' : 'triangle', 0.025);
    updateUI();
}

function getDistinctSpawnPoint(x, y) {
    const minSeparation = 320;
    if (state?.map === 'lycee' && y < LYCEE_ROUTE_CLEAR_Y) {
        const currentLane = LYCEE_ASSAULT_ROADS.indexOf(lyceeRoadForX(x));
        const offset = 1 + Math.floor(Math.random() * (LYCEE_ASSAULT_ROADS.length - 1));
        const lane = (Math.max(0, currentLane) + offset) % LYCEE_ASSAULT_ROADS.length;
        return lyceeRoadSpawn(lane, y + (Math.random() - 0.5) * 42);
    }
    if (y > WORLD_H - 20) {
        let nextX = 140 + Math.random() * (WORLD_W - 280);
        for (let attempt = 0; attempt < 12 && Math.abs(nextX - x) < minSeparation; attempt++) {
            nextX = 140 + Math.random() * (WORLD_W - 280);
        }
        return { x: nextX, y: y + (Math.random() - 0.5) * 80 };
    }
    if (x < 20) {
        let nextY = 180 + Math.random() * (WORLD_H - 360);
        for (let attempt = 0; attempt < 12 && Math.abs(nextY - y) < minSeparation; attempt++) {
            nextY = 180 + Math.random() * (WORLD_H - 360);
        }
        return { x: x - Math.random() * 70, y: nextY };
    }
    if (x > WORLD_W - 20) {
        let nextY = 180 + Math.random() * (WORLD_H - 360);
        for (let attempt = 0; attempt < 12 && Math.abs(nextY - y) < minSeparation; attempt++) {
            nextY = 180 + Math.random() * (WORLD_H - 360);
        }
        return { x: x + Math.random() * 70, y: nextY };
    }
    if (y < 180) {
        let nextX = 150 + Math.random() * (WORLD_W - 300);
        for (let attempt = 0; attempt < 12 && Math.abs(nextX - x) < minSeparation; attempt++) {
            nextX = 150 + Math.random() * (WORLD_W - 300);
        }
        return { x: nextX, y: y + (Math.random() - 0.5) * 40 };
    }
    const angle = Math.random() * Math.PI * 2;
    const distanceFromSource = 150 + Math.random() * 130;
    return {
        x: Math.max(70, Math.min(WORLD_W - 70, x + Math.cos(angle) * distanceFromSource)),
        y: Math.max(90, Math.min(WORLD_H - 70, y + Math.sin(angle) * distanceFromSource))
    };
}

function spawnEnemy(type = 'officer', x = 170 + Math.random() * (WORLD_W - 340), y = WORLD_H + 90, targetMode = 'camp', flankSide = 0, spawnCopy = false) {
    // En mode squat, aucun policier ne doit apparaître dans le noir ou une salle fermée.
    if (state?.map === 'squat' && !squatPointAllowed(x, y)) {
        const safe = squatWaveSpawnPoint();
        x = safe.x; y = safe.y;
    }
    const profiles = {
        officer: { radius: 30, hp: 34 + state.wave * 3.5, speed: (64 + Math.min(state.wave * 4.5, 54)) * MOVEMENT_SPEED_MULTIPLIER, damage: 7 + state.wave * 0.55 },
        shield_crs: { radius: 34, hp: 135 + state.wave * 11, speed: 46 * MOVEMENT_SPEED_MULTIPLIER, damage: 11, shield: true },
        flashball: { radius: 29, hp: 72 + state.wave * 7, speed: 46 * MOVEMENT_SPEED_MULTIPLIER, damage: 7, ranged: true },
        water_cannon: { radius: 112, hp: 1650 + state.wave * 55, speed: 22 * MOVEMENT_SPEED_MULTIPLIER, damage: 34, boss: true },
        infiltrator: { radius: 27, hp: 60 + state.wave * 4, speed: 154 * MOVEMENT_SPEED_MULTIPLIER, damage: 13, infiltrator: true },
        bac: { radius: 27, hp: 52 + state.wave * 3.5, speed: 212 * MOVEMENT_SPEED_MULTIPLIER, damage: 18, tackle: true },
        canine: { radius: 30, hp: 92 + state.wave * 7, speed: 66 * MOVEMENT_SPEED_MULTIPLIER, damage: 10, handler: true },
        dog: { radius: 20, hp: 38 + state.wave * 3, speed: 285 * MOVEMENT_SPEED_MULTIPLIER, damage: 16, missile: true },
        moto: { radius: 39, hp: 135 + state.wave * 8, speed: 245 * MOVEMENT_SPEED_MULTIPLIER, damage: 26, driveby: true },
        quad: { radius: 31, hp: 74 + state.wave * 4, speed: 300 * MOVEMENT_SPEED_MULTIPLIER, damage: 34, driveby: true },
        drone: { radius: 31, hp: 112 + state.wave * 6, speed: 88 * MOVEMENT_SPEED_MULTIPLIER, damage: 0, air: true, drone: true },
        megaphone: { radius: 29, hp: 125 + state.wave * 10, speed: 42 * MOVEMENT_SPEED_MULTIPLIER, damage: 7, support: true },
        sniper: { radius: 25, hp: 96 + state.wave * 6, speed: 0, damage: 48, sniper: true },
        grenadier: { radius: 30, hp: 118 + state.wave * 8, speed: 46 * MOVEMENT_SPEED_MULTIPLIER, damage: 0, grenadier: true },
        demineur: { radius: 31, hp: 108 + state.wave * 6, speed: 155 * MOVEMENT_SPEED_MULTIPLIER, damage: 18, kamikaze: true },
        flamethrower: { radius: 35, hp: 275 + state.wave * 18, speed: 46 * MOVEMENT_SPEED_MULTIPLIER, damage: 16, flameThrower: true },
        van: { radius: 64, hp: 320 + state.wave * 18, speed: 42 * MOVEMENT_SPEED_MULTIPLIER, damage: 20 },
        bonusVan: { radius: 64, hp: 520 + state.wave * 22, speed: 0, damage: 0, bonusVan: true },
        tank: { radius: 82, hp: 620 + state.wave * 30, speed: 28 * MOVEMENT_SPEED_MULTIPLIER, damage: 32 },
        helicopter: { radius: 60, hp: 440 + state.wave * 25, speed: 105 * MOVEMENT_SPEED_MULTIPLIER, damage: 25, air: true },
        macron: { radius: 38, hp: 2200 + state.wave * 80, speed: 265 * MOVEMENT_SPEED_MULTIPLIER, damage: 0, boss: true, macron: true }
    };
    const profile = profiles[type] || profiles.officer;
    const enemy = {
        type,
        x,
        y,
        ...profile,
        hp: profile.hp * ENEMY_HP_MULTIPLIER,
        maxHp: profile.hp * ENEMY_HP_MULTIPLIER,
        attackCooldown: Math.random(),
        flash: 0,
        guardDown: 0,
        aimTime: 0,
        gasCooldown: 4 + Math.random() * 3,
        tackleCooldown: 0,
        released: false,
        revealed: type !== 'infiltrator',
        facingX: 0,
        facingY: 1,
        vx: 0,
        vy: 0,
        targetMode: type === 'officer' ? targetMode : 'camp',
        flankSide,
        aiTimer: Math.random() * ENEMY_AI_INTERVAL,
        supportTimer: Math.random() * ENEMY_SUPPORT_INTERVAL,
        cachedTargetInfo: null,
        nearestPlayer: null,
        nearestPlayerDistance: Infinity,
        supported: false,
        lyceeRouteX: state.map === 'lycee' && !profile.air && y < LYCEE_ROUTE_CLEAR_Y ? lyceeRoadForX(x) : null
    };
    if (type === 'macron') {
        enemy.eggTimer = 2 + Math.random(); // temps avant prochain arrêt pour pondre
        enemy.laying = 0; // 0 = en mouvement, >0 = en train de pondre (1s)
        enemy.fleeing = false;
        enemy.wanderX = null;
        enemy.wanderY = null;
        enemy.wanderTimer = 0;
    }
    if (state.map === 'maze' && !enemy.air && isMazeWall(enemy.x, enemy.y, enemy.radius)) {
        const safe = randomMazeOpenPoint();
        enemy.x = safe.x;
        enemy.y = safe.y;
    }
    if (state.map === 'lycee' && !enemy.air && isLyceeBuildingBlocked(enemy.x, enemy.y, enemy.radius)) {
        const safeSpawn = findLyceeSafeSpawn(enemy.x, enemy.y, enemy.radius);
        enemy.x = safeSpawn.x;
        enemy.y = safeSpawn.y;
        enemy.lyceeRouteX = safeSpawn.x;
    }
    // Répartit l'IA dès le spawn pour éviter un pic quand toute une vague devient active.
    enemy.aiSlot = state.enemies.length;
    state.enemies.push(enemy);
    addSpatialItem(state.enemyGrid, enemy);
    return enemy;
}

function spawnSpecialAtEdge(type, lane = Math.floor(Math.random() * 3)) {
    // Les snipers sont immobiles : ils doivent rester dans le monde pour être
    // visibles et atteignables par les tirs du joueur et des tours.
    const isLycee = state.map === 'lycee';
    const isRiver = state.map === 'river';
    let spawn;
    if (isLycee) {
        spawn = type === 'sniper'
            ? { x: LYCEE_ASSAULT_ROADS[lane % LYCEE_ASSAULT_ROADS.length], y: 180 }
            : lyceeRoadSpawn(lane);
    } else if (isRiver) {
        const bridge = riverBridgeZones()[lane % 3];
        spawn = riverBridgeApproach(bridge, 145, (Math.random() - 0.5) * 110);
    } else if (type === 'sniper') {
        spawn = lane === 0
            ? { x: 150 + Math.random() * (WORLD_W - 300), y: 145 }
            : lane === 1
                ? { x: 145, y: 180 + Math.random() * (WORLD_H - 360) }
                : { x: WORLD_W - 145, y: 180 + Math.random() * (WORLD_H - 360) };
    } else {
        spawn = lane === 0
            ? { x: 140 + Math.random() * (WORLD_W - 280), y: WORLD_H + 100 }
            : lane === 1
                ? { x: -100, y: 180 + Math.random() * (WORLD_H - 360) }
                : { x: WORLD_W + 100, y: 180 + Math.random() * (WORLD_H - 360) };
    }
    spawnEnemy(type, spawn.x, spawn.y, 'hunter', lane === 1 ? -1 : 1);
}

function spawnBonusVan() {
    if (state.bonusVan || state.wave >= MAX_WAVES) return;
    const margin = 210;
    let spawn = state.map === 'lycee'
        ? lyceeRoadSpawn(Math.floor(Math.random() * LYCEE_ASSAULT_ROADS.length), -160)
        : { x: WORLD_W / 2, y: WORLD_H / 2 };
    for (let attempt = 0; state.map !== 'lycee' && attempt < 12; attempt++) {
        const side = Math.floor(Math.random() * 4);
        spawn = side === 0
            ? { x: margin, y: 220 + Math.random() * (WORLD_H - 440) }
            : side === 1
                ? { x: WORLD_W - margin, y: 220 + Math.random() * (WORLD_H - 440) }
                : side === 2
                    ? { x: 220 + Math.random() * (WORLD_W - 440), y: margin }
                    : { x: 220 + Math.random() * (WORLD_W - 440), y: WORLD_H - margin };
        if (nearestPlayerDistance(spawn) > 680 && distance(spawn, state.core) > 560) break;
    }
    state.bonusVan = spawnEnemy('bonusVan', spawn.x, spawn.y, 'bonus');
    state.bonusVanSpawnTime = null;
    showToast('CAMION DE RENFORTS REPÉRÉ · DÉTRUISEZ-LE');
    state.floaters.push({ x: spawn.x, y: spawn.y - 92, text: 'CAMION · RENFORTS', life: 2.8 });
    burst(spawn.x, spawn.y, '#8ad9ff', 18);
    tone(210, 0.5, 'sawtooth', 0.06);
}

function getWaveAgentCount(wave) {
    return Math.min(4 + Math.floor((wave - 1) * 1.55) + Math.floor(wave / 4), 34);
}

function getWaveFastUnitCount(wave) {
    return wave < 1 ? 0 : Math.min(1 + Math.floor((wave - 1) / 3), 6);
}

function getWaveIntel(wave) {
    const scale = (typeof getPoliceScale === 'function' && state) ? getPoliceScale() : POLICE_COUNT_MULTIPLIER;
    const fastUnits = getWaveFastUnitCount(wave) * scale;
    const agents = (getWaveAgentCount(wave) + getWaveFastUnitCount(wave)) * scale;
    const vehicles = [];
    const specials = [];
    if (wave >= 1) specials.push(`${fastUnits} BAC RAPIDE${fastUnits > 1 ? 'S' : ''}`);
    if (wave >= 6) specials.push('BOUCLIER');
    if (wave >= 7) specials.push('FLASHBALL');
    if (wave >= 9) specials.push('CANINE · CHIEN');
    if (wave >= 10) specials.push('BRAV-M · QUAD');
    if (wave >= 7) specials.push('DRONE · NÉGOCIATEUR');
    if (wave >= 8) specials.push('TIREUR LBD');
    if (wave >= 6) specials.push('LANCE-GRENADES F4');
    if (wave >= 9) specials.push('ROBOT FLASHBANG');
    if (wave >= 10) specials.push('CAMION LANCE-EAU');
    if (wave >= 11) specials.push('CRS NETTOYEUR');
    if (wave === 15 || wave === 20 || wave === 25 || wave === 30) {
        const n = { 15: 1, 20: 2, 25: 3, 30: 4 }[wave];
        specials.push(n === 1 ? 'MACRON' : `${n} MACRONS`);
    }
    if (wave >= 4 && wave % 3 === 1) vehicles.push('CAMION');
    if (wave >= 7 && (wave % 4 === 0 || wave % 3 === 1)) vehicles.push('TANK');
    if (wave >= 10 && (wave % 5 === 0 || wave % 3 === 1)) vehicles.push('HÉLICOPTÈRE');
    if (wave >= 20) vehicles.push('CAMION');
    if (wave >= 25) vehicles.push('TANK');
    if (REINFORCEMENT_WAVES.has(wave)) specials.push('RENFORTS ALLIÉS');
    return { agents, vehicles, specials };
}
function beginWaveAlert(countdown = 8, cleared = false) {
    if (state.wave >= MAX_WAVES || state.waveAlert) return;
    const wave = state.wave + 1;
    const intel = getWaveIntel(wave);
    const timeLeft = Math.max(1.4, countdown);
    state.waveAlert = { wave, timeLeft, lastSecond: Math.ceil(timeLeft), cleared };
    showToast(cleared ? `ZONE NETTOYÉE · VAGUE ${wave} EN APPROCHE` : `ALERTE VAGUE ${wave} — ${intel.agents} AGENTS`);
    tone(cleared ? 220 : 150, 0.25, 'square', 0.05);
}

function launchWave() {
    if (!state.waveAlert) return;
    state.waveAlert = null;
    spawnWave();
    if (state.wave < MAX_WAVES && state.wave >= state.bonusVanNextWave && !state.bonusVan && state.bonusVanSpawnTime === null) {
        state.bonusVanSpawnTime = state.time + 5 + Math.random() * 11;
    }
    state.nextWave = state.time + Math.max(9, 18 - state.wave * 0.35);
}

function queueEnemySpawn(type, x, y, targetMode = 'camp', flankSide = 0, spawnCopy = false) {
    state.enemySpawnQueue.push({ type, x, y, targetMode, flankSide, spawnCopy });
}

function updateEnemySpawnQueue(maxPerFrame = 8) {
    if (!state.enemySpawnQueue?.length) return;
    // Budget temps strict : jamais plus de ~4ms de spawn par frame, même si la file est pleine.
    const adaptiveMax = state.lastFrameDt > 0.028 ? 4 : state.lastFrameDt > 0.022 ? 6 : maxPerFrame;
    const t0 = performance.now();
    let spawned = 0;
    while (spawned < adaptiveMax && state.enemySpawnQueue.length) {
        if (performance.now() - t0 > 4) break;
        const entry = state.enemySpawnQueue.shift();
        spawnEnemy(entry.type, entry.x, entry.y, entry.targetMode, entry.flankSide, !!entry.spawnCopy);
        spawned++;
    }
}

function spawnWave() {
    if (state.wave >= MAX_WAVES) return;
    state.wave++;
    const isLycee = state.map === 'lycee';
    const isRiver = state.map === 'river';
    const isMaze = state.map === 'maze';
    // Mode Lycée : plus de flics, mais montée progressive (évite le mur CPU dès la vague 1)
    let count = getWaveAgentCount(state.wave);
    const isSquat = state.map === 'squat';
    if (isLycee) {
        const lyceeScale = state.wave <= 3 ? 2.2 : state.wave <= 8 ? 3.2 : 4.0;
        count = Math.floor(count * lyceeScale) + 8 + state.wave * 2;
    } else if (isMaze) {
        // Même densité que le mode Lycée
        const mazeScale = state.wave <= 3 ? 2.2 : state.wave <= 8 ? 3.2 : 4.0;
        count = Math.floor(count * mazeScale) + 8 + state.wave * 2;
    }
    // Multi : ×2 / ×3 / ×4 selon le nombre de joueurs (collectif)
    count = Math.floor(count * getPoliceScale());

    for (let i = 0; i < count; i++) {
        let spawn;
        if (isSquat) {
            spawn = squatWaveSpawnPoint();
        } else if (isMaze) {
            spawn = randomMazeOpenPoint();
        } else if (isLycee) {
            // Les renforts entrent uniquement sur les trois rues dégagées au nord.
            spawn = lyceeRoadSpawn(i % LYCEE_ASSAULT_ROADS.length, -90 - Math.random() * 160);
        } else if (isRiver) {
            // Chaque vague se répartit sur les trois ponts, côté extérieur de l'anneau.
            const bridge = riverBridgeZones()[i % 3];
            spawn = riverBridgeApproach(bridge, 105 + Math.random() * 65, (Math.random() - 0.5) * 130);
        } else {
            const lane = i % 3;
            spawn = lane === 0
                ? { x: 130 + Math.random() * (WORLD_W - 260), y: WORLD_H + 80 + Math.random() * 100 }
                : lane === 1
                    ? { x: -75 - Math.random() * 70, y: 180 + Math.random() * (WORLD_H - 360) }
                    : { x: WORLD_W + 75 + Math.random() * 70, y: 180 + Math.random() * (WORLD_H - 360) };
        }
        const targetMode = (isMaze || isSquat) ? 'hunter' : (i % 3 === 0 ? 'camp' : 'hunter');
        const flankSide = (i % 3 === 1) ? -1 : (i % 3 === 2) ? 1 : (i % 2 ? -1 : 1);
        queueEnemySpawn('officer', spawn.x, spawn.y, targetMode, flankSide);
    }

    // Mode Lycée : +10 alliés à chaque vague
    if (isLycee) {
        for (let a = 0; a < 10; a++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = 80 + Math.random() * 220;
            spawnAlly(state.core.x + Math.cos(angle) * dist, state.core.y + Math.sin(angle) * dist - 40, null, true);
        }
        showToast(`VAGUE ${state.wave} · +10 ALLIÉS ARRIVENT AU LYCÉE`);
    }
    const waveSpecials = [];
    const fastUnits = getWaveFastUnitCount(state.wave);
    for (let i = 0; i < fastUnits; i++) waveSpecials.push('bac');
    if (state.wave >= 6 && state.wave % 2 === 0) waveSpecials.push('shield_crs');
    if (state.wave >= 7 && state.wave % 2 === 1) waveSpecials.push('flashball');
    if (state.wave >= 9 && state.wave % 2 === 1) waveSpecials.push('canine');
    if (state.wave >= 10) waveSpecials.push('moto');
    if (state.wave >= 10 && state.wave % 2 === 0) waveSpecials.push('quad');
    if (state.wave >= 7 && state.wave % 3 === 1) waveSpecials.push('drone', 'megaphone');
    if (state.wave >= 8 && state.wave % 3 === 2) waveSpecials.push('sniper');
    // Grenadiers F4 de plus en plus fréquents avec les vagues
    if (state.wave >= 6) {
        waveSpecials.push('grenadier');
        if (state.wave >= 12) waveSpecials.push('grenadier');
        if (state.wave >= 18) waveSpecials.push('grenadier');
        if (state.wave >= 24) waveSpecials.push('grenadier');
    }
    if (state.wave >= 9 && state.wave % 4 === 1) waveSpecials.push('demineur');
    if (state.wave >= 10 && state.wave % 5 === 0) waveSpecials.push('water_cannon');
    if (state.wave >= 11 && state.wave % 3 === 2) waveSpecials.push('flamethrower');
    if (state.wave >= 12 && state.wave % 4 === 0) waveSpecials.push('infiltrator');
    for (const [index, type] of waveSpecials.entries()) {
        // Pas d'hélicos en mode squat
        if (isSquat && type === 'helicopter') continue;
        const lane = index % 3;
        const isLycee = state.map === 'lycee';
        const isRiver = state.map === 'river';
        const isMaze = state.map === 'maze';
        let spawn;
        if (isSquat) {
            spawn = squatWaveSpawnPoint();
        } else if (isMaze) {
            // Spawn sur cases libres près des bords (sauf drones/hélicos qui volent)
            spawn = randomMazeOpenPoint();
            // Favoriser les bords
            if (Math.random() < 0.7) {
                for (let tries = 0; tries < 40; tries++) {
                    const p = randomMazeOpenPoint();
                    const edge = p.x < MAZE_ORIGIN_X + MAZE_CELL * 4 || p.x > MAZE_ORIGIN_X + (MAZE_COLS - 4) * MAZE_CELL
                        || p.y < MAZE_ORIGIN_Y + MAZE_CELL * 4 || p.y > MAZE_ORIGIN_Y + (MAZE_ROWS - 4) * MAZE_CELL;
                    if (edge) { spawn = p; break; }
                }
            }
        } else if (isLycee) {
            spawn = type === 'sniper'
                ? { x: LYCEE_ASSAULT_ROADS[lane % LYCEE_ASSAULT_ROADS.length], y: 180 }
                : lyceeRoadSpawn(lane);
        } else if (isRiver) {
            const bridge = riverBridgeZones()[lane];
            spawn = riverBridgeApproach(bridge, 135, (Math.random() - 0.5) * 110);
        } else if (type === 'sniper') {
            spawn = lane === 0 ? { x: 150 + Math.random() * (WORLD_W - 300), y: 145 } : lane === 1 ? { x: 145, y: 180 + Math.random() * (WORLD_H - 360) } : { x: WORLD_W - 145, y: 180 + Math.random() * (WORLD_H - 360) };
        } else {
            spawn = lane === 0 ? { x: 140 + Math.random() * (WORLD_W - 280), y: WORLD_H + 100 } : lane === 1 ? { x: -100, y: 180 + Math.random() * (WORLD_H - 360) } : { x: WORLD_W + 100, y: 180 + Math.random() * (WORLD_H - 360) };
        }
        queueEnemySpawn(type, spawn.x, spawn.y, 'hunter', lane === 1 ? -1 : 1);
    }
    // Macron boss : vague 15 → 1, 20 → 2, 25 → 3, 30 → 4 (aucun entre ces vagues)
    const macronCounts = { 15: 1, 20: 2, 25: 3, 30: 4 };
    const macronCount = macronCounts[state.wave] || 0;
    if (macronCount > 0) {
        for (let m = 0; m < macronCount; m++) {
            let spawn;
            if (isSquat) {
                spawn = squatWaveSpawnPoint();
            } else if (isMaze) {
                spawn = randomMazeOpenPoint();
            } else if (isLycee) {
                spawn = lyceeRoadSpawn(m % LYCEE_ASSAULT_ROADS.length, -120 - Math.random() * 80);
            } else if (isRiver) {
                const bridge = riverBridgeZones()[m % 3];
                spawn = riverBridgeApproach(bridge, 150, (Math.random() - 0.5) * 100);
            } else {
                const lane = m % 3;
                spawn = lane === 0
                    ? { x: 200 + Math.random() * (WORLD_W - 400), y: WORLD_H + 120 }
                    : lane === 1
                        ? { x: -120, y: 200 + Math.random() * (WORLD_H - 400) }
                        : { x: WORLD_W + 120, y: 200 + Math.random() * (WORLD_H - 400) };
            }
            queueEnemySpawn('macron', spawn.x, spawn.y, 'hunter', m % 2 ? -1 : 1);
        }
        showToast(macronCount === 1 ? 'MACRON ARRIVE !' : `${macronCount} MACRONS ARRIVENT !`);
    }
    if (waveSpecials.length) showToast(`UNITÉS SPÉCIALES · ${waveSpecials.map((type) => SPECIAL_ENEMY_LABELS[type]).join(' · ')}`);
    if (REINFORCEMENT_WAVES.has(state.wave)) {
        spawnReinforcements(null, `VAGUE ${state.wave} · LES RENFORTS ARRIVENT AU CAMP`);
    }
    if (state.wave === 2) showToast('NOUVELLE ARME : FABRIQUEZ LA FRONDE');
    if (state.wave === 3) showToast('NOUVELLE ARME : FABRIQUEZ LE MOLOTOV');
    if (state.wave >= 4 && state.wave % 3 === 1) {
        {
            const spawn = isSquat ? squatWaveSpawnPoint()
                : state.map === 'lycee'
                ? lyceeRoadSpawn(state.wave % LYCEE_ASSAULT_ROADS.length, -145 - Math.random() * 70)
                : { x: 260 + Math.random() * (WORLD_W - 520), y: WORLD_H + 120 };
            queueEnemySpawn('van', spawn.x, spawn.y);
        }
        showToast(`VAGUE ${state.wave} — CAMION DE RENFORTS`);
    }
    if (state.wave >= 7 && state.wave % 3 === 1) {
        {
            const spawn = isSquat ? squatWaveSpawnPoint()
                : { x: 380 + Math.random() * (WORLD_W - 760), y: state.map === 'lycee' ? -110 - Math.random()*50 : WORLD_H + 140 };
            queueEnemySpawn('tank', spawn.x, spawn.y);
        }
        showToast(`VAGUE ${state.wave} — TANK EN APPROCHE`);
    }
    if (state.wave >= 10 && state.wave % 3 === 1 && !isSquat) {
        {
            const hy = state.map === 'lycee' ? -90 - Math.random()*40 : WORLD_H + 100;
            queueEnemySpawn('helicopter', 380 + Math.random() * (WORLD_W - 760), hy);
        }
        showToast(`VAGUE ${state.wave} — HÉLICOPTÈRE DANS LE CIEL`);
    }
    // Vagues finales plus dures
    if (state.wave >= 25) {
        {
            const spawn = isSquat ? squatWaveSpawnPoint()
                : { x: 400 + Math.random() * (WORLD_W - 800), y: state.map === 'lycee' ? -100 - Math.random()*50 : WORLD_H + 100 };
            queueEnemySpawn('van', spawn.x, spawn.y);
        }
        if (state.wave >= 28) {
            const spawn = isSquat ? squatWaveSpawnPoint()
                : { x: 500 + Math.random() * (WORLD_W - 1000), y: state.map === 'lycee' ? -120 - Math.random()*40 : WORLD_H + 130 };
            queueEnemySpawn('tank', spawn.x, spawn.y);
        }
    }
    if (state.wave === MAX_WAVES) {
        showToast('DERNIÈRE VAGUE ! TENEZ BON');
    }
    if (isSquat) showToast(`OUVERTURE DE SQUAT · VAGUE ${state.wave}`);
    tone(95, 0.8, 'sawtooth', 0.08);
}

function closestAvailableTarget(enemy, candidates, range) {
    let best = null;
    let bestDistanceSquared = range * range;
    for (const candidate of candidates) {
        if (!candidate || candidate.hp <= 0) continue;
        const dx = candidate.x - enemy.x;
        const dy = candidate.y - enemy.y;
        const d2 = dx * dx + dy * dy;
        if (d2 < bestDistanceSquared) {
            bestDistanceSquared = d2;
            best = candidate;
        }
    }
    return best;
}

function addSpatialItem(grid, entity, cellSize = 430) {
    if (!(grid instanceof Map)) return;
    const key = `${Math.floor(entity.x / cellSize)},${Math.floor(entity.y / cellSize)}`;
    let bucket = grid.get(key);
    if (!bucket) { bucket = []; grid.set(key, bucket); }
    bucket.push(entity);
}

function nearbyEnemies(x, y, range) {
    const grid = state.enemyGrid;
    if (!(grid instanceof Map) || !grid.size) return state.enemies;
    const cellSize = 430;
    // Les chiens/quad peuvent parcourir plus d'une centaine d'unités entre deux
    // reconstructions de l'index ; cette marge garde les collisions fiables.
    const searchRange = range + 160;
    const minX = Math.floor((x - searchRange) / cellSize);
    const maxX = Math.floor((x + searchRange) / cellSize);
    const minY = Math.floor((y - searchRange) / cellSize);
    const maxY = Math.floor((y + searchRange) / cellSize);
    const candidates = [];
    for (let cx = minX; cx <= maxX; cx++) {
        for (let cy = minY; cy <= maxY; cy++) {
            const bucket = grid.get(`${cx},${cy}`);
            if (bucket) for (const enemy of bucket) candidates.push(enemy);
        }
    }
    return candidates;
}

function closestGridTarget(enemy, grid, range) {
    if (!grid?.size) return null;
    const cellSize = 430;
    // L'index est rafraîchi à cadence réduite : la marge couvre le petit déplacement
    // intervenu depuis sa création, sans élargir la distance d'acquisition réelle.
    const searchRange = range + 96;
    const minX = Math.floor((enemy.x - searchRange) / cellSize);
    const maxX = Math.floor((enemy.x + searchRange) / cellSize);
    const minY = Math.floor((enemy.y - searchRange) / cellSize);
    const maxY = Math.floor((enemy.y + searchRange) / cellSize);
    const rangeSquared = range * range;
    let best = null;
    let bestDistanceSquared = rangeSquared;
    for (let cx = minX; cx <= maxX; cx++) {
        for (let cy = minY; cy <= maxY; cy++) {
            const bucket = grid.get(`${cx},${cy}`);
            if (!bucket) continue;
            for (const candidate of bucket) {
                if (!candidate || candidate.hp <= 0) continue;
                const dx = candidate.x - enemy.x;
                const dy = candidate.y - enemy.y;
                const distanceSquared = dx * dx + dy * dy;
                if (distanceSquared < bestDistanceSquared) {
                    bestDistanceSquared = distanceSquared;
                    best = candidate;
                }
            }
        }
    }
    return best;
}

function selectEnemyTarget(enemy) {
    // Priorité : joueurs > alliés > barricades > cabanes.
    // Le core n'est ciblé que sur la carte Lycée (porte à défendre).
    const playerRange = state.map === 'lycee' ? ENEMY_TARGET_RANGES.player : 900;
    const player = closestAvailableTarget(enemy, state.players, playerRange);
    if (player) return { entity: player, kind: 'player' };

    const ally = closestGridTarget(enemy, state.allyGrid, ENEMY_TARGET_RANGES.ally + 200);
    if (ally) return { entity: ally, kind: 'ally' };

    const barricade = closestGridTarget(enemy, state.barricadeGrid, ENEMY_TARGET_RANGES.barricade + 280);
    if (barricade) return { entity: barricade, kind: 'barricade' };

    const shack = closestGridTarget(enemy, state.cabinGrid, ENEMY_TARGET_RANGES.shack + 280);
    if (shack) return { entity: shack, kind: 'building' };

    // Dernier recours : joueur le plus proche même hors portée (chasse)
    const anyPlayer = nearestLivingPlayer(enemy);
    if (anyPlayer) return { entity: anyPlayer, kind: 'player' };

    // Core uniquement sur Lycée (porte du lycée)
    if (state.map === 'lycee') return { entity: state.core, kind: 'core' };

    // Camp / Rivière : pas de core invisible — viser une cabane ou barricade quelconque
    const anyBuilding = state.buildings.find((b) => b.hp > 0);
    if (anyBuilding) return { entity: anyBuilding, kind: anyBuilding.type === 'barricade' ? 'barricade' : 'building' };

    return { entity: anyPlayer || state.players[0], kind: 'player' };
}

function nearestLivingPlayer(entity) {
    let best = null;
    let bestDistanceSquared = Infinity;
    for (const player of state.players) {
        if (!player || player.hp <= 0) continue;
        const dx = player.x - entity.x;
        const dy = player.y - entity.y;
        const d2 = dx * dx + dy * dy;
        if (d2 < bestDistanceSquared) {
            bestDistanceSquared = d2;
            best = player;
        }
    }
    return best;
}

function nearestPlayerDistance(entity) {
    const player = nearestLivingPlayer(entity);
    return player ? Math.hypot(entity.x - player.x, entity.y - player.y) : Infinity;
}

function isPlayerEntity(entity) {
    return state.players.includes(entity);
}

function putPlayerDown(player) {
    if (player.downed || player.eliminated) return;
    player.hp = 0;
    player.downed = true;
    player.downedTimer = PLAYER_BLEEDOUT_DURATION;
    player.reviveTarget = null;
    player.reviveProgress = 0;
    burst(player.x, player.y, '#ff7770', 16);
    if (state.players.length === 1) {
        showToast(`${player.label} · PARTIE TERMINÉE`);
        endGame(false);
        return;
    }
    showToast(`${player.label} · À TERRE · UN·E CAMARADE PEUT VOUS RÉANIMER`);
}

function damagePlayer(player, amount) {
    if (!player || player.hp <= 0 || player.eliminated || player.permanentInvulnerability || player.invulnerabilityTime > 0) return;
    player.hp = Math.max(0, player.hp - amount);
    if (player.hp <= 0) putPlayerDown(player);
}

function findDownedPlayerToRevive(player) {
    return state.players
        .filter((candidate) => candidate !== player && candidate.downed && candidate.downedTimer > 0)
        .filter((candidate) => distance(candidate, player) <= PLAYER_REVIVE_RANGE)
        .sort((a, b) => distance(a, player) - distance(b, player))[0] || null;
}

function updatePlayerRevive(dt, player, interacting) {
    if (player.hp <= 0) return false;
    const target = interacting ? findDownedPlayerToRevive(player) : null;
    if (!target) {
        player.reviveTarget = null;
        player.reviveProgress = 0;
        return false;
    }
    if (player.reviveTarget !== target) {
        player.reviveTarget = target;
        player.reviveProgress = 0;
    }
    player.reviveProgress += dt;
    if (player.reviveProgress >= PLAYER_REVIVE_DURATION) {
        target.hp = Math.ceil(target.maxHp * 0.5);
        target.downed = false;
        target.downedTimer = 0;
        target.eliminated = false;
        target.damageCooldown = 2;
        target.stun = 0;
        player.reviveTarget = null;
        player.reviveProgress = 0;
        state.score += 25;
        burst(target.x, target.y, target.color, 24);
        tone(520, 0.28, 'sine', 0.05);
        showToast(`${player.label} · ${target.label} RÉANIMÉ·E · 50 % PV`);
        updateUI();
    }
    return true;
}

function barricadeBetween(enemy, target) {
    const dx = target.x - enemy.x;
    const dy = target.y - enemy.y;
    const lengthSquared = dx * dx + dy * dy;
    if (lengthSquared < 1) return null;
    let best = null;
    let bestProgress = Infinity;
    for (const building of state.buildings) {
        if (building.type !== 'barricade' || building.hp <= 0) continue;
        const progress = ((building.x - enemy.x) * dx + (building.y - enemy.y) * dy) / lengthSquared;
        if (progress <= 0 || progress >= 1 || progress >= bestProgress) continue;
        const nearestX = enemy.x + dx * progress;
        const nearestY = enemy.y + dy * progress;
        const gx = building.x - nearestX;
        const gy = building.y - nearestY;
        if (gx * gx + gy * gy < (building.radius + enemy.radius) ** 2) {
            best = building;
            bestProgress = progress;
        }
    }
    return best;
}

// Collision simple : la prochaine position de l'ennemi chevauche-t-elle une barricade ?
// (Utilisée par le déplacement des policiers — sans cette fonction le jeu crashait au premier mouvement.)
function blockingBarricade(enemy, nextX, nextY) {
    let best = null;
    let bestD2 = Infinity;
    const er = enemy.radius;
    const grid = state.barricadeGrid;
    const cellSize = 430;
    const cx = Math.floor(nextX / cellSize);
    const cy = Math.floor(nextY / cellSize);
    const testBuilding = (building) => {
        if (building.hp <= 0) return;
        const dx = building.x - nextX;
        const dy = building.y - nextY;
        const limit = building.radius + er;
        const d2 = dx * dx + dy * dy;
        if (d2 < limit * limit && d2 < bestD2) {
            bestD2 = d2;
            best = building;
        }
    };
    if (grid?.size) {
        // Les barricades et unités sont bien plus petites qu'une cellule : seules
        // les 9 cases voisines peuvent contenir un obstacle de collision.
        for (let ox = -1; ox <= 1; ox++) {
            for (let oy = -1; oy <= 1; oy++) {
                const bucket = grid.get(`${cx + ox},${cy + oy}`);
                if (bucket) for (const building of bucket) testBuilding(building);
            }
        }
    } else {
        for (const building of state.buildings) {
            if (building.type === 'barricade') testBuilding(building);
        }
    }
    return best;
}

function playerUsesPointerAim(player) {
    if (player.id !== 0 || !input.pointerInside || player.gamepad) return false;
    return true;
}

function setPlayerBuild(player, type) {
    if (player.id === 0) {
        // selectBuild toggles an already-selected type; controller selection is
        // an assignment, so don't pre-assign and accidentally toggle it off.
        if (type && player.selectedBuild === type) {
            updateUI();
            return;
        }
        selectBuild(type);
        return;
    }
    player.selectedBuild = type;
    updateUI();
}

function cyclePlayerBuild(player, direction = 1) {
    const current = BUILD_TYPES.indexOf(player.selectedBuild);
    const nextIndex = (current + direction + BUILD_TYPES.length) % BUILD_TYPES.length;
    const next = BUILD_TYPES[nextIndex];
    setPlayerBuild(player, next);
    showToast(`${player.label} · ${buildingDisplayName(next)} · R1 SUIVANT / L1 PRÉCÉDENT · STICK DROIT VISER / DISTANCE · CROIX POSER · ROND ANNULER`);
}

function cancelPlayerBuild(player) {
    if (!player.selectedBuild) return;
    setPlayerBuild(player, null);
}

function playerControls(player) {
    const layout = keyboardLayouts[player.id];
    const pad = player.gamepad;
    let dx = 0;
    let dy = 0;
    let aimX = 0;
    let aimY = 0;
    // Clavier J1 uniquement si pas de manette sur ce joueur (évite conflit clavier/manette)
    if (player.id === 0 && !pad) {
        if (input.keys.has('w') || input.keys.has('z')) dy--;
        if (input.keys.has('s')) dy++;
        if (input.keys.has('a') || input.keys.has('q')) dx--;
        if (input.keys.has('d')) dx++;
    } else if (layout && !pad) {
        if (input.codes.has(layout.up)) dy--;
        if (input.codes.has(layout.down)) dy++;
        if (input.codes.has(layout.left)) dx--;
        if (input.codes.has(layout.right)) dx++;
    }
    let stickAiming = false;
    // Helper stick accessible dans tout playerControls (évite crash triangle / inventaire)
    const axis = (value, deadZone = 0.2) => Math.abs(value || 0) > deadZone ? value : 0;
    if (pad) {
        // Le déplacement est neutralisé plus bas tant que le menu des armes est ouvert.
        dx += axis(pad.axes[0]);
        dy += axis(pad.axes[1]);
        if (gamepadButtonPressed(pad, 14)) dx--;
        if (gamepadButtonPressed(pad, 15)) dx++;
        if (gamepadButtonPressed(pad, 12)) dy--;
        if (gamepadButtonPressed(pad, 13)) dy++;
        aimX = axis(pad.axes[2], 0.24);
        aimY = axis(pad.axes[3], 0.24);
        if (Math.hypot(aimX, aimY) > 0) {
            const aimLength = Math.hypot(aimX, aimY);
            player.facingX = aimX / aimLength;
            player.facingY = aimY / aimLength;
            stickAiming = true;
        }
    }
    const moveLength = Math.hypot(dx, dy);
    if (moveLength > 0.08 && !stickAiming) {
        player.facingX = dx / moveLength;
        player.facingY = dy / moveLength;
    }

    const aimLength = Math.hypot(aimX, aimY);
    const buildMenuButton = gamepadButtonPressed(pad, 10);
    let openedBuildMenuThisFrame = false;
    if (buildMenuButton && !player.previousBuildButton) {
        player.gamepadBuildMenuOpen = !player.gamepadBuildMenuOpen;
        if (player.gamepadBuildMenuOpen) {
            player.gamepadBuildStickReady = aimLength === 0;
            openedBuildMenuThisFrame = true;
            showToast(`${player.label} · STICK DROIT POUR CHOISIR · ROND POUR REVENIR`);
        } else {
            player.gamepadBuildStickReady = false;
            showToast(`${player.label} · CHOIX DE CONSTRUCTION FERMÉ`);
        }
    }
    player.previousBuildButton = buildMenuButton;

    const cancelButton = gamepadButtonPressed(pad, 1);
    if (cancelButton && !player.previousCancelButton) {
        if (player.arsenalOpen) {
            player.arsenalOpen = false;
            if (player.id === 0) setArsenalOpen(false);
            showToast(`${player.label} · ATELIER FERMÉ`);
        } else if (player.gamepadBuildMenuOpen) {
            player.gamepadBuildMenuOpen = false;
            player.gamepadBuildStickReady = false;
            showToast(`${player.label} · RETOUR AU PLACEMENT`);
        } else if (player.selectedBuild) {
            cancelPlayerBuild(player);
            player.gamepadBuildStickReady = false;
            showToast(`${player.label} · CONSTRUCTION ANNULÉE`);
        }
    }
    player.previousCancelButton = cancelButton;

    const upgradeButton = gamepadButtonPressed(pad, 11);
    if (upgradeButton && !player.previousUpgradeButton) upgradeNearestCabin(player);
    player.previousUpgradeButton = upgradeButton;

    if (player.gamepadBuildMenuOpen && aimLength === 0) player.gamepadBuildStickReady = true;
    let selectedBuildThisFrame = false;
    if (player.gamepadBuildMenuOpen && player.gamepadBuildStickReady && !openedBuildMenuThisFrame && aimLength > 0) {
        const sectorWidth = Math.PI * 2 / BUILD_TYPES.length;
        const sector = Math.round(Math.atan2(aimY, aimX) / sectorWidth);
        const buildIndex = (sector % BUILD_TYPES.length + BUILD_TYPES.length) % BUILD_TYPES.length;
        const type = BUILD_TYPES[buildIndex];
        setPlayerBuild(player, type);
        selectedBuildThisFrame = true;
        player.gamepadBuildMenuOpen = false;
        player.gamepadBuildStickReady = false;
        const label = buildingDisplayName(type);
        showToast(`${player.label} · ${label} · R1 SUIVANT / L1 PRÉCÉDENT · STICK DROIT VISER / DISTANCE · CROIX POSER · ROND ANNULER`);
    }
    if (pad && player.selectedBuild && !player.gamepadBuildMenuOpen && aimLength > 0) {
        const pull = Math.max(0, Math.min(1, (aimLength - 0.24) / (1 - 0.24)));
        player.buildAimDistance = 120 + pull * 190;
    }

    const keyboardInteract = pad ? false : (player.id === 0 ? input.keys.has('e') : layout && input.codes.has(layout.interact));
    const keyboardFire = pad ? false : (player.id === 0 ? input.codes.has('Space') : layout && input.codes.has(layout.fire));
    const interactButton = gamepadButtonPressed(pad, 5);
    const igniteButton = gamepadButtonPressed(pad, 4);
    const constructionCycleMode = Boolean(pad && player.selectedBuild && !player.gamepadBuildMenuOpen);
    if (constructionCycleMode && interactButton && !player.previousInteractButton) {
        cyclePlayerBuild(player, 1);
    } else if (constructionCycleMode && igniteButton && !player.previousIgniteButton) {
        cyclePlayerBuild(player, -1);
    }
    const interact = Boolean(keyboardInteract || (interactButton && !constructionCycleMode));
    const crossButton = gamepadButtonPressed(pad, 0);
    const gamepadFireButton = crossButton || gamepadButtonPressed(pad, 7);
    if (!gamepadFireButton) player.suppressGamepadFireUntilRelease = false;
    if (selectedBuildThisFrame && crossButton) player.suppressGamepadFireUntilRelease = true;
    const arsenalBusy = Boolean(player.arsenalOpen || (player.id === 0 && arsenalOpen));
    const controllerCanFire = !player.gamepadBuildMenuOpen
        && !arsenalBusy
        && !player.suppressGamepadFireUntilRelease
        && (player.selectedBuild ? crossButton : gamepadFireButton);
    const fire = Boolean(!player.gamepadBuildMenuOpen && !arsenalBusy && ((player.id === 0 && !pad && input.pointerDown) || keyboardFire || controllerCanFire));

    // Triangle (bouton 3) : ouvre uniquement le menu des armes.
    // La validation se fait avec Croix et la fermeture avec Rond.
    const weaponButton = gamepadButtonPressed(pad, 3);
    if (weaponButton && !player.previousWeaponButton && !player.arsenalOpen) {
        player.arsenalOpen = true;
        const craftable = WEAPON_CYCLE_ORDER.filter((type) => !weapons[type].temporary);
        player.arsenalIndex = Math.max(0, craftable.indexOf(player.weapon));
        const stickX = axis(pad?.axes?.[0], 0.35);
        const stickY = axis(pad?.axes?.[1], 0.35);
        player.arsenalStickReady = Math.hypot(stickX, stickY) < 0.35;
        // Évite qu'une Croix déjà maintenue à l'ouverture valide immédiatement.
        player.previousConfirmWeapon = gamepadButtonPressed(pad, 0);
        if (player.id === 0) {
            setArsenalOpen(true);
            updateUI();
            highlightArsenalSelection(player);
        }
        showToast(`${player.label} · ATELIER · STICK / FLÈCHES CHOISIR · ✕ VALIDER · ○ FERMER`);
    }
    player.previousWeaponButton = weaponButton;

    // Navigation inventaire (tous les joueurs manette) : stick OU flèches D-pad
    if (player.arsenalOpen && pad) {
        const stickX = axis(pad.axes[0], 0.35);
        const stickY = axis(pad.axes[1], 0.35);
        const stickLen = Math.hypot(stickX, stickY);
        if (stickLen < 0.20) player.arsenalStickReady = true;
        const craftable = WEAPON_CYCLE_ORDER.filter((type) => !weapons[type].temporary);
        let dpadDir = 0;
        if (gamepadButtonPressed(pad, 15) && !player.prevArsenalDpadRight) dpadDir = 1;
        if (gamepadButtonPressed(pad, 14) && !player.prevArsenalDpadLeft) dpadDir = -1;
        if (gamepadButtonPressed(pad, 13) && !player.prevArsenalDpadDown) dpadDir = 1;
        if (gamepadButtonPressed(pad, 12) && !player.prevArsenalDpadUp) dpadDir = -1;
        player.prevArsenalDpadRight = gamepadButtonPressed(pad, 15);
        player.prevArsenalDpadLeft = gamepadButtonPressed(pad, 14);
        player.prevArsenalDpadDown = gamepadButtonPressed(pad, 13);
        player.prevArsenalDpadUp = gamepadButtonPressed(pad, 12);
        if (dpadDir !== 0 && craftable.length) {
            player.arsenalIndex = (player.arsenalIndex + dpadDir + craftable.length) % craftable.length;
            if (player.id === 0) highlightArsenalSelection(player);
            const preview = craftable[player.arsenalIndex];
            const status = player.craftedWeapons[preview]
                ? 'DÉJÀ FABRIQUÉE'
                : (state.wave < weapons[preview].wave ? `VAGUE ${weapons[preview].wave}` : 'À FABRIQUER');
            showToast(`${player.label} · ${weapons[preview].label} · ${status}`);
        } else if (player.arsenalStickReady && stickLen >= 0.65 && craftable.length) {
            const dir = Math.abs(stickX) > Math.abs(stickY) ? (stickX > 0 ? 1 : -1) : (stickY > 0 ? 1 : -1);
            player.arsenalIndex = (player.arsenalIndex + dir + craftable.length) % craftable.length;
            player.arsenalStickReady = false;
            if (player.id === 0) highlightArsenalSelection(player);
            const preview = craftable[player.arsenalIndex];
            const status = player.craftedWeapons[preview]
                ? 'DÉJÀ FABRIQUÉE'
                : (state.wave < weapons[preview].wave ? `VAGUE ${weapons[preview].wave}` : 'À FABRIQUER');
            showToast(`${player.label} · ${weapons[preview].label} · ${status}`);
        }
        const confirmWeapon = gamepadButtonPressed(pad, 0); // Croix
        if (confirmWeapon && !player.previousConfirmWeapon && craftable.length) {
            const chosen = craftable[player.arsenalIndex % craftable.length];
            if (player.craftedWeapons[chosen]) {
                player.weapon = chosen;
                player.lastWeapon = chosen;
                player.selectedBuild = null;
                player.arsenalOpen = false;
                if (player.id === 0) {
                    for (const button of document.querySelectorAll('.build')) button.classList.remove('active');
                    setArsenalOpen(false);
                    updateUI();
                }
                showToast(`${player.label} · ARME ÉQUIPÉE : ${weapons[chosen].label}`);
            } else {
                const ok = craftWeapon(chosen, player);
                if (ok) {
                    player.arsenalOpen = false;
                    if (player.id === 0) setArsenalOpen(false);
                }
                if (player.id === 0) {
                    updateUI();
                    highlightArsenalSelection(player);
                }
            }
        }
        player.previousConfirmWeapon = confirmWeapon;
    } else {
        player.previousConfirmWeapon = false;
    }

    if (igniteButton && !player.previousIgniteButton && !constructionCycleMode) igniteNearest(player);
    player.previousInteractButton = interactButton;
    player.previousIgniteButton = igniteButton;
    // Le menu des armes met le jeu en mode sélection : aucun déplacement,
    // interaction ou tir tant qu'il reste ouvert.
    if (player.arsenalOpen) {
        return { dx: 0, dy: 0, moveLength: 0, interact: false, fire: false };
    }
    return { dx, dy, moveLength, interact, fire };
}

function highlightArsenalSelection(player) {
    const craftable = WEAPON_CYCLE_ORDER.filter((type) => !weapons[type].temporary);
    if (!craftable.length) return;
    const chosen = craftable[player.arsenalIndex % craftable.length];
    for (const button of document.querySelectorAll('.weapon')) {
        const isSelected = button.dataset.weapon === chosen;
        button.classList.toggle('active', isSelected);
        if (isSelected) button.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }
}

function updatePlayer(player, dt) {
    if (player.hp <= 0) {
        if (!player.downed && !player.eliminated) putPlayerDown(player);
        if (player.downed) {
            player.downedTimer = Math.max(0, player.downedTimer - dt);
            if (player.downedTimer <= 0) {
                player.downed = false;
                player.eliminated = true;
                player.reviveTarget = null;
                player.reviveProgress = 0;
            }
        }
        player.repairTarget = null;
        player.repairProgress = 0;
        player.harvestNode = null;
        player.harvest = 0;
        return;
    }
    player.weaponCooldown = Math.max(0, player.weaponCooldown - dt);
    updateTemporaryWeapon(player, dt);
    player.speedBoostTime = Math.max(0, player.speedBoostTime - dt);
    player.invulnerabilityTime = Math.max(0, player.invulnerabilityTime - dt);
    player.damageCooldown = Math.max(0, player.damageCooldown - dt);
    player.stun = Math.max(0, player.stun - dt);
    player.slow = Math.max(0, player.slow - dt);
    player.blind = Math.max(0, player.blind - dt);
    player.marked = Math.max(0, player.marked - dt);
    const controls = playerControls(player);
    const movementFactor = player.stun > 0 ? 0 : player.slow > 0 ? 0.48 : 1;
    const speedBoost = (player.speedBoostTime > 0 ? 1.65 : 1) * (1 + (player.speedPower || 0));
    if (controls.moveLength > 0.08) {
        const nx = player.x + controls.dx / controls.moveLength * player.speed * movementFactor * speedBoost * dt;
        const ny = player.y + controls.dy / controls.moveLength * player.speed * movementFactor * speedBoost * dt;
        const resolved = resolveRiverMove(player, nx, ny, false);
        player.x = Math.max(35, Math.min(WORLD_W - 35, resolved.x));
        player.y = Math.max(55, Math.min(WORLD_H - 35, resolved.y));
    }
    // Butins : ramassage automatique en marchant dessus (pas besoin d'appuyer sur E)
    pickupNearbyLoot(player, 58);
    const reviving = updatePlayerRevive(dt, player, controls.interact);
    if (reviving) {
        updateRepair(dt, player, false);
        updateHarvest(dt, player, false);
    } else if (controls.interact && pickupNearbyWeapon(player)) {
        updateRepair(dt, player, false);
        updateHarvest(dt, player, false);
    } else if (controls.interact) {
        if (state.map === 'squat' && openNearbySquatDoor(player)) {
            // porte ouverte
        } else {
            updateRepair(dt, player, true);
            updateHarvest(dt, player, true);
        }
    } else {
        updateRepair(dt, player, false);
        updateHarvest(dt, player, false);
    }

    if (playerUsesPointerAim(player)) {
        const aimX = input.mouseX - player.x;
        const aimY = input.mouseY - player.y;
        const aimLength = Math.hypot(aimX, aimY);
        if (aimLength > 1) {
            player.facingX = aimX / aimLength;
            player.facingY = aimY / aimLength;
        }
    }
    if (controls.fire && player.hp > 0) {
        const useMouseTarget = playerUsesPointerAim(player) && !input.codes.has('Space');
        const targetX = useMouseTarget ? input.mouseX : player.x + player.facingX * 620;
        const targetY = useMouseTarget ? input.mouseY : player.y + player.facingY * 620;
        if (player.selectedBuild) {
            if (!player.previousFire) {
                const buildTarget = getBuildTarget(player);
                const placed = placeBuilding(player, buildTarget.x, buildTarget.y);
                const controllerPlacePressed = player.gamepad
                    && gamepadButtonPressed(player.gamepad, 0);
                if (placed && controllerPlacePressed) {
                    player.gamepadBuildMenuOpen = false;
                    player.suppressGamepadFireUntilRelease = true;
                }
            }
        } else {
            throwStone(player, targetX, targetY);
        }
    }
    player.previousFire = controls.fire;
}

function update(dt) {
    if (!running || state.gameOver || state.paused) return;
    state.time += dt;
    if (state.wave > 0) state.survival += dt;
    for (const player of state.players) updatePlayer(player, dt);
    updateCamera(dt);
    updatePointerWorld();

    updateBuildings(dt);
    updateWorkers(dt);
    updateMedics(dt);
    updateFireZones(dt);
    updateGasZones(dt);
    updateAllies(dt);
    updateProjectiles(dt);
    updateEggs(dt);
    updateEnemySpawnQueue();
    // Déplacement des policiers CHAQUE frame (glissement fluide).
    // L'IA (choix de cible) reste throttlée via aiTimer à l'intérieur de updateEnemies.
    if (state.enemies.length > 0) {
        updateEnemies(dt);
    }
    updateWeaponDrops(dt);
    updateLootDrops(dt);
    for (const zone of state.waterZones) zone.life -= dt;
    state.waterZones = state.waterZones.filter((zone) => zone.life > 0);
    for (const zone of state.explosionZones) zone.life -= dt;
    state.explosionZones = state.explosionZones.filter((zone) => zone.life > 0);
    updateParticles(dt);

    if (state.difficulty === 'tutorial') {
        advanceTutorial();
        // Pas de vagues automatiques en tutoriel
    } else {
        const remainingWaveEnemies = state.enemySpawnQueue.length > 0 || state.enemies.some((enemy) => enemy.hp > 0 && !enemy.bonusVan);
        if (state.wave > 0 && !state.waveAlert && !remainingWaveEnemies && state.lastScoredWave !== state.wave) {
            state.lastScoredWave = state.wave;
            const waveBonus = 100 + state.wave * 25;
            state.score += waveBonus;
            state.floaters.push({ x: state.core.x, y: state.core.y - 250, text: `VAGUE ${state.wave} · +${waveBonus} POINTS`, life: 2.2 });
            if (state.wave < MAX_WAVES) beginWaveAlert(2.4, true);
        }
        if (state.wave < MAX_WAVES && !state.waveAlert && state.time >= state.nextWave) beginWaveAlert();
        if (state.waveAlert) {
            state.waveAlert.timeLeft -= dt;
            const second = Math.ceil(Math.max(0, state.waveAlert.timeLeft));
            if (second !== state.waveAlert.lastSecond) {
                state.waveAlert.lastSecond = second;
                if (second <= 3 && second > 0) tone(300 + second * 80, 0.09, 'square', 0.035);
            }
            if (state.waveAlert.timeLeft <= 0) launchWave();
        }
    }
    if (state.bonusVanSpawnTime !== null && state.time >= state.bonusVanSpawnTime) spawnBonusVan();
    // Labyrinthe : atteindre la sortie sud = victoire
    if (!state.gameOver && state.map === 'maze' && mazeExit) {
        for (const player of state.players) {
            if (player.hp <= 0) continue;
            if (Math.abs(player.x - mazeExit.x) < mazeExit.w * 0.5 && Math.abs(player.y - mazeExit.y) < mazeExit.h * 0.55) {
                state.victory = true;
                endGame(true);
                showToast('SORTIE TROUVÉE · LABYRINTHE RÉUSSI');
                break;
            }
        }
    }
    if (!state.gameOver && state.wave >= MAX_WAVES && state.enemies.length === 0 && !state.waveAlert && !state.victory) {
        state.victory = true;
        if (!lyceeUnlocked) {
            lyceeUnlocked = true;
            localStorage.setItem('zoneLibre_lyceeUnlocked', '1');
            updateLyceeButton();
            showToast('MODE LYCÉE DÉBLOQUÉ !');
        }
        endGame(true);
    }
    toastTimer -= dt;
    if (toastTimer <= 0) ui.toast.style.opacity = 0;
    state.uiRefreshTimer -= dt;
    if (state.uiRefreshTimer <= 0) {
        updateUI();
        state.uiRefreshTimer = 0.18;
    }
}

function findRepairTarget(player = state.player) {
    return state.buildings
        .filter((building) => (building.type === 'barricade' || isCabin(building.type)) && building.hp > 0 && building.hp < building.maxHp - 0.01 && distance(building, player) <= repairRange)
        .sort((a, b) => distance(a, player) - distance(b, player))[0] || null;
}

function interruptRepair(message = 'RÉPARATION INTERROMPUE', player = state.player) {
    if (!player.repairTarget && player.repairProgress <= 0) return;
    player.repairTarget = null;
    player.repairProgress = 0;
    player.repairBlocked = true;
    showToast(`${player.label} · ${message}`);
}

function updateRepair(dt, player = state.player, interacting = input.keys.has('e')) {
    if (!interacting) {
        player.repairTarget = null;
        player.repairProgress = 0;
        player.repairBlocked = false;
        return;
    }
    if (player.repairBlocked) return;
    const target = findRepairTarget(player);
    if (!target) {
        if (player.repairTarget) interruptRepair('RÉPARATION INTERROMPUE', player);
        return;
    }
    if (player.repairTarget !== target) {
        player.repairTarget = target;
        player.repairProgress = 0;
    }
    player.repairProgress += dt;
    if (player.repairProgress < repairDuration) return;
    target.hp = Math.min(target.maxHp, target.hp + repairAmount);
    if (target.type === 'barricade') player.stats.barricadesRepaired++;
    else if (isCabin(target.type)) player.stats.cabinsRepaired++;
    state.score += 12;
    const targetLabel = target.type === 'barricade' ? 'BARRICADE' : target.type === 'treehouse' ? 'TOUR' : 'CABANE';
    state.floaters.push({ x: target.x, y: target.y - 78, text: `+ ${targetLabel} RÉPARÉE J${player.id + 1}`, life: 1.1 });
    burst(target.x, target.y, '#72b9a2', 12);
    tone(320, 0.16, 'triangle', 0.04);
    showToast(`${player.label} · ${targetLabel} RÉPARÉE GRATUITEMENT · RELÂCHEZ`);
    player.repairTarget = null;
    player.repairProgress = 0;
    player.repairBlocked = true;
    updateUI();
}

function pickupNearbyWeapon(player) {
    const drop = state.weaponDrops
        .filter((item) => item.life > 0 && distance(item, player) <= 105)
        .sort((a, b) => distance(a, player) - distance(b, player))[0];
    if (!drop) return false;

    const currentlyTemporary = Boolean(weapons[player.weapon]?.temporary);
    if (!player.temporaryWeapon || !currentlyTemporary) player.temporaryPreviousWeapon = player.weapon;
    if (player.temporaryWeapon && player.temporaryWeapon !== drop.weapon) player.craftedWeapons[player.temporaryWeapon] = false;
    player.temporaryWeapon = drop.weapon;
    player.temporaryWeaponTime = TEMPORARY_WEAPON_DURATION;
    player.craftedWeapons[drop.weapon] = true;
    player.weapon = drop.weapon;
    player.lastWeapon = drop.weapon;
    player.selectedBuild = null;
    state.weaponDrops = state.weaponDrops.filter((item) => item !== drop);
    const label = weapons[drop.weapon].label;
    state.floaters.push({ x: player.x, y: player.y - 75, text: `${label} · ${player.label}`, life: 1.6 });
    burst(player.x, player.y, weapons[drop.weapon].color, 15);
    showToast(`${player.label} · ${label} · ${TEMPORARY_WEAPON_DURATION} SECONDES`);
    updateUI();
    return true;
}

function updateTemporaryWeapon(player, dt) {
    if (!player.temporaryWeapon) return;
    player.temporaryWeaponTime = Math.max(0, player.temporaryWeaponTime - dt);
    if (player.temporaryWeaponTime > 0) return;

    const expiredWeapon = player.temporaryWeapon;
    player.craftedWeapons[expiredWeapon] = false;
    if (player.weapon === expiredWeapon) {
        const fallback = player.temporaryPreviousWeapon;
        player.weapon = fallback && player.craftedWeapons[fallback] ? fallback : 'slingshot';
        player.lastWeapon = player.weapon;
    } else if (player.lastWeapon === expiredWeapon) {
        player.lastWeapon = player.weapon || 'slingshot';
    }
    player.temporaryWeapon = null;
    player.temporaryWeaponTime = 0;
    player.temporaryPreviousWeapon = null;
    showToast(`${player.label} · L’ÉQUIPEMENT RÉCUPÉRÉ EST ÉPUISÉ`);
}

function updateWeaponDrops(dt) {
    for (const drop of state.weaponDrops) drop.life -= dt;
    state.weaponDrops = state.weaponDrops.filter((drop) => drop.life > 0);
}

function createLootDrop(enemy) {
    if (Math.random() >= LOOT_DROP_CHANCE || state.lootDrops.length >= 70) return;
    const roll = Math.random();
    const type = roll < 0.26 ? 'heal' : roll < 0.5 ? 'speed' : roll < 0.81 ? 'resources' : 'invulnerability';
    const drop = {
        x: enemy.x,
        y: enemy.y,
        type,
        life: LOOT_DROP_LIFETIME,
        pulse: Math.random() * Math.PI * 2
    };
    state.lootDrops.push(drop);
    const labels = { heal: 'SOIN', speed: 'VITESSE', resources: 'RESSOURCES', invulnerability: 'INVULNÉRABILITÉ' };
    state.floaters.push({ x: drop.x, y: drop.y - 48, text: labels[type], life: 1.5 });
    burst(drop.x, drop.y, type === 'heal' ? '#ff7b8d' : type === 'speed' ? '#ffe16b' : type === 'resources' ? '#8ff0b0' : '#8ad9ff', 9);
}

function pickupNearbyLoot(player, maxDist = 58) {
    const drop = state.lootDrops
        .filter((item) => item.life > 0 && distance(item, player) <= maxDist)
        .sort((a, b) => distance(a, player) - distance(b, player))[0];
    if (!drop) return false;

    let message = '';
    let color = '#8ff0b0';
    if (drop.type === 'heal') {
        const before = player.hp;
        player.hp = Math.min(player.maxHp, player.hp + 48);
        message = `+${Math.ceil(player.hp - before)} PV`;
        color = '#ff7b8d';
        if (player.hp > 0) {
            player.downed = false;
            player.downedTimer = 0;
        }
    } else if (drop.type === 'speed') {
        player.speedBoostTime = Math.max(player.speedBoostTime, PLAYER_BUFF_DURATION);
        message = `VITESSE ×1,65 · ${PLAYER_BUFF_DURATION} S`;
        color = '#ffe16b';
    } else if (drop.type === 'invulnerability') {
        player.invulnerabilityTime = Math.max(player.invulnerabilityTime, INVULN_DROP_DURATION);
        message = `INVULNÉRABLE · ${INVULN_DROP_DURATION} S`;
        color = '#8ad9ff';
    } else {
        const keys = ['wood', 'scrap', 'stone', 'fuel', 'glass'];
        const resource = keys[Math.floor(Math.random() * keys.length)];
        const amount = resource === 'fuel' || resource === 'glass' ? 2 : 3 + Math.floor(Math.random() * 2);
        player.inventory[resource] += amount;
        player.stats.resourcesGathered += amount;
        message = `+${amount} ${resourceInfo[resource].label}`;
        color = resourceInfo[resource].color;
    }

    state.lootDrops = state.lootDrops.filter((item) => item !== drop);
    state.score += 8;
    state.floaters.push({ x: player.x, y: player.y - 68, text: `${message} · J${player.id + 1}`, life: 1.7 });
    burst(player.x, player.y, color, 14);
    tone(drop.type === 'heal' ? 660 : 480, 0.18, 'sine', 0.04);
    showToast(`${player.label} · BUTIN : ${message}`);
    updateUI();
    return true;
}

function updateLootDrops(dt) {
    for (const drop of state.lootDrops) drop.life -= dt;
    state.lootDrops = state.lootDrops.filter((drop) => drop.life > 0);
}

function updateHarvest(dt, player = state.player, interacting = input.keys.has('e')) {
    const repairNearby = Boolean(findRepairTarget(player)) || player.repairTarget || player.repairBlocked;
    const nearby = state.nodes.find((node) => node.amount > 0 && distance(node, player) < 100);
    if (nearby && interacting && !repairNearby) {
        if (player.harvestNode !== nearby) player.harvest = 0;
        player.harvestNode = nearby;
        player.harvest += dt;
        const harvestDuration = Math.max(0.18, 0.55 * (1 - (player.harvestPower || 0)));
        if (player.harvest >= harvestDuration) {
            player.harvest = 0;
            nearby.amount--;
            const gatheredAmount = nearby.type === 'stone' ? 2 : 1;
            player.inventory[nearby.type] += gatheredAmount;
            player.stats.resourcesGathered += gatheredAmount;
            state.score += 2;
            state.floaters.push({ x: nearby.x, y: nearby.y - 30, text: `${resourceInfo[nearby.type].gain} · J${player.id + 1}`, life: 1 });
            tone(260 + Math.random() * 100, 0.08, 'triangle', 0.025);
            if (nearby.amount <= 0) nearby.cooldown = 22;
            updateUI();
        }
    } else {
        player.harvest = 0;
        player.harvestNode = null;
    }
    if (player === state.players.find((candidate) => candidate.hp > 0 && !candidate.eliminated)) {
        for (const node of state.nodes) {
            if (node.amount <= 0) {
                node.cooldown -= dt;
                if (node.cooldown <= 0) node.amount = 6;
            }
        }
    }
}

function updateBuildings(dt) {
    for (const building of state.buildings) {
        if ((building.type === 'shack' || building.type === 'guardShack' || building.type === 'medicShack') && building.hp > 0) {
            building.recruitTimer = (building.recruitTimer || 0) + dt;
            const isGuardPost = building.type === 'guardShack';
            const isMedicPost = building.type === 'medicShack';
            const stats = getCabinStats(building.type, building.level);
            const limit = isGuardPost ? stats.guards : isMedicPost ? stats.medics : stats.workers;
            const recruitTime = stats.recruitTime;
            const count = isGuardPost ? (building.guardCount || 0) : isMedicPost ? (building.medicCount || 0) : (building.workerCount || 0);
            if (building.recruitTimer >= recruitTime && count < limit) {
                building.recruitTimer = 0;
                if (isGuardPost) {
                    spawnAlly(building.x + (Math.random() - 0.5) * 42, building.y + 72, building, false);
                    state.floaters.push({ x: building.x, y: building.y - 70, text: '+ GUERRIER', life: 1.2 });
                    showToast('CABANE GUERRIÈRE · UN COMBATTANT EST PRÊT');
                } else if (isMedicPost) {
                    spawnMedic(building.x + (Math.random() - 0.5) * 42, building.y + 72, building);
                    state.floaters.push({ x: building.x, y: building.y - 70, text: '+ MÉDECIN', life: 1.2 });
                    showToast('CABANE MÉDIC · UN MÉDECIN PART SOIGNER');
                } else {
                    spawnWorker(building.x + (Math.random() - 0.5) * 42, building.y + 72, building);
                    state.floaters.push({ x: building.x, y: building.y - 70, text: '+ COLLECTEUR', life: 1.2 });
                    showToast('CABANE COLLECTE · UN COLLECTEUR PART EN MISSION');
                }
            }
        }
        if (building.type === 'treehouse' && building.hp > 0) {
            const stats = getCabinStats('treehouse', building.level);
            building.towerCooldown = Math.max(0, (building.towerCooldown || 0) - dt);
            // Grille spatiale au lieu de filter+sort sur toute la liste
            let target = null, bestD = Infinity;
            for (const enemy of nearbyEnemies(building.x, building.y, stats.range + 40)) {
                if (enemy.hp <= 0) continue;
                const d = distance(building, enemy);
                if (d <= stats.range && d < bestD) { bestD = d; target = enemy; }
            }
            if (target && building.towerCooldown <= 0) {
                const angle = Math.atan2(target.y - building.y, target.x - building.x);
                // 2× plus de projectiles à chaque niveau (niv1=1, niv2=2, niv3=4)
                const shotCount = Math.pow(2, Math.max(0, (building.level || 1) - 1));
                for (let s = 0; s < shotCount; s++) {
                    const spread = shotCount > 1 ? (s - (shotCount - 1) / 2) * 0.12 : 0;
                    const a = angle + spread;
                    state.projectiles.push({
                        weapon: 'tower', owner: 'tower', playerId: building.ownerId, personal: false,
                        x: building.x, y: building.y - 82,
                        vx: Math.cos(a) * 690, vy: Math.sin(a) * 690, life: 1.4,
                        radius: 8, color: '#8ff0b0', damage: stats.damage + state.wave * 2, splash: 0
                    });
                }
                building.towerCooldown = stats.cooldown;
                burst(building.x + Math.cos(angle) * 38, building.y - 82 + Math.sin(angle) * 38, '#8ff0b0', 4);
            }
        }
        if (building.burning) {
            building.burnTime -= dt;
            building.hp -= 2.2 * dt;
            if (Math.random() < dt * 12) flame(building.x + (Math.random() - 0.5) * 90, building.y - 20);
            for (const enemy of nearbyEnemies(building.x, building.y, 105 + 120)) {
                if (enemy.hp > 0 && distance(building, enemy) < 105) { enemy.lastHitPlayerId = building.ownerId ?? enemy.lastHitPlayerId; enemy.lastHitPersonal = false; enemy.hp -= 28 * dt; }
            }
            if (building.burnTime <= 0) building.burning = false;
        }
    }
    state.buildings = state.buildings.filter((building) => {
        if (building.hp > 0) return true;
        burst(building.x, building.y, '#a86c43', 18);
        if (isCabin(building.type)) {
            state.core.maxHp = Math.max(420, state.core.maxHp - cabinCoreBonus(building));
            state.core.hp = Math.min(state.core.hp, state.core.maxHp);
        }
        for (const worker of state.workers) {
            if (worker.home === building) worker.home = null;
        }
        for (const ally of state.allies) {
            if (ally.home === building) ally.home = null;
        }
        for (const medic of state.medics) {
            if (medic.home === building) medic.home = null;
        }
        if (building.type === 'guardShack') showToast('CABANE GUERRIÈRE DÉTRUITE · LES GUERRIERS REVIENNENT AU CAMP');
        else if (building.type === 'medicShack') showToast('CABANE MÉDIC DÉTRUITE · LES MÉDECINS SE REPLIENT');
        else if (building.type === 'treehouse') showToast('TOUR ARBORICOLE DÉTRUITE');
        else if (building.type === 'shack') showToast('CABANE DÉTRUITE · COLLECTEURS DÉSORIENTÉS');
        return false;
    });
}

function chooseWorkerNode(worker) {
    const candidates = state.nodes
        .filter((node) => node.amount > 0 && (!node.assignedWorker || node.assignedWorker === worker))
        .sort((a, b) => {
            const inventory = state.players[worker.ownerId || 0]?.inventory || state.resources;
            const score = (node) => distance(worker, node) / 700 + inventory[node.type] / 26;
            return score(a) - score(b);
        });
    return candidates[0] || null;
}

function releaseWorkerNode(worker) {
    if (worker.targetNode?.assignedWorker === worker) worker.targetNode.assignedWorker = null;
    worker.targetNode = null;
}

function assignWorkerNode(worker) {
    releaseWorkerNode(worker);
    const node = state.map === 'squat'
        ? state.nodes.filter(n => n.amount > 0 && n.cooldown <= 0 && n.roomId === (worker.squatRoomId ?? worker.home?.squatRoomId ?? 0) && !n.assignedWorker).sort((a,b)=>distance(worker,a)-distance(worker,b))[0]
        : chooseWorkerNode(worker);
    if (!node) {
        worker.status = 'waiting';
        worker.waitTimer = 2;
        return false;
    }
    node.assignedWorker = worker;
    worker.targetNode = node;
    worker.status = 'to-node';
    worker.harvestTimer = 0;
    return true;
}

function workerHome(worker) {
    if (worker.home && worker.home.hp > 0) return worker.home;
    worker.home = state.buildings.find((building) => building.type === 'shack' && building.hp > 0 && (building.ownerId || 0) === (worker.ownerId || 0))
        || state.buildings.find((building) => building.type === 'shack' && building.hp > 0)
        || state.core;
    if (worker.home.ownerId !== undefined) worker.ownerId = worker.home.ownerId;
    return worker.home;
}

function depositWorkerLoad(worker) {
    if (!worker.carryType || worker.carryAmount <= 0) return;
    const inventory = state.players[worker.ownerId || 0]?.inventory || state.resources;
    inventory[worker.carryType] += worker.carryAmount;
    const workerOwner = state.players[worker.ownerId || 0];
    if (workerOwner) workerOwner.stats.resourcesGathered += worker.carryAmount;
    state.score += worker.carryAmount;
    const info = resourceInfo[worker.carryType];
    state.floaters.push({
        x: worker.x,
        y: worker.y - 42,
        text: `+${worker.carryAmount} ${info?.label || worker.carryType}`,
        life: 1.15
    });
    burst(worker.x, worker.y, info?.color || '#f4b942', 6);
    worker.carryType = null;
    worker.carryAmount = 0;
}

function riverWorkerWaypoint(worker, destination) {
    if (state.map !== 'river') return destination;
    const hereR = Math.hypot(worker.x - CAMP_X, worker.y - CAMP_Y);
    const destR = Math.hypot(destination.x - CAMP_X, destination.y - CAMP_Y);
    const workerOuter = hereR >= RIVER_RING_R;
    const destOuter = destR >= RIVER_RING_R;
    // Même côté de l'anneau et pas dans l'eau → ligne droite.
    // IMPORTANT : ne PAS exiger !isOnRiverBridge. La zone "pont" est très large
    // (approches incluses) : après le milieu du pont on est déjà du bon côté
    // (workerOuter === destOuter) mais encore "onBridge" → sans ça, oscillation
    // sortie↔destination et collecteurs coincés à la sortie des ponts.
    // CORRECTIF : "même côté" se mesurait par rapport au CENTRE de l'anneau (r = RIVER_RING_R),
    // c.-à-d. au milieu de l'eau. Le collecteur était donc libéré vers sa destination dès la
    // moitié du pont et restait bloqué contre la limite latérale du pont.
    // Désormais, sur un pont, il continue tout droit jusqu'à RIVER_CROSS_EXTRA au-delà de la
    // berge avant de viser sa destination (sans dépasser la distance de la destination elle-même).
    const sameSide = workerOuter === destOuter;
    if (!sameSide) worker.riverCrossed = false;
    if (sameSide && !isInRiverWater(worker.x, worker.y)) {
        const dr = Math.abs(hereR - RIVER_RING_R);
        const destDr = Math.abs(destR - RIVER_RING_R);
        const clearDist = Math.max(RIVER_WATER_HALF - 20, Math.min(RIVER_WATER_HALF + RIVER_CROSS_EXTRA, destDr - 15));
        if (dr >= clearDist) worker.riverCrossed = true;
        // riverCrossed évite de re-viser la sortie si la trajectoire vers la destination
        // repasse un peu en dessous du seuil (pas d'aller-retour).
        if (worker.riverCrossed || !isOnRiverBridge(worker.x, worker.y)) return destination;
    }

    // Choisir le pont qui minimise le trajet complet (worker → entrée → sortie → dest).
    let bestBridge = null, bestScore = Infinity, bestEntry = null, bestExit = null;
    for (const bridge of riverBridgeZones()) {
        const entry = riverBridgeEntryForSide(bridge, workerOuter);
        const exit = riverBridgeExitForSide(bridge, destOuter);
        const score = Math.hypot(worker.x - entry.x, worker.y - entry.y)
            + Math.hypot(entry.x - exit.x, entry.y - exit.y)
            + Math.hypot(exit.x - destination.x, exit.y - destination.y);
        if (score < bestScore) {
            bestScore = score;
            bestBridge = bridge;
            bestEntry = entry;
            bestExit = exit;
        }
    }
    if (!bestBridge) return destination;

    const entry = bestEntry;
    const exit = bestExit;
    const distEntry = Math.hypot(worker.x - entry.x, worker.y - entry.y);
    const distExit = Math.hypot(worker.x - exit.x, worker.y - exit.y);

    // 1) Encore loin, pas sur le pont → rejoindre l'entrée
    if (!isOnRiverBridge(worker.x, worker.y) && distEntry > 40) {
        return entry;
    }
    // 2) Traversée en cours : rester sur l'axe et viser la sortie, située au-delà de l'eau.
    //    Plus de "déjà passé le milieu → destination" : la sortie est suivie jusqu'à ce que
    //    le collecteur ait quitté la bande d'eau (voir le test en début de fonction).
    if (distExit > 55) {
        return exit;
    }
    // 3) Arrivé à la sortie → destination finale
    return destination;
}

function updateWorkers(dt) {
    if (!state.workers.length) return;
    for (const worker of state.workers) {
        worker.stun = Math.max(0, worker.stun - dt);
        worker.slow = Math.max(0, worker.slow - dt);
        worker.flash = Math.max(0, worker.flash - dt);
        const movementFactor = worker.stun > 0 ? 0 : worker.slow > 0 ? 0.48 : 1;
        const home = workerHome(worker);
        const workerStats = getCabinStats('shack', home?.type === 'shack' ? home.level : 1);
        worker.speed = workerStats.workerSpeed;
        worker.harvestTime = workerStats.harvestTime;

        if (worker.status === 'waiting') {
            worker.waitTimer -= dt;
            if (worker.waitTimer <= 0) assignWorkerNode(worker);
            continue;
        }
        if (worker.status === 'to-node') {
            const node = worker.targetNode;
            if (!node || node.amount <= 0) {
                assignWorkerNode(worker);
                continue;
            }
            // Distance à la VRAIE destination (jamais s'arrêter sur un waypoint intermédiaire)
            const finalDist = distance(worker, node) || 1;
            if (finalDist > 58) {
                const nodeTarget = riverWorkerWaypoint(worker, node);
                const nodeDistance = distance(worker, nodeTarget) || 1;
                const wx = worker.x + (nodeTarget.x - worker.x) / nodeDistance * worker.speed * movementFactor * dt;
                const wy = worker.y + (nodeTarget.y - worker.y) / nodeDistance * worker.speed * movementFactor * dt;
                const wr = resolveRiverMove(worker, wx, wy, false);
                worker.x = wr.x;
                worker.y = wr.y;
            } else if (worker.stun <= 0) {
                worker.harvestTimer += dt;
                if (worker.harvestTimer >= worker.harvestTime) {
                    worker.harvestTimer = 0;
                    node.amount--;
                    worker.carryType = node.type;
                    worker.carryAmount = node.type === 'stone' ? 2 : 1;
                    releaseWorkerNode(worker);
                    worker.status = 'returning';
                    state.floaters.push({ x: node.x, y: node.y - 42, text: `COLLECTE · ${resourceInfo[node.type].short}`, life: 0.8 });
                    burst(node.x, node.y, resourceInfo[node.type].color, 5);
                    if (node.amount <= 0) node.cooldown = 22;
                }
            }
            continue;
        }
        if (worker.status === 'returning') {
            const realHomeDist = distance(worker, home) || 1;
            if (realHomeDist <= 85) {
                depositWorkerLoad(worker);
                assignWorkerNode(worker);
            } else {
                // Toujours avancer : waypoint intermédiaire ou cabane, sans s'arrêter avant
                const homeTarget = riverWorkerWaypoint(worker, home);
                const homeDistance = distance(worker, homeTarget) || 1;
                const wx = worker.x + (homeTarget.x - worker.x) / homeDistance * worker.speed * movementFactor * dt;
                const wy = worker.y + (homeTarget.y - worker.y) / homeDistance * worker.speed * movementFactor * dt;
                const wr = resolveRiverMove(worker, wx, wy, false);
                worker.x = wr.x;
                worker.y = wr.y;
            }
        }
    }
    const fallen = state.workers.filter((worker) => worker.hp <= 0);
    for (const worker of fallen) {
        releaseWorkerNode(worker);
        if (worker.home) worker.home.workerCount = Math.max(0, (worker.home.workerCount || 1) - 1);
        state.battleStats.collectorsFallen++;
        burst(worker.x, worker.y, '#ffb36c', 10);
        showToast('UN COLLECTEUR EST TOMBÉ');
    }
    state.workers = state.workers.filter((worker) => worker.hp > 0);
}

function updateFireZones(dt) {
    for (const zone of state.fireZones) {
        zone.life -= dt;
        if (Math.random() < dt * 16) flame(zone.x + (Math.random() - 0.5) * zone.radius, zone.y + (Math.random() - 0.5) * zone.radius);
        for (const enemy of nearbyEnemies(zone.x, zone.y, zone.radius + 120)) {
            if (enemy.hp > 0 && distance(zone, enemy) < zone.radius + enemy.radius) { enemy.lastHitPlayerId = zone.ownerId ?? enemy.lastHitPlayerId; enemy.lastHitPersonal = true; enemy.hp -= 42 * dt; }
        }
    }
    state.fireZones = state.fireZones.filter((zone) => zone.life > 0);
}

function updateGasZones(dt) {
    for (const zone of state.gasZones) {
        zone.life -= dt;
        if (Math.random() < dt * 2) burst(zone.x + (Math.random() - 0.5) * zone.radius, zone.y + (Math.random() - 0.5) * zone.radius, '#b8e46d', 1);
        for (const player of state.players) {
            if (player.hp > 0 && distance(zone, player) < zone.radius + player.radius) player.slow = Math.max(player.slow, 0.8);
        }
        for (const ally of state.allies) {
            if (distance(zone, ally) < zone.radius + ally.radius) ally.slow = Math.max(ally.slow || 0, 0.8);
        }
        for (const worker of state.workers) {
            if (distance(zone, worker) < zone.radius + worker.radius) worker.slow = Math.max(worker.slow || 0, 0.8);
        }
        for (const medic of state.medics) {
            if (distance(zone, medic) < zone.radius + medic.radius) medic.slow = Math.max(medic.slow || 0, 0.8);
        }
    }
    state.gasZones = state.gasZones.filter((zone) => zone.life > 0);
}

function spawnWorker(x, y, home) {
    const stats = getCabinStats('shack', home?.type === 'shack' ? home.level : 1);
    const worker = {
        x: Math.max(45, Math.min(WORLD_W - 45, x)),
        y: Math.max(60, Math.min(WORLD_H - 45, y)),
        radius: 19,
        hp: 58,
        maxHp: 58,
        stun: 0,
        slow: 0,
        speed: stats.workerSpeed,
        harvestTime: stats.harvestTime,
        home,
        ownerId: home?.ownerId || 0,
        targetNode: null,
        status: 'waiting',
        waitTimer: 0.25 + Math.random() * 0.45,
        harvestTimer: 0,
        carryType: null,
        carryAmount: 0,
        flash: 0
    };
    state.workers.push(worker);
    if (home) home.workerCount = (home.workerCount || 0) + 1;
    burst(worker.x, worker.y, '#f4b942', 8);
    return worker;
}

function getMedicTarget(medic) {
    const stats = getCabinStats('medicShack', medic.home?.type === 'medicShack' ? medic.home.level : 1);
    const injured = [...state.players, ...state.allies, ...state.workers]
        .filter((entity) => entity.hp > 0 && entity.hp < entity.maxHp - 0.01 && distance(medic, entity) <= stats.range)
        .sort((a, b) => distance(medic, a) - distance(medic, b));
    return injured[0] || null;
}

function spawnMedic(x, y, home = null) {
    const stats = getCabinStats('medicShack', home?.type === 'medicShack' ? home.level : 1);
    const medic = {
        x: Math.max(45, Math.min(WORLD_W - 45, x)),
        y: Math.max(60, Math.min(WORLD_H - 45, y)),
        radius: 21,
        hp: 70,
        maxHp: 70,
        stun: 0,
        slow: 0,
        speed: stats.speed,
        home,
        target: null,
        healTimer: 0,
        healPulse: 0,
        flash: 0
    };
    state.medics.push(medic);
    if (home) home.medicCount = (home.medicCount || 0) + 1;
    burst(medic.x, medic.y, '#f4f1d0', 9);
    return medic;
}

function updateMedics(dt) {
    for (const medic of state.medics) {
        medic.stun = Math.max(0, medic.stun - dt);
        medic.slow = Math.max(0, (medic.slow || 0) - dt);
        medic.flash = Math.max(0, medic.flash - dt);
        const home = medic.home?.type === 'medicShack' && medic.home.hp > 0 ? medic.home : state.core;
        const stats = getCabinStats('medicShack', medic.home?.type === 'medicShack' ? medic.home.level : 1);
        medic.speed = stats.speed;
        const target = getMedicTarget(medic);
        medic.target = target;
        const movementFactor = medic.stun > 0 ? 0 : medic.slow > 0 ? 0.48 : 1;
        if (target) {
            const targetDistance = distance(medic, target) || 1;
            const stop = medic.radius + target.radius + 22;
            if (targetDistance > stop && medic.stun <= 0) {
                const mx = medic.x + (target.x - medic.x) / targetDistance * medic.speed * movementFactor * dt;
                const my = medic.y + (target.y - medic.y) / targetDistance * medic.speed * movementFactor * dt;
                const mr = resolveRiverMove(medic, mx, my, false);
                medic.x = mr.x;
                medic.y = mr.y;
            } else if (medic.stun <= 0) {
                medic.healTimer += dt;
                medic.healPulse += dt;
                target.hp = Math.min(target.maxHp, target.hp + stats.healRate * dt);
                if (medic.healTimer >= MEDIC_HEAL_INTERVAL) {
                    medic.healTimer = 0;
                    state.floaters.push({ x: target.x, y: target.y - 48, text: '+ SOINS', life: 0.75 });
                    burst(target.x, target.y, '#f4f1d0', 4);
                    tone(680, 0.06, 'sine', 0.018);
                }
            }
            continue;
        }
        medic.healTimer = 0;
        const homeDistance = distance(medic, home) || 1;
        if (homeDistance > 92 && medic.stun <= 0) {
            const mx = medic.x + (home.x - medic.x) / homeDistance * medic.speed * movementFactor * dt;
            const my = medic.y + (home.y - medic.y) / homeDistance * medic.speed * movementFactor * dt;
            const mr = resolveRiverMove(medic, mx, my, false);
            medic.x = mr.x;
            medic.y = mr.y;
        }
    }
    const fallen = state.medics.filter((medic) => medic.hp <= 0);
    for (const medic of fallen) {
        if (medic.home) medic.home.medicCount = Math.max(0, (medic.home.medicCount || 1) - 1);
        state.battleStats.medicsFallen++;
        burst(medic.x, medic.y, '#f4f1d0', 12);
        showToast('UN MÉDECIN EST TOMBÉ');
    }
    state.medics = state.medics.filter((medic) => medic.hp > 0);
}

function spawnAlly(x, y, home = null, veteran = false, ownerId = null) {
    if (state?.map === 'squat' && !squatPointAllowed(x, y)) {
        const safe = squatWaveSpawnPoint();
        x = safe.x; y = safe.y;
    }
    const stats = getCabinStats('guardShack', home?.type === 'guardShack' ? home.level : 1);
    const ally = {
        x: Math.max(45, Math.min(WORLD_W - 45, x)),
        y: Math.max(60, Math.min(WORLD_H - 45, y)),
        radius: 23,
        hp: veteran ? 115 : 82,
        maxHp: veteran ? 115 : 82,
        stun: 0,
        slow: 0,
        speed: veteran ? 145 * MOVEMENT_SPEED_MULTIPLIER : stats.speed,
        attackCooldown: 0.35 + Math.random() * 0.45,
        attackInterval: veteran ? 0.72 : stats.attackInterval,
        damage: veteran ? 25 : stats.damage,
        range: veteran ? 330 : stats.range,
        home,
        veteran,
        flash: 0,
        targetEnemy: null,
        targetScanTimer: Math.random() * 0.35,
        ownerId: ownerId ?? home?.ownerId ?? null
    };
    state.allies.push(ally);
    if (home) home.guardCount = (home.guardCount || 0) + 1;
    burst(ally.x, ally.y, veteran ? '#f4b942' : '#72b9a2', veteran ? 12 : 7);
    return ally;
}

function spawnReinforcements(countOverride = null, toastMessage = null) {
    const count = countOverride ?? Math.min(7 + Math.floor(state.wave / 5) * 2, 13);
    for (let i = 0; i < count; i++) {
        const side = i % 3;
        const x = side === 0
            ? 180 + Math.random() * 620
            : side === 1
                ? 2420 + Math.random() * 620
                : 1180 + Math.random() * 840;
        const y = 1540 + Math.random() * 80;
        spawnAlly(x, y, null, true);
    }
    state.score += count * 10;
    showToast(toastMessage || `RENFORTS POPULAIRES · ${count} ALLIÉS AU CAMP`);
    tone(260, 0.45, 'triangle', 0.07);
}

function updateAllies(dt) {
    for (const ally of state.allies) {
        ally.attackCooldown -= dt;
        ally.stun = Math.max(0, ally.stun - dt);
        ally.slow = Math.max(0, (ally.slow || 0) - dt);
        ally.flash = Math.max(0, ally.flash - dt);
        if (!ally.veteran && ally.home?.type === 'guardShack' && ally.home.hp > 0) {
            const guardStats = getCabinStats('guardShack', ally.home.level);
            ally.speed = guardStats.speed;
            ally.damage = guardStats.damage;
            ally.range = guardStats.range;
            ally.attackInterval = guardStats.attackInterval;
        }
        // Rechercher la cible à intervalles espacés évite, au lycée, un tri complet
        // de centaines de policiers pour chacun des nombreux alliés à chaque frame.
        ally.targetScanTimer -= dt;
        let target = ally.targetEnemy;
        if (!target || target.hp <= 0 || ally.targetScanTimer <= 0) {
            target = null;
            let bestDistanceSquared = Infinity;
            // Grille spatiale uniquement — plus de scan O(alliés × ennemis)
            for (const enemy of nearbyEnemies(ally.x, ally.y, 900)) {
                if (enemy.hp <= 0) continue;
                const dx = enemy.x - ally.x;
                const dy = enemy.y - ally.y;
                const distanceSquared = dx * dx + dy * dy;
                if (distanceSquared < bestDistanceSquared) {
                    bestDistanceSquared = distanceSquared;
                    target = enemy;
                }
            }
            ally.targetEnemy = target;
            const scanInterval = state.enemies.length > 120 ? 0.55 : 0.28;
            ally.targetScanTimer = scanInterval + Math.random() * scanInterval * 0.25;
        }
        if (!target) {
            const homeTarget = ally.home?.hp > 0 ? ally.home : state.core;
            const homeDistance = distance(ally, homeTarget);
            if (homeDistance > 90) {
                const ax = ally.x + (homeTarget.x - ally.x) / homeDistance * ally.speed * dt;
                const ay = ally.y + (homeTarget.y - ally.y) / homeDistance * ally.speed * dt;
                const ar = resolveRiverMove(ally, ax, ay, false);
                ally.x = ar.x;
                ally.y = ar.y;
            }
            continue;
        }
        const targetDistance = distance(ally, target) || 1;
        if (targetDistance > ally.range * 0.8 && ally.stun <= 0) {
            const allyMoveFactor = ally.slow > 0 ? 0.48 : 1;
            const ax = ally.x + (target.x - ally.x) / targetDistance * ally.speed * allyMoveFactor * dt;
            const ay = ally.y + (target.y - ally.y) / targetDistance * ally.speed * allyMoveFactor * dt;
            const ar = resolveRiverMove(ally, ax, ay, false);
            ally.x = ar.x;
            ally.y = ar.y;
        }
        if (targetDistance <= ally.range && ally.attackCooldown <= 0 && ally.stun <= 0) {
            const angle = Math.atan2(target.y - ally.y, target.x - ally.x);
            state.projectiles.push({
                weapon: 'ally',
                owner: 'ally',
                playerId: ally.ownerId,
                personal: false,
                x: ally.x,
                y: ally.y - 12,
                vx: Math.cos(angle) * 560,
                vy: Math.sin(angle) * 560,
                life: 0.9,
                radius: 7,
                color: ally.veteran ? '#f4b942' : '#8bd9bb',
                damage: ally.damage,
                splash: 0
            });
            ally.attackCooldown = ally.attackInterval || (ally.veteran ? 0.72 : 1.05);
            tone(520, 0.045, 'triangle', 0.012);
        }
    }
    const fallen = state.allies.filter((ally) => ally.hp <= 0);
    for (const ally of fallen) {
        if (ally.home) ally.home.guardCount = Math.max(0, (ally.home.guardCount || 1) - 1);
        state.battleStats.warriorsFallen++;
        burst(ally.x, ally.y, '#ff8c68', 12);
    }
    state.allies = state.allies.filter((ally) => ally.hp > 0);
}

function detonateFirework(projectile, primaryEnemy = null) {
    for (const enemy of nearbyEnemies(projectile.x, projectile.y, projectile.splash + 120)) {
        if (enemy === primaryEnemy || enemy.hp <= 0 || distance(projectile, enemy) > projectile.splash + enemy.radius) continue;
        enemy.lastHitPlayerId = projectile.playerId ?? 0;
        enemy.lastHitPersonal = projectile.personal !== false;
        enemy.hp -= projectile.damage * (enemy.supported ? 0.62 : 1);
        enemy.flash = 0.18;
        if (enemy.infiltrator) enemy.revealed = true;
    }
    burst(projectile.x, projectile.y, '#ff6fb5', 12);
    burst(projectile.x, projectile.y, '#ffe27a', 8);
    showToast('FEUX D’ARTIFICES · IMPACT EN ZONE');
}

function fireF4Grenade(enemy, target) {
    const targetX = Math.max(45, Math.min(WORLD_W - 45, target.x));
    const targetY = Math.max(55, Math.min(WORLD_H - 45, target.y));
    const angle = Math.atan2(targetY - enemy.y, targetX - enemy.x);
    enemy.facingX = Math.cos(angle);
    enemy.facingY = Math.sin(angle);
    state.projectiles.push({
        weapon: 'grenadeF4', owner: 'enemy', grenadeF4: true,
        x: enemy.x, y: enemy.y - 12, originX: enemy.x, originY: enemy.y - 12,
        targetX, targetY, fuse: F4_GRENADE_FUSE, life: F4_GRENADE_FUSE,
        radius: 14, splash: F4_GRENADE_RADIUS, color: '#ff6b45', damage: 42
    });
    tone(235, 0.12, 'square', 0.04);
}

function detonateF4Grenade(projectile) {
    const blast = { x: projectile.targetX, y: projectile.targetY, radius: projectile.splash };
    state.explosionZones.push({ ...blast, life: 0.58 });
    for (const player of state.players) {
        if (player.hp <= 0 || player.permanentInvulnerability || player.invulnerabilityTime > 0 || distance(blast, player) > blast.radius + player.radius) continue;
        damagePlayer(player, projectile.damage);
        player.stun = Math.max(player.stun, 0.8);
        player.slow = Math.max(player.slow, 0.7);
    }
    for (const ally of state.allies) {
        if (distance(blast, ally) <= blast.radius + ally.radius) ally.hp -= 58;
    }
    for (const worker of state.workers) {
        if (distance(blast, worker) <= blast.radius + worker.radius) worker.hp -= 48;
    }
    for (const medic of state.medics) {
        if (distance(blast, medic) <= blast.radius + medic.radius) medic.hp -= 48;
    }
    for (const building of state.buildings) {
        if (distance(blast, building) <= blast.radius + building.radius * 0.5) building.hp -= 72;
    }
    if (distance(blast, state.core) <= blast.radius + state.core.radius * 0.25) {
        state.core.hp = Math.max(0, state.core.hp - 58);
    }
    projectile.life = 0;
    burst(blast.x, blast.y, '#ff7349', 14);
    burst(blast.x, blast.y, '#ffd978', 8);
    tone(82, 0.34, 'sawtooth', 0.07);
}

function updateProjectiles(dt) {
    for (const projectile of state.projectiles) {
        if (projectile.grenadeF4) {
            projectile.fuse = Math.max(0, projectile.fuse - dt);
            projectile.life = projectile.fuse;
            const progress = 1 - projectile.fuse / F4_GRENADE_FUSE;
            projectile.x = projectile.originX + (projectile.targetX - projectile.originX) * progress;
            projectile.y = projectile.originY + (projectile.targetY - projectile.originY) * progress - Math.sin(progress * Math.PI) * 190;
            if (projectile.fuse <= 0) detonateF4Grenade(projectile);
            continue;
        }
        projectile.x += projectile.vx * dt;
        projectile.y += projectile.vy * dt;
        projectile.life -= dt;
        if (projectile.melee) {
            if (projectile.life > 0) {
                for (const enemy of nearbyEnemies(projectile.x, projectile.y, projectile.radius + 120)) {
                    if (projectile.hitEnemies.has(enemy) || enemy.hp <= 0 || distance(projectile, enemy) >= projectile.radius + enemy.radius) continue;
                    projectile.hitEnemies.add(enemy);
                    enemy.lastHitPlayerId = projectile.playerId ?? 0;
                    enemy.lastHitPersonal = projectile.personal !== false;
                    enemy.hp -= projectile.damage * (enemy.supported ? 0.62 : 1);
                    enemy.flash = 0.16;
                    burst(enemy.x, enemy.y, '#f4b942', 8);
                }
            }
            continue;
        }
        if (projectile.firework && projectile.life <= 0) {
            detonateFirework(projectile);
            continue;
        }
        if (projectile.owner === 'enemy') {
            const target = projectile.target;
            if (projectile.life > 0 && target && target.hp > 0 && distance(projectile, target) < projectile.radius + target.radius) {
                if (isPlayerEntity(target)) damagePlayer(target, projectile.damage);
                else target.hp -= projectile.damage;
                if (isPlayerEntity(target)) {
                    interruptRepair('PROJECTILE — RÉPARATION INTERROMPUE', target);
                    if (projectile.effect === 'flashball') {
                        target.slow = Math.max(target.slow, 2.8);
                        target.stun = Math.max(target.stun, 0.65);
                        showToast(`${target.label} · FLASHBALL · MOUVEMENTS RALENTIS`);
                    }
                    if (projectile.effect === 'sniper') {
                        target.stun = Math.max(target.stun, 1.8);
                        target.blind = Math.max(target.blind, 1.2);
                        showToast(`${target.label} · TIR LBD · ÉTOURDIE`);
                    }
                } else {
                    target.flash = 0.2;
                    if (projectile.effect === 'flashball') target.stun = Math.max(target.stun || 0, 1.1);
                }
                projectile.life = 0;
                burst(projectile.x, projectile.y, projectile.color || '#ff9b67', 10);
                tone(projectile.effect === 'sniper' ? 75 : 150, 0.14, 'square', 0.04);
            }
            continue;
        }
        for (const enemy of nearbyEnemies(projectile.x, projectile.y, projectile.radius + 120)) {
            if (projectile.life <= 0 || enemy.hp <= 0 || distance(projectile, enemy) >= projectile.radius + enemy.radius) continue;
            const incomingDot = projectile.vx * (enemy.facingX || 0) + projectile.vy * (enemy.facingY || 0);
            const shieldedFromFront = enemy.shield && enemy.guardDown <= 0 && incomingDot < -0.2 && !projectile.splash && !projectile.melee;
            if (shieldedFromFront) {
                projectile.life = 0;
                enemy.lastHitPlayerId = projectile.playerId ?? enemy.lastHitPlayerId;
                enemy.lastHitPersonal = projectile.personal !== false;
                enemy.hp -= projectile.damage * 0.28;
                enemy.flash = 0.08;
                burst(projectile.x, projectile.y, '#dce9f0', 10);
                if (Math.random() < 0.18) showToast('BOUCLIER · LES TIRS DE FACE SONT RÉDUITS');
                continue;
            }
            if (enemy.infiltrator) enemy.revealed = true;
            enemy.lastHitPlayerId = projectile.playerId ?? 0;
            enemy.lastHitPersonal = projectile.personal !== false;
            const resistance = enemy.supported ? 0.62 : 1;
            enemy.hp -= projectile.damage * resistance;
            enemy.flash = 0.12;
            if (projectile.splash && enemy.shield) enemy.guardDown = 3;
            projectile.life = 0;
            burst(projectile.x, projectile.y, projectile.color, 8);
            if (projectile.firework) detonateFirework(projectile, enemy);
            else if (projectile.splash) {
                state.fireZones.push({ x: projectile.x, y: projectile.y, radius: projectile.splash, life: 5, ownerId: projectile.playerId ?? null });
                burst(projectile.x, projectile.y, '#ff7137', 20);
            }
        }
    }
    state.projectiles = state.projectiles.filter((projectile) => projectile.life > 0 && projectile.x > -120 && projectile.x < WORLD_W + 120 && projectile.y > -120 && projectile.y < WORLD_H + 120);
}

function updateEggs(dt) {
    if (!state.eggs || !state.eggs.length) return;
    for (let i = state.eggs.length - 1; i >= 0; i--) {
        const egg = state.eggs[i];
        egg.hatchTimer -= dt;
        if (egg.hatchTimer <= 0) {
            // Éclosion → policier BAC (un seul, pas de multi-copie)
            spawnEnemy('bac', egg.x, egg.y, 'hunter', Math.random() < 0.5 ? -1 : 1, true);
            burst(egg.x, egg.y, '#4a9eff', 14);
            showToast('ŒUF · BAC ÉCLOS');
            tone(180, 0.25, 'square', 0.05);
            state.eggs.splice(i, 1);
        }
    }
}

function fireEnemyProjectile(enemy, target, effect, damage, color, speed = 520) {
    const angle = Math.atan2(target.y - enemy.y, target.x - enemy.x);
    state.projectiles.push({
        weapon: effect,
        owner: 'enemy',
        effect,
        x: enemy.x,
        y: enemy.y - (enemy.air ? 35 : 8),
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: 2.2,
        radius: effect === 'sniper' ? 13 : 10,
        color,
        damage,
        target
    });
}

function pushEntity(entity, source, amount) {
    const length = distance(entity, source) || 1;
    entity.x = Math.max(40, Math.min(WORLD_W - 40, entity.x + (entity.x - source.x) / length * amount));
    entity.y = Math.max(55, Math.min(WORLD_H - 45, entity.y + (entity.y - source.y) / length * amount));
}

function waterBlast(enemy, target) {
    // Jet style lance-flammes : cône d'eau continue vers la cible
    if (!enemy || !state) return;
    const tx = target && Number.isFinite(target.x) ? target.x : enemy.x + (enemy.facingX || 0) * 280;
    const ty = target && Number.isFinite(target.y) ? target.y : enemy.y + (enemy.facingY || 1) * 280;
    const angle = Math.atan2(ty - enemy.y, tx - enemy.x);
    enemy.facingX = Math.cos(angle);
    enemy.facingY = Math.sin(angle);
    const range = 320;
    const coneHalf = 0.42; // radians ~24°

    // Cap pour éviter explosion mémoire / freeze en vague 10+
    if (state.waterZones.length > 90) {
        state.waterZones.splice(0, state.waterZones.length - 60);
    }
    // Particules / zones d'eau le long du jet
    for (let i = 0; i < 5; i++) {
        const dist = 70 + i * 48 + Math.random() * 14;
        const spread = (Math.random() - 0.5) * coneHalf * 1.3;
        const a = angle + spread;
        state.waterZones.push({
            x: enemy.x + Math.cos(a) * dist,
            y: enemy.y + Math.sin(a) * dist,
            radius: 36 + i * 5,
            life: 0.22 + Math.random() * 0.12
        });
    }

    const inCone = (entity, extraR = 0) => {
        if (!entity || !Number.isFinite(entity.x) || !Number.isFinite(entity.y)) return false;
        const dx = entity.x - enemy.x;
        const dy = entity.y - enemy.y;
        const d = Math.hypot(dx, dy);
        if (d > range + extraR) return false;
        if (d < 40) return true;
        const ang = Math.atan2(dy, dx);
        let diff = ang - angle;
        while (diff > Math.PI) diff -= Math.PI * 2;
        while (diff < -Math.PI) diff += Math.PI * 2;
        return Math.abs(diff) <= coneHalf + 0.08;
    };

    for (const player of state.players) {
        if (player.hp <= 0 || !inCone(player, player.radius)) continue;
        damagePlayer(player, 14);
        player.slow = Math.max(player.slow, 1.5);
        pushEntity(player, enemy, 55);
        interruptRepair('JET DU CAMION — RÉPARATION INTERROMPUE', player);
    }
    for (const ally of state.allies) {
        if (!inCone(ally, ally.radius)) continue;
        ally.hp -= 18;
        ally.stun = Math.max(ally.stun, 0.55);
        pushEntity(ally, enemy, 50);
    }
    for (const worker of state.workers) {
        if (!inCone(worker, worker.radius || 20)) continue;
        worker.hp -= 18;
        worker.stun = Math.max(worker.stun || 0, 0.6);
        pushEntity(worker, enemy, 50);
    }
    for (const medic of state.medics) {
        if (!inCone(medic, medic.radius || 20)) continue;
        medic.hp -= 18;
        medic.stun = Math.max(medic.stun || 0, 0.6);
        pushEntity(medic, enemy, 50);
    }
    for (const building of state.buildings) {
        if (!inCone(building, building.radius * 0.45)) continue;
        building.hp -= 28;
        building.burning = false;
        building.burnTime = 0;
    }
    if (state.core && inCone(state.core, (state.core.radius || 40) * 0.2)) {
        state.core.hp = Math.max(0, state.core.hp - 18);
    }
    for (const zone of state.fireZones) {
        if (zone && inCone(zone, zone.radius || 0)) zone.life = 0;
    }
    state.fireZones = state.fireZones.filter((zone) => zone.life > 0);
    const jetX = enemy.x + Math.cos(angle) * 160;
    const jetY = enemy.y + Math.sin(angle) * 160;
    tone(190, 0.12, 'sawtooth', 0.03);
    burst(jetX, jetY, '#8ad9ff', 18);
    tone(70, 0.2, 'sawtooth', 0.05);
}

function explodeDemineur(enemy) {
    enemy.hp = 0;
    for (const player of state.players) {
        if (player.hp > 0 && distance(enemy, player) < 250) {
            player.blind = Math.max(player.blind, 4);
            player.stun = Math.max(player.stun, 2.2);
        }
    }
    for (const ally of state.allies) {
        if (distance(enemy, ally) < 250) {
            ally.stun = Math.max(ally.stun, 4);
            ally.flash = 0.4;
        }
    }
    for (const worker of state.workers) {
        if (distance(enemy, worker) < 250) {
            worker.stun = Math.max(worker.stun, 4);
            worker.flash = 0.4;
        }
    }
    for (const building of state.buildings) {
        if (distance(enemy, building) < 220) building.hp -= 80;
    }
    burst(enemy.x, enemy.y, '#f7f5dc', 38);
    showToast('FLASHBANG · VISION BROUILLÉE');
    tone(900, 0.6, 'sine', 0.07);
}

function dropPoliceWeapon(enemy) {
    const weapon = enemy.type === 'flashball'
        ? 'policeFlashball'
        : enemy.type === 'sniper'
            ? 'policeLbd'
            : null;
    if (!weapon || Math.random() > (weapon === 'policeFlashball' ? 0.68 : 0.58)) return;
    state.weaponDrops.push({
        x: enemy.x,
        y: enemy.y,
        weapon,
        life: WEAPON_DROP_LIFETIME,
        pulse: Math.random() * Math.PI * 2
    });
    const shortName = weapon === 'policeFlashball' ? 'FLASHBALL' : 'LBD';
    state.floaters.push({ x: enemy.x, y: enemy.y - 52, text: `${shortName} AU SOL · E POUR RAMASSER`, life: 2.1 });
    burst(enemy.x, enemy.y, weapons[weapon].color, 10);
}

function rebuildEnemyGrid() {
    const cellSize = 430;
    const enemyGrid = new Map();
    const allyGrid = new Map();
    const barricadeGrid = new Map();
    const cabinGrid = new Map();
    const addToGrid = (grid, entity) => {
        const key = `${Math.floor(entity.x / cellSize)},${Math.floor(entity.y / cellSize)}`;
        let bucket = grid.get(key);
        if (!bucket) { bucket = []; grid.set(key, bucket); }
        bucket.push(entity);
    };
    for (const enemy of state.enemies) {
        if (enemy.hp > 0) addToGrid(enemyGrid, enemy);
    }
    for (const ally of state.allies) {
        if (ally.hp > 0) addToGrid(allyGrid, ally);
    }
    const barricades = [];
    for (const building of state.buildings) {
        if (building.hp <= 0) continue;
        if (building.type === 'barricade') {
            barricades.push(building);
            addToGrid(barricadeGrid, building);
        } else if (isCabin(building.type)) {
            addToGrid(cabinGrid, building);
        }
    }
    state.enemyGrid = enemyGrid;
    state.allyGrid = allyGrid;
    state.barricadeGrid = barricadeGrid;
    state.cabinGrid = cabinGrid;
    state.barricadeList = barricades;
}

function rebuildSupportGrid() {
    const cellSize = 430;
    const grid = new Map();
    for (const support of state.enemies) {
        if (!support.support || support.hp <= 0) continue;
        const cx = Math.floor(support.x / cellSize);
        const cy = Math.floor(support.y / cellSize);
        const key = `${cx},${cy}`;
        let bucket = grid.get(key);
        if (!bucket) { bucket = []; grid.set(key, bucket); }
        bucket.push(support);
    }
    state.supportGrid = grid;
}

function isSupportedByNearbyUnit(enemy) {
    if (enemy.support) return false;
    const cellSize = 430;
    const cx = Math.floor(enemy.x / cellSize);
    const cy = Math.floor(enemy.y / cellSize);
    const maxD2 = 430 * 430;
    for (let ox = -1; ox <= 1; ox++) {
        for (let oy = -1; oy <= 1; oy++) {
            const bucket = state.supportGrid.get(`${cx + ox},${cy + oy}`);
            if (!bucket) continue;
            for (const support of bucket) {
                const dx = enemy.x - support.x;
                const dy = enemy.y - support.y;
                if (dx * dx + dy * dy < maxD2) return true;
            }
        }
    }
    return false;
}

function getPlayerLevelForKills(kills) {
    if (kills < PLAYER_LEVEL_THRESHOLDS[1]) return 1;
    if (kills < PLAYER_LEVEL_THRESHOLDS[2]) return 2;
    if (kills < PLAYER_LEVEL_THRESHOLDS[3]) return 3;
    if (kills < PLAYER_LEVEL_THRESHOLDS[4]) return 4;
    if (kills < PLAYER_LEVEL_THRESHOLDS[5]) return 5;
    if (kills < PLAYER_LEVEL_THRESHOLDS[6]) return 6;
    if (kills < PLAYER_LEVEL_THRESHOLDS[7]) return 7;
    if (kills < PLAYER_LEVEL_THRESHOLDS[8]) return 8;
    if (kills < PLAYER_LEVEL_THRESHOLDS[9]) return 9;
    return 10 + Math.floor((kills - PLAYER_LEVEL_THRESHOLDS[9]) / 10000);
}

function nextPlayerLevelKills(level) {
    if (level < PLAYER_LEVEL_THRESHOLDS.length) return PLAYER_LEVEL_THRESHOLDS[level];
    return 30000 + (level - 10 + 1) * 10000;
}

function chooseThreePowers(player) {
    const available = PLAYER_POWER_KEYS.filter((key) => !player.chosenPowers.includes(key));
    const pool = available.length >= 3 ? available : PLAYER_POWER_KEYS;
    return [...pool].sort(() => Math.random() - 0.5).slice(0, 3);
}

function queuePlayerLevelUp(player) {
    // Compat : le système est désormais collectif
    queueTeamLevelUps();
}

function awardPoliceKill(enemy) {
    // Les éliminations des guerriers alliés comptent aussi pour les niveaux d'équipe.
    // Les autres dégâts non attribués (tours, environnement) conservent l'ancien comportement.
    const ownerId = Number.isInteger(enemy.lastHitPlayerId) ? enemy.lastHitPlayerId : null;
    const player = ownerId !== null ? state.players[ownerId] : null;
    if (player) player.stats.policeKilled++;
    else if (enemy.lastHitPersonal !== false && state.players[0]) state.players[0].stats.policeKilled++;
    else if (enemy.lastHitByAlly) {
        if (state.players[0]) state.players[0].stats.policeKilled++;
    } else return;
    queueTeamLevelUps();
}

function getTeamPoliceKills() {
    if (!state?.players) return 0;
    return state.players.reduce((sum, p) => sum + (p.stats?.policeKilled || 0), 0);
}

function queueTeamLevelUps() {
    if (!state?.players?.length) return;
    const scale = getPolicePlayerScale();
    const teamKills = getTeamPoliceKills();
    // Seuil effectif = seuil solo × nb joueurs (collectif doublé/triplé/…)
    const effectiveKills = Math.floor(teamKills / scale);
    const teamLevel = getPlayerLevelForKills(effectiveKills);
    let any = false;
    for (const p of state.players) {
        while (p.level < teamLevel) {
            p.level++;
            state.powerQueue.push({ playerId: p.id, level: p.level, choices: chooseThreePowers(p), selected: null, confirmed: false });
            any = true;
        }
        p.nextLevelKills = nextPlayerLevelKills(p.level) * scale;
    }
    if (any) showNextPowerChoice();
}

function applyPlayerPower(player, powerKey) {
    if (!player || !PLAYER_POWER_DEFS[powerKey]) return;
    player.chosenPowers.push(powerKey);
    if (powerKey === 'harvest') player.harvestPower += 0.10;
    if (powerKey === 'cabinDiscount') player.cabinDiscount = Math.min(0.50, player.cabinDiscount + 0.10);
    if (powerKey === 'speed') { player.speedPower += 0.10; }
    if (powerKey === 'life') {
        const oldMax = player.maxHp;
        player.maxHp = Math.round(player.maxHp * 1.10);
        player.hp = Math.min(player.maxHp, Math.round(player.hp + (player.maxHp - oldMax)));
    }
    if (powerKey === 'resources') {
        for (const key of Object.keys(state.sharedResources)) state.sharedResources[key] += 10;
    }
    if (powerKey === 'bomb') {
        let count = 0;
        for (const enemy of state.enemies) { if (enemy.hp > 0) { enemy.hp = 0; enemy.noKillCredit = true; count++; } }
        state.enemySpawnQueue = [];
        burst(player.x, player.y, '#ff6b45', 70);
        showToast(`${player.label} · ÉMEUTE RÉVOLUTIONNAIRE · ${count} POLICIERS NEUTRALISÉS · SANS XP DE NIVEAU`);
    }
    if (powerKey === 'warriors') {
        for (let i = 0; i < 10; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = 70 + Math.random() * 170;
            spawnAlly(player.x + Math.cos(angle) * dist, player.y + Math.sin(angle) * dist, null, true, player.id);
        }
        showToast(`${player.label} · 10 GUERRIERS ARRIVENT`);
    }
    updateUI();
}

function showNextPowerChoice() {
    if (!state?.powerQueue?.length) {
        state.powerChoices = null;
        state.paused = false;
        return;
    }
    const next = state.powerQueue[0];
    state.powerChoices = next;
    state.paused = true;
    renderPowerChoice();
}

function renderPowerChoice() {
    const overlay = document.querySelector('#power-choice');
    if (!overlay || !state?.powerChoices) return;
    const entry = state.powerChoices;
    const player = state.players?.[entry.playerId];
    if (!player || !Array.isArray(entry.choices) || !entry.choices.length) {
        console.error('Choix de niveau invalide :', entry);
        state.powerQueue.shift();
        state.powerChoices = null;
        showNextPowerChoice();
        return;
    }
    const teamKills = typeof getTeamPoliceKills === 'function' ? getTeamPoliceKills() : (player.stats.policeKilled || 0);
    const scale = typeof getPolicePlayerScale === 'function' ? getPolicePlayerScale() : 1;
    const selected = entry.selected || null;
    const options = entry.choices.map((key, index) => {
        const active = selected === key ? ' selected' : '';
        return `<button type="button" class="power-option${active}" data-power="${key}"><b>${index + 1}</b><strong>${PLAYER_POWER_DEFS[key].label}</strong><span>${PLAYER_POWER_DEFS[key].short}</span></button>`;
    }).join('');
    overlay.innerHTML = `<div class="power-card"><button type="button" class="power-close" title="Passer" aria-label="Fermer">✕</button><div class="power-kicker">${player.label} · NIVEAU ${entry.level}</div><h2>GAIN DE NIVEAU</h2><p>Équipe : ${teamKills.toLocaleString('fr-FR')} policiers · ×${scale} joueur${scale > 1 ? 's' : ''}<br>Sélectionnez un pouvoir puis validez avec <b>OK</b> (✕ pour passer)</p><div class="power-options">${options}</div><div class="power-actions"><button type="button" class="power-ok"${selected ? '' : ' disabled'}>OK</button></div><small>1 · 2 · 3 sélection · Entrée / OK valider · Échap / ✕ passer</small></div>`;
    overlay.classList.remove('hidden');
    overlay.setAttribute('aria-hidden', 'false');
    overlay.querySelectorAll('.power-option').forEach((button) => {
        button.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            entry.selected = button.dataset.power;
            renderPowerChoice();
        });
    });
    overlay.querySelector('.power-ok')?.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (entry.selected) confirmCurrentPower();
    });
    overlay.querySelector('.power-close')?.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        skipCurrentPower();
    });
}

function confirmCurrentPower() {
    if (!state?.powerChoices || !state.powerChoices.selected) return;
    const powerKey = state.powerChoices.selected;
    if (state.powerChoices.choices.indexOf(powerKey) < 0) return;
    const entry = state.powerQueue[0];
    const player = state.players?.[entry?.playerId];
    if (!entry || !player || !PLAYER_POWER_DEFS[powerKey]) {
        console.error('Impossible de valider le pouvoir de niveau', {entry, powerKey});
        state.powerQueue.shift(); state.powerChoices = null; showNextPowerChoice(); return;
    }
    state.powerQueue.shift();
    applyPlayerPower(player, powerKey);
    state.powerChoices = null;
    const overlay = document.querySelector('#power-choice');
    overlay?.classList.add('hidden');
    overlay?.setAttribute('aria-hidden', 'true');
    showNextPowerChoice();
}

function skipCurrentPower() {
    if (!state?.powerChoices) return;
    if (!window.confirm('Passer ce pouvoir sans le recevoir ?')) return;
    state.powerQueue.shift();
    state.powerChoices = null;
    const overlay = document.querySelector('#power-choice');
    overlay?.classList.add('hidden');
    overlay?.setAttribute('aria-hidden', 'true');
    showToast('POUVOIR PASSÉ');
    showNextPowerChoice();
}

function chooseCurrentPower(powerKey) {
    if (!state?.powerChoices || state.powerChoices.choices.indexOf(powerKey) < 0) return;
    state.powerChoices.selected = powerKey;
    confirmCurrentPower();
}

function handlePowerChoiceInput() {
    if (!state?.powerChoices) return false;
    const indexByKey = { Digit1: 0, Digit2: 1, Digit3: 2, Numpad1: 0, Numpad2: 1, Numpad3: 2 };
    for (const [code, index] of Object.entries(indexByKey)) {
        if (input.codes.has(code)) {
            const key = state.powerChoices.choices[index];
            if (key) { state.powerChoices.selected = key; renderPowerChoice(); }
            return true;
        }
    }
    if (input.codes.has('Enter') || input.codes.has('NumpadEnter')) {
        if (state.powerChoices.selected) confirmCurrentPower();
        return true;
    }
    if (input.codes.has('Escape')) {
        return true;
    }
    return false;
}

function updateEnemies(dt) {
    // Aucun policier : ne pas reconstruire les grilles ni boucler pour rien (gros gain avant vague 1).
    if (!state.enemies.length) {
        state.supportGridTimer = 0;
        return;
    }
    state.supportGridTimer -= dt;
    if (state.supportGridTimer <= 0) {
        rebuildEnemyGrid();
        rebuildSupportGrid();
        state.supportGridTimer = ENEMY_SUPPORT_INTERVAL;
    }
    for (const enemy of state.enemies) {
        enemy.flash -= dt;
        enemy.attackCooldown -= dt;
        enemy.guardDown = Math.max(0, enemy.guardDown - dt);
        enemy.tackleCooldown = Math.max(0, enemy.tackleCooldown - dt);
        enemy.gasCooldown -= dt;
        enemy.supportTimer -= dt;
        const crowdSize = state.enemies.length;
        const supportTick = enemy.supportTimer <= 0;
        // En grosse foule, le soutien n'est recalculé que pour ~1 unité sur 3.
        if (supportTick) {
            if (crowdSize < 100 || (enemy.aiSlot % 3) === (Math.floor(state.time * 5) % 3)) {
                enemy.supported = isSupportedByNearbyUnit(enemy);
            }
            enemy.supportTimer = ENEMY_SUPPORT_INTERVAL + (crowdSize > 160 ? 0.12 : 0);
        }
        // La recherche du joueur le plus proche est coûteuse quand la foule est grande.
        // Elle est donc mise en cache et recalculée seulement lors du tick IA de l'unité.
        const aiDue = enemy.aiTimer <= 0 || !enemy.cachedTargetInfo || !enemy.cachedTargetInfo.entity || enemy.cachedTargetInfo.entity.hp <= 0;
        if (aiDue) {
            enemy.nearestPlayer = nearestLivingPlayer(enemy);
            enemy.nearestPlayerDistance = enemy.nearestPlayer ? Math.hypot(enemy.x - enemy.nearestPlayer.x, enemy.y - enemy.nearestPlayer.y) : Infinity;
        } else if (enemy.nearestPlayer) {
            // Distance cheap update without full search
            enemy.nearestPlayerDistance = Math.hypot(enemy.x - enemy.nearestPlayer.x, enemy.y - enemy.nearestPlayer.y);
        }
        const nearestPlayer = enemy.nearestPlayer;
        if (enemy.infiltrator && nearestPlayer && enemy.nearestPlayerDistance < 260) enemy.revealed = true;
        if (enemy.bonusVan) continue;

        // Macron : boss qui fuit le joueur et pond des œufs bleus (BAC)
        if (enemy.macron) {
            const FLEE_DIST = 420;
            const LAY_INTERVAL = 3;
            const LAY_DURATION = 1;
            if (nearestPlayer && enemy.nearestPlayerDistance < FLEE_DIST) {
                enemy.fleeing = true;
                enemy.laying = 0;
            } else {
                enemy.fleeing = false;
            }
            if (enemy.fleeing && nearestPlayer) {
                // Fuite rapide à l'opposé du joueur
                const dx = enemy.x - nearestPlayer.x;
                const dy = enemy.y - nearestPlayer.y;
                const dist = Math.hypot(dx, dy) || 1;
                const fleeSpeed = enemy.speed * 1.35;
                enemy.vx = (dx / dist) * fleeSpeed;
                enemy.vy = (dy / dist) * fleeSpeed;
                enemy.x += enemy.vx * dt;
                enemy.y += enemy.vy * dt;
                enemy.facingX = dx / dist;
                enemy.facingY = dy / dist;
                // Clamp monde
                enemy.x = Math.max(enemy.radius + 20, Math.min(WORLD_W - enemy.radius - 20, enemy.x));
                enemy.y = Math.max(enemy.radius + 20, Math.min(WORLD_H - enemy.radius - 20, enemy.y));
            } else if (enemy.laying > 0) {
                // En train de pondre : immobile
                enemy.laying -= dt;
                enemy.vx = 0;
                enemy.vy = 0;
                if (enemy.laying <= 0) {
                    // Pondre l'œuf
                    state.eggs.push({
                        x: enemy.x + (Math.random() - 0.5) * 40,
                        y: enemy.y + 30,
                        hatchTimer: 1,
                        radius: 22
                    });
                    enemy.eggTimer = LAY_INTERVAL;
                    showToast('MACRON · ŒUF BLEU PONDU');
                }
            } else {
                // Déplacement normal + timer de ponte
                enemy.eggTimer -= dt;
                if (enemy.eggTimer <= 0) {
                    enemy.laying = LAY_DURATION;
                } else {
                    // Cible de errance stable (changée toutes les ~2s)
                    if (!enemy.wanderX || !enemy.wanderTimer || enemy.wanderTimer <= 0) {
                        enemy.wanderX = CAMP_X + (Math.random() - 0.5) * 1200;
                        enemy.wanderY = CAMP_Y + (Math.random() - 0.5) * 900;
                        enemy.wanderTimer = 1.5 + Math.random() * 1.5;
                    }
                    enemy.wanderTimer -= dt;
                    const ad = Math.hypot(enemy.wanderX - enemy.x, enemy.wanderY - enemy.y) || 1;
                    const moveSpeed = enemy.speed * 0.75;
                    enemy.vx = (enemy.wanderX - enemy.x) / ad * moveSpeed;
                    enemy.vy = (enemy.wanderY - enemy.y) / ad * moveSpeed;
                    enemy.x += enemy.vx * dt;
                    enemy.y += enemy.vy * dt;
                    const fl = Math.hypot(enemy.vx, enemy.vy) || 1;
                    enemy.facingX = enemy.vx / fl;
                    enemy.facingY = enemy.vy / fl;
                    enemy.x = Math.max(enemy.radius + 20, Math.min(WORLD_W - enemy.radius - 20, enemy.x));
                    enemy.y = Math.max(enemy.radius + 20, Math.min(WORLD_H - enemy.radius - 20, enemy.y));
                }
            }
            continue;
        }

        if (enemy.drone) {
            const target = nearestPlayer || { x: CAMP_X, y: CAMP_Y };
            const angle = state.time * 0.45 + enemy.flankSide;
            const targetX = target.x + Math.cos(angle) * 320;
            const targetY = target.y - 180 + Math.sin(angle) * 190;
            const orbitDistance = Math.hypot(targetX - enemy.x, targetY - enemy.y) || 1;
            enemy.facingX = (targetX - enemy.x) / orbitDistance;
            enemy.facingY = (targetY - enemy.y) / orbitDistance;
            enemy.x += enemy.facingX * enemy.speed * dt;
            enemy.y += enemy.facingY * enemy.speed * dt;
            if (nearestPlayer && distance(enemy, nearestPlayer) < 900) {
                nearestPlayer.marked = Math.max(nearestPlayer.marked, 0.3);
                if (enemy.gasCooldown <= 0) {
                    state.gasZones.push({ x: nearestPlayer.x, y: nearestPlayer.y, radius: 105, life: 5 });
                    enemy.gasCooldown = 7;
                    showToast(`DRONE · ${nearestPlayer.label} REPÉRÉ·E · GAZ LARGUÉ`);
                }
            }
            continue;
        }
        if (enemy.sniper) {
            enemy.aimTarget = nearestPlayer;
            if (nearestPlayer) {
                enemy.aimTime += dt;
                if (enemy.aimTime >= 3 && enemy.attackCooldown <= 0) {
                    fireEnemyProjectile(enemy, nearestPlayer, 'sniper', enemy.damage, '#ff3f4e', 760);
                    enemy.attackCooldown = 4.8;
                    enemy.aimTime = 0;
                }
            } else {
                enemy.aimTime = 0;
            }
            continue;
        }
        if (enemy.support) {
            // Les soins ne sont appliqués qu'au rythme du supportTimer, pas 60 fois/s.
            if (supportTick) {
                const cellSize = 430;
                const cx = Math.floor(enemy.x / cellSize);
                const cy = Math.floor(enemy.y / cellSize);
                const maxD2 = 340 * 340;
                for (let ox = -1; ox <= 1; ox++) {
                    for (let oy = -1; oy <= 1; oy++) {
                        const bucket = state.enemyGrid.get(`${cx + ox},${cy + oy}`);
                        if (!bucket) continue;
                        for (const nearby of bucket) {
                            if (nearby === enemy || nearby.hp <= 0) continue;
                            const dx = nearby.x - enemy.x;
                            const dy = nearby.y - enemy.y;
                            if (dx * dx + dy * dy < maxD2) nearby.hp = Math.min(nearby.maxHp, nearby.hp + 4 * ENEMY_SUPPORT_INTERVAL);
                        }
                    }
                }
            }
            continue;
        }
        if (enemy.handler && !enemy.released && nearestPlayer && distance(enemy, nearestPlayer) < 300) {
            enemy.released = true;
            queueEnemySpawn('dog', enemy.x - 25, enemy.y + 12, 'hunter', enemy.flankSide);
            showToast('BRIGADE CANINE · LE CHIEN EST LÂCHÉ');
        }

        enemy.aiTimer -= dt;
        let targetInfo = enemy.cachedTargetInfo;
        // Avec une grosse foule, on répartit les décisions IA sur plusieurs frames.
        // Le déplacement continue avec la dernière cible connue.
        if (!targetInfo || !targetInfo.entity || targetInfo.entity.hp <= 0) {
            targetInfo = selectEnemyTarget(enemy);
            enemy.cachedTargetInfo = targetInfo;
            enemy.aiTimer = ENEMY_AI_INTERVAL;
        } else if (enemy.aiTimer <= 0) {
            const crowd = state.enemies.length;
            const budget = crowd > 200 ? Math.floor(CROWD_AI_BUDGET * 0.7) : CROWD_AI_BUDGET;
            if (crowd <= budget || enemy.aiSlot === undefined || ((enemyAiCursor++) % crowd) < budget) {
                targetInfo = selectEnemyTarget(enemy);
                enemy.cachedTargetInfo = targetInfo;
                enemy.aiTimer = ENEMY_AI_INTERVAL + (crowd > 160 ? 0.08 : 0);
            } else {
                enemy.aiTimer = 0.04;
            }
        }
        const target = targetInfo?.entity;
        if (!target || !Number.isFinite(target.x) || !Number.isFinite(target.y)) {
            continue;
        }
        const d = distance(enemy, target) || 1;
        const stop = enemy.radius + (target.radius || 30) - 5;
        const speedBoost = target.marked > 0 ? 1.28 : 1;
        const supportBoost = enemy.supported ? 1.16 : 1;
        const step = enemy.speed * speedBoost * supportBoost * dt;

        if (enemy.grenadier) {
            const grenadeTarget = nearestPlayer && distance(enemy, nearestPlayer) <= 1080 ? nearestPlayer : target;
            const grenadeDistance = distance(enemy, grenadeTarget);
            if (grenadeDistance <= 1080 && grenadeDistance >= 220 && enemy.attackCooldown <= 0) {
                fireF4Grenade(enemy, grenadeTarget);
                // Cadence plus élevée plus les vagues avancent
                enemy.attackCooldown = Math.max(2.4, 5.8 - state.wave * 0.12);
            }
        }
        if (enemy.type === 'water_cannon' && d <= 520 && enemy.attackCooldown <= 0) {
            waterBlast(enemy, target);
            enemy.attackCooldown = 0.55;
            continue;
        }

        if (enemy.ranged && targetInfo.kind === 'player' && d < 780 && enemy.attackCooldown <= 0) {
            fireEnemyProjectile(enemy, target, 'flashball', enemy.damage, '#ffdd76');
            enemy.attackCooldown = 2.3;
        }
        if (enemy.flameThrower && d < 245 && enemy.attackCooldown <= 0) {
            enemy.attackCooldown = 0.62;
            const angle = Math.atan2(target.y - enemy.y, target.x - enemy.x);
            for (const building of state.buildings) {
                const dot = (building.x - enemy.x) * Math.cos(angle) + (building.y - enemy.y) * Math.sin(angle);
                if (dot > 0 && dot < 250 && Math.abs((building.x - enemy.x) * Math.sin(angle) - (building.y - enemy.y) * Math.cos(angle)) < 110) {
                    building.hp -= 32;
                    building.burning = true;
                    building.burnTime = Math.max(building.burnTime || 0, 3);
                }
            }
            if (isPlayerEntity(target)) {
                damagePlayer(target, 7);
                target.slow = Math.max(target.slow, 1.2);
            }
            flame(enemy.x + Math.cos(angle) * 100, enemy.y + Math.sin(angle) * 100);
        }
        if (enemy.kamikaze && d <= stop + 22) {
            explodeDemineur(enemy);
            continue;
        }
        if (d > stop && !(enemy.ranged && d < 540)) {
            let aimX = target.x;
            let aimY = target.y;
            if (state.map === 'squat' && !enemy.air) {
                // Dans le donjon, un policier rejoint d'abord le couloir ouvert qui mène
                // vers la salle du joueur au lieu de pousser contre un mur.
                const enemyRoom = squatRoomForPoint(enemy.x, enemy.y);
                const targetRoom = squatRoomForPoint(target.x, target.y);
                if (targetRoom) {
                    if (enemyRoom && enemyRoom.id !== targetRoom.id) {
                        const direction = targetRoom.id > enemyRoom.id ? 1 : -1;
                        const door = SQUAT_DOORS.find(d => d.open &&
                            ((d.a === enemyRoom.id && d.b === enemyRoom.id + direction) ||
                             (d.b === enemyRoom.id && d.a === enemyRoom.id + direction)));
                        if (door) { aimX = door.x; aimY = door.y; }
                    } else if (!enemyRoom) {
                        const corridor = squatCorridorForPoint(enemy.x, enemy.y);
                        if (corridor?.open) {
                            const nextRoomId = Math.abs(corridor.a - targetRoom.id) < Math.abs(corridor.b - targetRoom.id) ? corridor.a : corridor.b;
                            const nextRoom = SQUAT_ROOMS[nextRoomId];
                            aimX = nextRoom.x; aimY = nextRoom.y;
                        }
                    }
                }
            }
            if (state.map === 'lycee' && !enemy.air && Number.isFinite(enemy.lyceeRouteX) && enemy.y < LYCEE_ROUTE_CLEAR_Y) {
                // Garder chaque unité au sol dans son axe dégagé jusqu'à avoir dépassé
                // les bâtiments du nord, puis reprendre sa trajectoire vers la cible.
                aimX = enemy.lyceeRouteX;
                aimY = Math.max(target.y, LYCEE_ROUTE_CLEAR_Y + 70);
            }
            // Rivière : entrée (notre rive) → sortie (rive cible) — points LOIN du centre
            if (state.map === 'river' && !enemy.air) {
                const fromOuter = Math.hypot(enemy.x - CAMP_X, enemy.y - CAMP_Y) >= RIVER_RING_R;
                const toOuter = Math.hypot(target.x - CAMP_X, target.y - CAMP_Y) >= RIVER_RING_R;
                // Aussi forcer un pont si le segment droit traverse l'eau (même côté "outer"
                // mais de part et d'autre de l'anneau, ex. barricade mal placée).
                let pathCrossesWater = false;
                if (fromOuter === toOuter && !isInRiverWater(enemy.x, enemy.y) && !isOnRiverBridge(enemy.x, enemy.y)) {
                    for (let s = 0.15; s < 0.9; s += 0.15) {
                        const sx = enemy.x + (target.x - enemy.x) * s;
                        const sy = enemy.y + (target.y - enemy.y) * s;
                        if (isInRiverWater(sx, sy)) { pathCrossesWater = true; break; }
                    }
                }
                if (fromOuter !== toOuter || isInRiverWater(enemy.x, enemy.y) || isOnRiverBridge(enemy.x, enemy.y) || pathCrossesWater) {
                    // Pont qui minimise le trajet complet (évite de choisir le mauvais pont)
                    let bestBridge = null, bestScore = Infinity, bestEntry = null, bestExit = null;
                    for (const bridge of riverBridgeZones()) {
                        const entry = riverBridgeEntryForSide(bridge, fromOuter);
                        const exit = riverBridgeExitForSide(bridge, toOuter);
                        const score = Math.hypot(enemy.x - entry.x, enemy.y - entry.y)
                            + Math.hypot(entry.x - exit.x, entry.y - exit.y)
                            + Math.hypot(exit.x - target.x, exit.y - target.y);
                        if (score < bestScore) {
                            bestScore = score;
                            bestBridge = bridge;
                            bestEntry = entry;
                            bestExit = exit;
                        }
                    }
                    if (bestBridge) {
                        const entry = bestEntry;
                        const exit = bestExit;
                        const distEntry = Math.hypot(enemy.x - entry.x, enemy.y - entry.y);
                        const distExit = Math.hypot(enemy.x - exit.x, enemy.y - exit.y);
                        const c = Math.cos(-bestBridge.angle);
                        const s = Math.sin(-bestBridge.angle);
                        const lx = (enemy.x - bestBridge.x) * c - (enemy.y - bestBridge.y) * s;
                        const destSign = toOuter ? 1 : -1;
                        const pastMidTowardDest = lx * destSign > 40;
                        // Même côté de l'anneau (déjà traversé) → viser la cible, pas le pont
                        if (fromOuter === toOuter && !isInRiverWater(enemy.x, enemy.y)) {
                            // laisser aim = target
                        } else if (!isOnRiverBridge(enemy.x, enemy.y) && !pastMidTowardDest && distEntry > 40) {
                            aimX = entry.x; aimY = entry.y;
                        } else if (distExit > 55 && !pastMidTowardDest) {
                            aimX = exit.x; aimY = exit.y;
                        }
                        // sinon laisser aim = target (déjà de l'autre côté / sortie atteinte)
                    }
                }
            }
            // Stocker la cible de déplacement pour le glissement continu chaque frame
            enemy.moveAimX = aimX;
            enemy.moveAimY = aimY;
            enemy.moveSpeed = enemy.speed * speedBoost * supportBoost;
            const ad = Math.hypot(aimX - enemy.x, aimY - enemy.y) || 1;
            const desiredVx = (aimX - enemy.x) / ad * enemy.moveSpeed;
            const desiredVy = (aimY - enemy.y) / ad * enemy.moveSpeed;
            // Lissage fort pour un vrai glissement (surtout BAC / unités rapides)
            const smooth = 1 - Math.exp(-18 * dt);
            enemy.vx = (enemy.vx || 0) * (1 - smooth) + desiredVx * smooth;
            enemy.vy = (enemy.vy || 0) * (1 - smooth) + desiredVy * smooth;
            const nextX = enemy.x + enemy.vx * dt;
            const nextY = enemy.y + enemy.vy * dt;
            const faceLen = Math.hypot(enemy.vx, enemy.vy) || 1;
            enemy.facingX = enemy.vx / faceLen;
            enemy.facingY = enemy.vy / faceLen;
            const canBeBlocked = BARRICADE_BLOCKING_ENEMIES.has(enemy.type);
            const barrier = canBeBlocked ? blockingBarricade(enemy, nextX, nextY) : null;
            if (barrier) {
                const barrierDistance = distance(enemy, barrier) || 1;
                const separation = enemy.radius + barrier.radius + 1;
                enemy.x = barrier.x + (enemy.x - barrier.x) / barrierDistance * separation;
                enemy.y = barrier.y + (enemy.y - barrier.y) / barrierDistance * separation;
                enemy.vx = 0;
                enemy.vy = 0;
                if (enemy.attackCooldown <= 0) {
                    barrier.hp -= enemy.damage;
                    enemy.attackCooldown = enemy.type === 'helicopter' ? 1.1 : 0.8;
                    burst(barrier.x, barrier.y, '#ff6b4a', 5);
                    tone(110, 0.1, 'square', 0.025);
                }
            } else {
                const resolved = resolveRiverMove(enemy, nextX, nextY, Boolean(enemy.air));
                if (resolved.x === enemy.x && resolved.y === enemy.y) {
                    enemy.vx *= 0.3;
                    enemy.vy *= 0.3;
                }
                enemy.x = resolved.x;
                enemy.y = resolved.y;
            }
        } else {
            // À portée (ou ranged en stand-off) : freiner pour supprimer les mini-sauts résiduels
            enemy.vx = (enemy.vx || 0) * 0.5;
            enemy.vy = (enemy.vy || 0) * 0.5;
        }
        if (d <= stop && enemy.attackCooldown <= 0) {
            if (enemy.type === 'water_cannon' && targetInfo.kind === 'barricade') {
                target.hp -= enemy.damage;
                waterBlast(enemy);
                enemy.attackCooldown = 1.8;
                showToast('CAMION LANCE-EAU · BARRICADE ENDOMMAGÉE');
                continue;
            }
            const damageTarget = targetInfo.entity;
            const isPlayerTarget = isPlayerEntity(damageTarget);
            if (isPlayerTarget && damageTarget.damageCooldown > 0) {
                enemy.attackCooldown = 0.2;
                continue;
            }
            if (isPlayerTarget) {
                interruptRepair('TOUCHÉ·E — RÉPARATION INTERROMPUE', damageTarget);
                damageTarget.damageCooldown = 0.42;
                if (enemy.tackle) {
                    damageTarget.stun = Math.max(damageTarget.stun, 2.2);
                    showToast(`${damageTarget.label} · PLAQUAGE BAC · IMMOBILISÉ·E`);
                }
                if (enemy.driveby) pushEntity(damageTarget, enemy, 95);
                if (enemy.missile) damageTarget.slow = Math.max(damageTarget.slow, 2.4);
            }
            if (isPlayerTarget) damagePlayer(damageTarget, enemy.damage);
            else damageTarget.hp -= enemy.damage;
            if (!isPlayerTarget && damageTarget !== state.core) damageTarget.flash = 0.15;
            if (enemy.type === 'water_cannon') waterBlast(enemy);
            enemy.revealed = enemy.infiltrator ? true : enemy.revealed;
            enemy.attackCooldown = enemy.type === 'helicopter' ? 1.1 : enemy.driveby ? 1.2 : 0.8;
            if (enemy.missile) enemy.hp = 0;
            burst(damageTarget.x + (Math.random() - 0.5) * 40, damageTarget.y, '#ff6b4a', 5);
            tone(110, 0.1, 'square', 0.025);
        }
    }
    const defeated = state.enemies.filter((enemy) => enemy.hp <= 0);
    const scoreValues = { officer: 50, shield_crs: 130, flashball: 125, water_cannon: 1000, infiltrator: 160, bac: 155, canine: 180, dog: 60, moto: 240, quad: 190, drone: 220, megaphone: 260, sniper: 230, demineur: 260, flamethrower: 340, van: 180, bonusVan: 420, tank: 320, helicopter: 450 };
    for (const enemy of defeated) {
        const killCreditAllowed = !enemy.noKillCredit;
        state.battleStats.policeKilled[enemy.type] = (state.battleStats.policeKilled[enemy.type] || 0) + 1;
        state.score += scoreValues[enemy.type] || 100;
        if (killCreditAllowed) awardPoliceKill(enemy);
        burst(enemy.x, enemy.y, enemy.boss ? '#8ad9ff' : enemy.type === 'drone' ? '#f4b942' : '#79b8ad', 18);
        // Tache de sang au sol (1 minute)
        if (enemy.type !== 'drone' && enemy.type !== 'helicopter') {
            state.bloodStains.push({
                x: enemy.x + (Math.random() - 0.5) * 12,
                y: enemy.y + (Math.random() - 0.5) * 12,
                life: 60,
                maxLife: 60,
                scale: 0.85 + Math.random() * 0.35 + (enemy.boss ? 0.4 : 0),
                rotation: Math.random() * Math.PI * 2
            });
            // Cap pour éviter trop de flaques en vague haute
            if (state.bloodStains.length > MAX_BLOOD_STAINS) {
                state.bloodStains.splice(0, state.bloodStains.length - MAX_BLOOD_STAINS);
            }
        }
        dropPoliceWeapon(enemy);
        createLootDrop(enemy);
        if (enemy.type === 'van') {
            for (let i = 0; i < 4; i++) queueEnemySpawn('officer', enemy.x + (i - 1.5) * 34, enemy.y + 20);
            showToast('LE CAMION EST OUVERT — RENFORTS À PIED');
        }
        if (enemy.type === 'bonusVan') {
            state.bonusVan = null;
            state.bonusVanNextWave = state.wave + 4 + Math.floor(Math.random() * 3);
            state.bonusVanSpawnTime = null;
            spawnReinforcements(4, 'CAMION DÉTRUIT · 4 RENFORTS ALLIÉS');
            state.floaters.push({ x: enemy.x, y: enemy.y - 92, text: '+ 4 RENFORTS', life: 1.8 });
        }
        if (Math.random() < 0.35) {
            const owner = state.players[enemy.lastHitPlayerId] || state.player;
            owner.inventory.stone += 2;
        }
    }
    state.enemies = state.enemies.filter((enemy) => enemy.hp > 0);
    if (!state.players.some((player) => player.hp > 0 || player.downed)) endGame(false);
}

function burst(x, y, color, count) {
    // Cap global : trop de particules = lag visible en fin de vague.
    const room = Math.max(0, MAX_PARTICLES - state.particles.length);
    if (room <= 0) return;
    const n = Math.min(count, room);
    for (let i = 0; i < n; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 50 + Math.random() * 180;
        state.particles.push({ x, y, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed, life: 0.35 + Math.random() * 0.5, maxLife: 0.85, color, size: 3 + Math.random() * 5 });
    }
}

function flame(x, y) {
    if (state.particles.length >= MAX_PARTICLES) return;
    state.particles.push({ x, y, vx: (Math.random() - 0.5) * 25, vy: -80 - Math.random() * 80, life: 0.4 + Math.random() * 0.4, maxLife: 0.8, color: Math.random() > 0.5 ? '#ffb22f' : '#ff5238', size: 10 + Math.random() * 10 });
}

function updateParticles(dt) {
    for (let i = state.particles.length - 1; i >= 0; i--) {
        const particle = state.particles[i];
        particle.x += particle.vx * dt;
        particle.y += particle.vy * dt;
        particle.vx *= 0.96;
        particle.life -= dt;
        if (particle.life <= 0) state.particles.splice(i, 1);
    }
    for (let i = state.floaters.length - 1; i >= 0; i--) {
        const floater = state.floaters[i];
        floater.y -= 35 * dt;
        floater.life -= dt;
        if (floater.life <= 0) state.floaters.splice(i, 1);
    }
    if (state.floaters.length > MAX_FLOATERS) state.floaters.splice(0, state.floaters.length - MAX_FLOATERS);
    // Flaques de sang : disparaissent après 1 minute
    if (state.bloodStains?.length) {
        for (const stain of state.bloodStains) stain.life -= dt;
        state.bloodStains = state.bloodStains.filter((stain) => stain.life > 0);
    }
}

function drawBloodStains() {
    if (!state.bloodStains?.length) return;
    const img = images.bloodStain;
    const hasImg = img?.complete && img.naturalWidth > 0;
    const vx = camera.x, vy = camera.y, vw = W / camera.zoom, vh = H / camera.zoom;
    for (const stain of state.bloodStains) {
        if (stain.x < vx - 200 || stain.x > vx + vw + 200 || stain.y < vy - 200 || stain.y > vy + vh + 200) continue;
        const fade = stain.life < 8 ? Math.max(0, stain.life / 8) : 1;
        const size = 180 * (stain.scale || 1);
        ctx.save();
        ctx.translate(stain.x, stain.y);
        ctx.rotate(stain.rotation || 0);
        ctx.globalAlpha = 0.82 * fade;
        if (hasImg) {
            ctx.drawImage(img, -size / 2, -size / 2, size, size);
        } else {
            ctx.fillStyle = '#6b0a12';
            ctx.beginPath();
            ctx.ellipse(0, 0, size * 0.42, size * 0.32, 0, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.restore();
    }
    ctx.globalAlpha = 1;
}

function endGame(victory) {
    if (state.gameOver) return;
    state.gameOver = true;
    running = false;
    // Le coup qui met fin à la partie peut tomber après le passage des unités alliées.
    // Comptabiliser ici les pertes encore présentes évite de les omettre du rapport final.
    for (const medic of state.medics.filter((unit) => unit.hp <= 0)) state.battleStats.medicsFallen++;
    for (const worker of state.workers.filter((unit) => unit.hp <= 0)) state.battleStats.collectorsFallen++;
    for (const ally of state.allies.filter((unit) => unit.hp <= 0)) state.battleStats.warriorsFallen++;
    const leaderboard = saveLocalRun();
    window.ProgressLogger?.logProgress(victory ? 'survival_victory' : 'camp_overrun', { score: state.score, wave: state.wave, survival: Math.round(state.survival) });
    const defeatCount = state.players.filter((player) => player.hp <= 0).length;
    const defeatTitle = defeatCount > 1 ? 'ÉQUIPE À TERRE' : 'SURVIVANT À TERRE';
    const defeatLine = defeatCount > 1 ? 'Toute l’équipe est tombée ; la zone ne peut plus être défendue.' : 'Vous avez été neutralisé ; la zone ne peut plus être défendue.';
    const playerStatRows = state.players.map((player) => `<div class="player-stat-column" style="--player-color:${player.color}"><h3>J${player.id + 1}</h3><strong>${player.label}</strong><div><span>Flics tués</span><b>${player.stats.policeKilled}</b></div><div><span>Ressources récoltées</span><b>${player.stats.resourcesGathered}</b></div><div><span>Cabanes réparées</span><b>${player.stats.cabinsRepaired}</b></div><div><span>Barricades réparées</span><b>${player.stats.barricadesRepaired}</b></div><div><span>Niveau</span><b>${player.level}</b></div></div>`).join('');
    const policeRows = Object.entries(POLICE_REPORT_LABELS)
        .map(([type, label]) => `<div class="report-row"><span>${label}</span><b>${state.battleStats.policeKilled[type] || 0}</b></div>`)
        .join('');
    const totalPolice = Object.values(state.battleStats.policeKilled).reduce((sum, count) => sum + count, 0);
    const cabinsBuilt = state.battleStats.cabinsBuilt || 0;
    const barricadesBuilt = state.battleStats.barricadesBuilt || 0;
    const rankLine = leaderboard.rank
        ? `Votre résultat est classé #${leaderboard.rank} parmi les 10 meilleurs scores de cet appareil.`
        : 'Partie enregistrée localement ; le top 10 reste inchangé.';
    ui.overlay.innerHTML = `<div class="card result-card"><h1 class="${victory ? '' : 'danger'}">${victory ? 'EXPULSION CONTENUE' : defeatTitle}</h1><p>${victory ? 'Le camp a tenu pendant toute l’expulsion.' : defeatLine}</p><p>Vous avez tenu <b>${formatTime(state.survival)}</b>, atteint la vague <b>${state.wave}</b> et marqué <b>${state.score.toLocaleString('fr-FR')}</b> points.</p><section class="local-ranking result-ranking"><h3>CLASSEMENT LOCAL · CET APPAREIL</h3><p>${rankLine}</p><div class="ranking-list">${leaderboardRows(leaderboard.entries, leaderboard.record.id)}</div></section><div class="report-title">STATS DES JOUEURS</div><div class="player-stat-grid">${playerStatRows}</div><div class="report-title">RAPPORT DE L’EXPULSION</div><div class="report-summary"><span>Police neutralisée <b>${totalPolice}</b></span><span>Médecins tombés <b>${state.battleStats.medicsFallen}</b></span><span>Collecteurs tombés <b>${state.battleStats.collectorsFallen}</b></span><span>Guerriers tombés <b>${state.battleStats.warriorsFallen}</b></span><span>Cabanes construites <b>${cabinsBuilt}</b></span><span>Barricades construites <b>${barricadesBuilt}</b></span></div><div class="report-title">POLICIERS NEUTRALISÉS PAR TYPE</div><div class="report-grid">${policeRows}</div><div class="pause-actions" style="margin-top:18px;display:flex;gap:12px;flex-wrap:wrap;justify-content:center"><button id="restart" type="button">RECOMMENCER · MÊME CARTE</button><button id="result-menu" type="button" class="secondary">MENU PRINCIPAL · CHANGER DE CARTE</button></div></div>`;
    ui.overlay.classList.remove('hidden');
    const lastDifficulty = state.difficulty;
    document.querySelector('#restart')?.addEventListener('click', () => startGame(lastDifficulty));
    document.querySelector('#result-menu')?.addEventListener('click', () => showMainMenu());
}

function updateUI() {
    const shared = state.sharedResources || state.resources;
    const resourceUi = { wood: 'resourceWood', stone: 'resourceStone', scrap: 'resourceScrap', fuel: 'resourceFuel', glass: 'resourceGlass' };
    const resourceLabels = { wood: 'BOIS', stone: 'PIERRE', scrap: 'FERRAILLE', fuel: 'ESSENCE', glass: 'VERRE' };
    const resourceBar = document.querySelector('#resource-bar');
    if (resourceBar && shared) {
        resourceBar.innerHTML = Object.entries(resourceLabels).map(([key, label]) => `<div class="resource-chip"><img src="${assetPaths[resourceUi[key]]}" alt="${label}"><span><small>${label}</small><b>${shared[key]}</b></span></div>`).join('') + `<div class="kill-chip"><small>POLICIERS ÉLIMINÉS</small><b>${Object.values(state.battleStats.policeKilled).reduce((a,b)=>a+b,0)}</b></div>`;
    }
    const playerKillLevels = document.querySelector('#player-kill-levels');
    if (playerKillLevels) {
        playerKillLevels.innerHTML = state.players.map((player) => `<div class="player-kill-chip" style="--player-color:${player.color}"><b>J${player.id + 1} · N${player.level}</b><small>${player.stats.policeKilled.toLocaleString('fr-FR')} flics · prochain ${player.level >= 10 ? (30000 + (player.level - 9) * 10000).toLocaleString('fr-FR') : PLAYER_LEVEL_THRESHOLDS[player.level].toLocaleString('fr-FR')}</small></div>`).join('');
    }
    ui.score.textContent = state.score;
    if (ui.allyCount) ui.allyCount.textContent = state.allies.length;
    if (ui.workerCount) ui.workerCount.textContent = state.workers.length;
    if (ui.medicCount) ui.medicCount.textContent = state.medics.length;
    ui.weaponWave.textContent = state.wave;
    if (ui.campText) ui.campText.textContent = `${Math.max(0, Math.ceil(state.core.hp))} / ${state.core.maxHp}`;
    for (const button of ui.weaponButtons) {
        const type = button.dataset.weapon;
        const weapon = weapons[type];
        const crafted = state.craftedWeapons[type];
        const unlocked = state.wave >= weapon.wave;
        button.classList.toggle('active', state.weapon === type);
        button.classList.toggle('locked', !crafted);
        const status = button.querySelector('span');
        const useCostText = formatWeaponCost(weapon.cost);
        const craftCostText = formatWeaponCost(weapon.craftCost || weapon.cost);
        status.textContent = crafted
            ? `PRÊT · ${useCostText} / ${type === 'barre' ? 'frappe' : 'tir'}`
            : unlocked
                ? `FABRIQUER · ${craftCostText}`
                : `VAGUE ${weapon.wave} · ${craftCostText}`;
    }
    if (ui.campMeter) ui.campMeter.style.width = `${Math.max(0, state.core.hp / state.core.maxHp * 100)}%`;
    const remaining = Math.max(0, state.prepTime - state.time);
    const alert = state.waveAlert;
    if (alert) {
        const intel = getWaveIntel(alert.wave);
        ui.phase.textContent = `ALERTE · VAGUE ${alert.wave}/${MAX_WAVES}`;
        ui.waveAlertTitle.textContent = `VAGUE ${alert.wave} / ${MAX_WAVES}`;
        ui.waveAlertClock.textContent = String(Math.max(0, Math.ceil(alert.timeLeft))).padStart(2, '0');
        ui.waveAlertAgents.textContent = intel.agents;
        const alertUnits = [...intel.vehicles, ...intel.specials];
        if (state.bonusVanNextWave === alert.wave && !state.bonusVan && state.bonusVanSpawnTime === null) alertUnits.push('CAMION BONUS · RENFORTS');
        ui.waveAlertVehicles.textContent = alertUnits.length ? alertUnits.join(' · ') : 'AUCUNE UNITÉ SPÉCIALE';
        const routeParts = [alert.cleared ? 'SECTEUR DÉGAGÉ' : state.map === 'lycee' ? 'ASSAUT PAR LES RUES DU NORD · AXES DÉGAGÉS' : 'ASSAUT PAR LE SUD, L’OUEST ET L’EST'];
        if (REINFORCEMENT_WAVES.has(alert.wave)) routeParts.push('RENFORTS ALLIÉS À L’ARRIVÉE');
        if (alertUnits.length) routeParts.push('PRIORISEZ LES UNITÉS SPÉCIALES');
        ui.waveAlertRoute.textContent = routeParts.join(' · ');
        ui.waveAlert.classList.toggle('imminent', !alert.cleared && alert.timeLeft <= 3);
        ui.waveAlert.classList.toggle('cleared', Boolean(alert.cleared));
        ui.waveAlert.classList.remove('hidden');
    } else {
        ui.waveAlert.classList.add('hidden');
        ui.phase.textContent = remaining > 0
            ? state.map === 'lycee' ? 'ASSAUT DU NORD DANS' : 'Arrivée par le sud dans'
            : `Défense · Vague ${state.wave}/${MAX_WAVES}`;
        ui.clock.textContent = remaining > 0 ? formatTime(remaining) : formatTime(state.survival);
    }
    if (state.difficulty === 'tutorial' && state.tutorial) {
        updateTutorialUI();
    } else if (state.bonusVan && state.bonusVan.hp > 0) {
        ui.bonusObjective?.classList.remove('hidden');
        if (ui.bonusObjectiveDistance) ui.bonusObjectiveDistance.textContent = `${Math.round(nearestPlayerDistance(state.bonusVan))} m · 4 alliés à gagner`;
    } else {
        ui.bonusObjective?.classList.add('hidden');
    }
    ui.timer?.classList.toggle('danger', Boolean(alert) || remaining > 0 && remaining < 20);
}

function formatTime(seconds) {
    const total = Math.max(0, Math.ceil(seconds));
    return `${String(Math.floor(total / 60)).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`;
}

function showToast(text) {
    ui.toast.textContent = text;
    ui.toast.style.opacity = 1;
    toastTimer = 1.5;
}

function isWorldPointVisible(x, y, margin = 180) {
    const left = camera.x - margin;
    const right = camera.x + W / camera.zoom + margin;
    const top = camera.y - margin;
    const bottom = camera.y + H / camera.zoom + margin;
    return x >= left && x <= right && y >= top && y <= bottom;
}

function drawImage(image, x, y, width, height, alpha = 1) {
    if (!image.complete || !image.naturalWidth) return false;
    // Évite save/restore (coûteux) quand l'alpha est plein — cas le plus fréquent.
    if (alpha >= 0.999) {
        ctx.drawImage(image, x - width / 2, y - height / 2, width, height);
        return true;
    }
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.drawImage(image, x - width / 2, y - height / 2, width, height);
    ctx.restore();
    return true;
}

function drawImageRegion(image, region, x, y, alpha = 1) {
    if (!image.complete || !image.naturalWidth) return false;
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.drawImage(
        image,
        region.sx, region.sy, region.sw, region.sh,
        x - region.width / 2, y - region.height / 2, region.width, region.height
    );
    ctx.restore();
    return true;
}

function drawGround() {
    // Tout le sol est dessiné en coordonnées MONDE.
    // Ainsi les textures restent parfaitement collées au décor quand la caméra se déplace ou dézoome.
    const map = state?.map || 'camp';
    const vx = camera.x;
    const vy = camera.y;
    const viewW = W / camera.zoom;
    const viewH = H / camera.zoom;

    if (map === 'squat') {
        ctx.fillStyle = '#0a0b0c';
        ctx.fillRect(vx - 20, vy - 20, viewW + 40, viewH + 40);

        // Construire les caches une seule fois (sol+murs+décors pré-scalés)
        if (!squatCacheReady) {
            if (!buildSquatCaches()) {
                // Images pas encore chargées : fallback simple
                ctx.fillStyle = '#000000';
                for (const room of SQUAT_ROOMS) {
                    if (room.id >= (state?.squatUnlocked || 1)) continue;
                    const rx = room.x - SQUAT_ROOM_W / 2, ry = room.y - SQUAT_ROOM_H / 2;
                    if (rx + SQUAT_ROOM_W < vx || rx > vx + viewW || ry + SQUAT_ROOM_H < vy || ry > vy + viewH) continue;
                    ctx.fillRect(rx, ry, SQUAT_ROOM_W, SQUAT_ROOM_H);
                }
                return;
            }
        }

        // Les salles verrouillées sont réellement invisibles, pas seulement inaccessibles.
        for (const rc of squatRoomCaches) {
            const roomData = SQUAT_ROOMS[rc.roomId];
            if (!roomData || roomData.id >= (state?.squatUnlocked || 1)) continue;
            if (rc.x + rc.w < vx - 20 || rc.x > vx + viewW + 20) continue;
            if (rc.y + rc.h < vy - 20 || rc.y > vy + viewH + 20) continue;
            ctx.drawImage(rc.canvas, rc.x, rc.y, rc.w, rc.h);
        }

        // Couloirs
        for (const cc of squatCorridorCaches) {
            const door = SQUAT_DOORS.find(d => d.id === cc.doorId);
            if (!door?.open) continue;
            if (cc.x + cc.w < vx - 20 || cc.x > vx + viewW + 20) continue;
            if (cc.y + cc.h < vy - 20 || cc.y > vy + viewH + 20) continue;
            ctx.drawImage(cc.canvas, cc.x, cc.y);
        }

        // Feux : animation frame par frame (grille 6×4), pas de défilement
        const fireImg = images.squatFire;
        if (fireImg?.complete && fireImg.naturalWidth) {
            const cols = SQUAT_FIRE_COLS, rows = SQUAT_FIRE_ROWS;
            const fw = Math.floor(fireImg.naturalWidth / cols);
            const fh = Math.floor(fireImg.naturalHeight / rows);
            const total = cols * rows;
            // 10 fps, index entier → chaque sprite s'affiche net puis le suivant
            const frame = Math.floor((state?.time || 0) * 10) % total;
            const col = frame % cols;
            const row = Math.floor(frame / cols);
            const sx = col * fw;
            const sy = row * fh;
            const fireSize = 72;
            for (const room of SQUAT_ROOMS) {
                // Aucune animation ni décor dans les salles encore verrouillées.
                if (room.id >= (state?.squatUnlocked || 1)) continue;
                const rx = room.x - SQUAT_ROOM_W / 2, ry = room.y - SQUAT_ROOM_H / 2;
                if (rx + SQUAT_ROOM_W < vx || rx > vx + viewW || ry + SQUAT_ROOM_H < vy || ry > vy + viewH) continue;
                for (const [fx, fy] of [
                    [rx + 90, ry + 95], [rx + SQUAT_ROOM_W - 90, ry + 95],
                    [rx + 90, ry + SQUAT_ROOM_H - 95], [rx + SQUAT_ROOM_W - 90, ry + SQUAT_ROOM_H - 95]
                ]) {
                    ctx.drawImage(fireImg, sx, sy, fw, fh, fx - fireSize / 2, fy - fireSize / 2 - 8, fireSize, fireSize);
                }
            }
        }

        // Portes dynamiques
        for (const d of SQUAT_DOORS) {
            if (d.a >= (state?.squatUnlocked || 1)) continue;
            if (d.x < vx - 100 || d.x > vx + viewW + 100 || d.y < vy - 100 || d.y > vy + viewH + 100) continue;
            ctx.save();
            ctx.translate(d.x, d.y);
            ctx.fillStyle = d.open ? '#4fc477' : '#65432f';
            ctx.strokeStyle = '#171717';
            ctx.lineWidth = 10;
            if (d.orientation === 'h') {
                ctx.fillRect(-38, -80, 76, 160);
                ctx.strokeRect(-38, -80, 76, 160);
            } else {
                ctx.fillRect(-80, -38, 160, 76);
                ctx.strokeRect(-80, -38, 160, 76);
            }
            ctx.fillStyle = '#fff1c8';
            ctx.font = 'bold 22px Orbitron, sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(d.open ? 'OUVERTE' : `E · ${d.id * 10} CHAQUE`, 0, d.orientation === 'h' ? -95 : -52);
            ctx.restore();
        }
        return;
    }
    if (map === 'lycee') {
        const backdrop = images.lyceeBackground;
        ctx.fillStyle = '#e7deca';
        ctx.fillRect(vx, vy, viewW, viewH);
        if (backdrop?.complete && backdrop.naturalWidth) {
            const sourceAspect = backdrop.naturalWidth / backdrop.naturalHeight;
            const worldAspect = WORLD_W / WORLD_H;
            let sx = 0, sy = 0, sw = backdrop.naturalWidth, sh = backdrop.naturalHeight;
            if (sourceAspect > worldAspect) {
                sw = sh * worldAspect;
                sx = (backdrop.naturalWidth - sw) / 2;
            } else {
                sh = sw / worldAspect;
                sy = (backdrop.naturalHeight - sh) / 2;
            }
            const srcX = sx + (vx / WORLD_W) * sw;
            const srcY = sy + (vy / WORLD_H) * sh;
            const srcW = (viewW / WORLD_W) * sw;
            const srcH = (viewH / WORLD_H) * sh;
            ctx.drawImage(backdrop, srcX, srcY, srcW, srcH, vx, vy, viewW, viewH);
        } else {
            ctx.fillStyle = '#eadfcd';
            ctx.fillRect(0, 580, WORLD_W, 250);
            ctx.fillRect(0, 1760, WORLD_W, 250);
            ctx.fillRect(820, 0, 250, WORLD_H);
            ctx.fillRect(4100, 0, 250, WORLD_H);
        }
    } else {
        ctx.fillStyle = '#68c96b';
        ctx.fillRect(vx, vy, viewW, viewH);
        if (images.terrain?.complete && images.terrain.naturalWidth) {
            ctx.globalAlpha = 0.72;
            const tile = 960; // tuiles plus grandes = beaucoup moins de drawImage
            const x0 = Math.floor(vx / tile) * tile;
            const y0 = Math.floor(vy / tile) * tile;
            const x1 = vx + viewW + tile;
            const y1 = vy + viewH + tile;
            for (let y = y0; y < y1; y += tile) {
                for (let x = x0; x < x1; x += tile) {
                    ctx.drawImage(images.terrain, x, y, tile, tile);
                }
            }
            ctx.globalAlpha = 1;
        }
        // Gradient ambiant simplifié (plus de createRadialGradient chaque frame)
        ctx.fillStyle = 'rgba(17,104,66,0.12)';
        ctx.fillRect(vx, vy, viewW, viewH);
    }

    ctx.save();
    ctx.strokeStyle = map === 'lycee' ? 'rgba(200,210,220,.35)' : 'rgba(255,249,178,.42)';
    ctx.lineWidth = 5;
    ctx.setLineDash([18, 16]);
    ctx.strokeRect(45, 45, WORLD_W - 90, WORLD_H - 90);
    ctx.setLineDash([]);
    ctx.restore();
    drawWorldRegions();
}

function roundRect(ctx, x, y, w, h, r) {
    const rr = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + rr, y);
    ctx.arcTo(x + w, y, x + w, y + h, rr);
    ctx.arcTo(x + w, y + h, x, y + h, rr);
    ctx.arcTo(x, y + h, x, y, rr);
    ctx.arcTo(x, y, x + w, y, rr);
    ctx.closePath();
}

function drawZoneLabel(text, sub, x, y) {
    // Libellé flottant : pas de panneau qui masque le décor.
    ctx.save();
    ctx.textAlign = 'center';
    ctx.shadowColor = 'rgba(0,0,0,.72)';
    ctx.shadowBlur = 0;
    ctx.fillStyle = '#fff4b0';
    ctx.font = '900 25px Orbitron';
    ctx.fillText(text, x, y - 8);
    ctx.fillStyle = '#d9ead2';
    ctx.font = '700 12px Inter';
    ctx.fillText(sub, x, y + 16);
    ctx.restore();
}

function drawRiverBankFlowers() {
    // Moins de fleurs = moins de path stroke/fill par frame (gain net sur map rivière).
    const left = camera.x - 80;
    const top = camera.y - 80;
    const right = camera.x + W / camera.zoom + 80;
    const bottom = camera.y + H / camera.zoom + 80;
    for (let i = 0; i < 10; i++) {
        for (const side of [-1, 1]) {
            const angle = i * 2.399963 + (side > 0 ? 0.22 : 0);
            const radius = RIVER_RING_R + side * (RIVER_WATER_HALF + 39 + Math.sin(i * 4.7) * 10);
            const x = CAMP_X + Math.cos(angle) * radius;
            const y = CAMP_Y + Math.sin(angle) * radius;
            if (x < left || x > right || y < top || y > bottom) continue;
            ctx.save();
            ctx.translate(x, y);
            ctx.rotate(angle + Math.PI / 2);
            ctx.strokeStyle = i % 3 === 0 ? '#5caa70' : '#77b969';
            ctx.lineWidth = 4;
            ctx.lineCap = 'round';
            ctx.beginPath();
            ctx.moveTo(-8, 9); ctx.quadraticCurveTo(-7, -1, -12, -7);
            ctx.moveTo(0, 10); ctx.quadraticCurveTo(2, -2, 0, -10);
            ctx.moveTo(7, 9); ctx.quadraticCurveTo(9, 0, 14, -6);
            ctx.stroke();
            if (i % 3 === 0) {
                const petal = i % 2 === 0 ? '#fff6d2' : '#ffb7c7';
                ctx.fillStyle = petal;
                for (let petalIndex = 0; petalIndex < 5; petalIndex++) {
                    const petalAngle = petalIndex * Math.PI * 0.4;
                    ctx.beginPath();
                    ctx.arc(12 + Math.cos(petalAngle) * 5, -7 + Math.sin(petalAngle) * 5, 3.2, 0, Math.PI * 2);
                    ctx.fill();
                }
                ctx.fillStyle = '#ffd968';
                ctx.beginPath(); ctx.arc(12, -7, 3, 0, Math.PI * 2); ctx.fill();
            }
            ctx.restore();
        }
    }
}

let _riverRingPath = null;
function getRiverRingPath() {
    if (!_riverRingPath) {
        _riverRingPath = new Path2D();
        _riverRingPath.arc(CAMP_X, CAMP_Y, RIVER_RING_R + RIVER_WATER_HALF, 0, Math.PI * 2);
        _riverRingPath.arc(CAMP_X, CAMP_Y, RIVER_RING_R - RIVER_WATER_HALF, 0, Math.PI * 2);
    }
    return _riverRingPath;
}
function drawRiverSurfaceTexture() {
    ctx.save();
    ctx.clip(getRiverRingPath(), 'evenodd');

    const texture = images.riverCurrent;
    if (texture?.complete && texture.naturalWidth) {
        const tile = 640;
        const left = Math.floor((camera.x - tile) / tile) * tile;
        const top = Math.floor((camera.y - tile) / tile) * tile;
        const right = camera.x + W / camera.zoom + tile;
        const bottom = camera.y + H / camera.zoom + tile;
        ctx.globalAlpha = 0.58;
        for (let y = top; y < bottom; y += tile) {
            for (let x = left; x < right; x += tile) {
                ctx.drawImage(texture, x, y, tile, tile);
            }
        }
        ctx.globalAlpha = 1;
    }

    // Un léger voile bleu profond souligne le chenal sans masquer les rubans clairs.
    // Couleur plate au lieu de radial gradient chaque frame
    ctx.fillStyle = 'rgba(17,91,148,0.12)';
    ctx.fillRect(camera.x - 80, camera.y - 80, W / camera.zoom + 160, H / camera.zoom + 160);
    ctx.restore();
}

function drawRiverRipples() {
    const left = camera.x - 120;
    const top = camera.y - 120;
    const right = camera.x + W / camera.zoom + 120;
    const bottom = camera.y + H / camera.zoom + 120;
    const time = state?.time || 0;
    ctx.save();
    ctx.clip(getRiverRingPath(), 'evenodd');
    ctx.lineCap = 'round';

    // Moins de traînées (12 au lieu de 22) pour alléger le CPU.
    for (let i = 0; i < 12; i++) {
        const speed = 0.1 + (i % 4) * 0.018;
        const angle = (i * 2.399963 + time * speed) % (Math.PI * 2);
        const radius = RIVER_RING_R + Math.sin(i * 2.17 + time * 0.7) * 88;
        const x = CAMP_X + Math.cos(angle) * radius;
        const y = CAMP_Y + Math.sin(angle) * radius;
        if (x < left || x > right || y < top || y > bottom) continue;
        ctx.strokeStyle = i % 5 === 0 ? 'rgba(236,255,255,.88)' : i % 2 ? 'rgba(195,245,255,.64)' : 'rgba(41,133,183,.52)';
        ctx.lineWidth = i % 5 === 0 ? 6 : 3.5;
        ctx.beginPath();
        ctx.arc(CAMP_X, CAMP_Y, radius, angle, angle + 0.09 + (i % 3) * 0.035);
        ctx.stroke();
    }

    ctx.fillStyle = 'rgba(245,255,255,.92)';
    for (let i = 0; i < 58; i += 7) {
        const angle = (i * 2.399963 + time * 0.14) % (Math.PI * 2);
        const radius = RIVER_RING_R + Math.sin(i * 2.17 + time * 0.7) * 82;
        const x = CAMP_X + Math.cos(angle) * radius;
        const y = CAMP_Y + Math.sin(angle) * radius;
        if (x < left || x > right || y < top || y > bottom) continue;
        ctx.beginPath();
        ctx.arc(x, y, 3 + (i % 3) * 0.6, 0, Math.PI * 2);
        ctx.fill();
    }
    ctx.restore();
}

function drawRiverLilies() {
    const placements = [0.18, 0.77, 1.56, 2.35, 3.42, 4.17, 5.28];
    for (let i = 0; i < placements.length; i++) {
        const angle = placements[i];
        const radius = RIVER_RING_R + Math.sin(i * 5.1) * 67;
        const x = CAMP_X + Math.cos(angle) * radius;
        const y = CAMP_Y + Math.sin(angle) * radius;
        if (x < camera.x - 50 || x > camera.x + W / camera.zoom + 50 || y < camera.y - 50 || y > camera.y + H / camera.zoom + 50) continue;
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(angle);
        ctx.fillStyle = 'rgba(27,111,112,.2)';
        ctx.beginPath(); ctx.ellipse(3, 5, 24, 15, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = i % 2 ? '#43a982' : '#50b98c';
        ctx.beginPath(); ctx.moveTo(0, 0); ctx.arc(0, 0, 20, 0.28, Math.PI * 1.86); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = 'rgba(210,255,218,.72)';
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(13, -8); ctx.stroke();
        if (i % 2 === 0) {
            for (let p = 0; p < 5; p++) {
                const petalAngle = p * Math.PI * 0.4;
                ctx.fillStyle = '#fff4de';
                ctx.beginPath(); ctx.arc(8 + Math.cos(petalAngle) * 5, -4 + Math.sin(petalAngle) * 5, 4, 0, Math.PI * 2); ctx.fill();
            }
            ctx.fillStyle = '#ffd96e';
            ctx.beginPath(); ctx.arc(8, -4, 3, 0, Math.PI * 2); ctx.fill();
        }
        ctx.restore();
    }
}

function drawCuteRiverBridge(bridge, index) {
    ctx.save();
    ctx.translate(bridge.x, bridge.y);
    ctx.rotate(bridge.angle);

    // L'illustration est partagée par les trois traversées, chacune suivant son axe radial.
    ctx.fillStyle = 'rgba(18,51,62,.25)';
    roundRect(ctx, -bridge.w * 0.55, -104, bridge.w * 1.1, 208, 24);
    ctx.fill();
    const bridgeImage = images.riverBridge;
    if (bridgeImage?.complete && bridgeImage.naturalWidth) {
        ctx.drawImage(bridgeImage, -bridge.w * 0.57, -100, bridge.w * 1.14, 200);
    } else {
        // Repli immédiat si le sprite n'est pas encore chargé.
        const halfLength = bridge.w * 0.5;
        ctx.fillStyle = '#855a3f';
        roundRect(ctx, -halfLength, -68, bridge.w, 136, 18);
        ctx.fill();
        ctx.fillStyle = '#d6a96f';
        roundRect(ctx, -halfLength + 8, -56, bridge.w - 16, 112, 12);
        ctx.fill();
        for (let x = -halfLength + 18, plank = 0; x < halfLength - 12; x += 28, plank++) {
            ctx.fillStyle = plank % 2 ? 'rgba(113,73,43,.32)' : 'rgba(255,226,165,.26)';
            roundRect(ctx, x, -51, 22, 102, 4);
            ctx.fill();
        }
        ctx.strokeStyle = '#71492f';
        ctx.lineWidth = 10;
        for (const y of [-60, 60]) {
            ctx.beginPath();
            ctx.moveTo(-halfLength + 12, y);
            ctx.lineTo(halfLength - 12, y);
            ctx.stroke();
        }
    }

    // Les petites fleurs colorées reprennent l'identité des berges sans gêner le passage.
    ctx.fillStyle = index === 0 ? '#ffd6e1' : '#fff0b9';
    for (const x of [-bridge.w * 0.48, bridge.w * 0.48]) {
        ctx.beginPath();
        ctx.arc(x, 0, 5.5, 0, Math.PI * 2);
        ctx.fill();
    }
    ctx.restore();
}

function drawMazeHedges() {
    if (!mazeGrid) return;
    const left = camera.x - MAZE_CELL;
    const top = camera.y - MAZE_CELL;
    const right = camera.x + W / camera.zoom + MAZE_CELL;
    const bottom = camera.y + H / camera.zoom + MAZE_CELL;
    const hedge = images.hedgeWall;
    const hasHedge = hedge?.complete && hedge.naturalWidth > 0;

    // Murs de haies uniquement (le sol = asset classique via drawGround)
    for (let r = 0; r < MAZE_ROWS; r++) {
        for (let c = 0; c < MAZE_COLS; c++) {
            if (!mazeGrid[r][c]) continue;
            const x = MAZE_ORIGIN_X + c * MAZE_CELL;
            const y = MAZE_ORIGIN_Y + r * MAZE_CELL;
            if (x + MAZE_CELL < left || x > right || y + MAZE_CELL < top || y > bottom) continue;
            // Asset recadré sans bord transparent : remplit tout le carré de collision
            if (hasHedge) {
                ctx.drawImage(hedge, x, y, MAZE_CELL + 1, MAZE_CELL + 1);
            } else {
                ctx.fillStyle = '#1a5c2e';
                ctx.fillRect(x, y, MAZE_CELL + 1, MAZE_CELL + 1);
                ctx.fillStyle = '#2d8a45';
                ctx.fillRect(x + 2, y + 2, MAZE_CELL - 4, MAZE_CELL - 8);
            }
        }
    }

    // Entrée / sortie : signalétiques légères, sans cadres autour du texte.
    if (mazeEntrance) {
        ctx.save();
        ctx.globalAlpha = 0.82;
        ctx.font = '900 13px Orbitron';
        ctx.fillStyle = '#bdeaff';
        ctx.textAlign = 'center';
        ctx.shadowColor = '#000';
        ctx.shadowBlur = 0;
        ctx.fillText('ENTRÉE', mazeEntrance.x, mazeEntrance.y + 6);
        ctx.restore();
    }
    if (mazeExit) {
        const pulse = 0.72 + Math.sin(state.time * 4) * 0.2;
        ctx.save();
        ctx.globalAlpha = pulse;
        ctx.font = '900 15px Orbitron';
        ctx.fillStyle = '#fff0a0';
        ctx.textAlign = 'center';
        ctx.shadowColor = '#000';
        ctx.shadowBlur = 0;
        ctx.fillText('SORTIE', mazeExit.x, mazeExit.y + 8);
        ctx.restore();
    }
}

function drawWorldRegions() {
    const map = state?.map || 'camp';

    if (map === 'maze') {
        // Sol classique déjà dessiné par drawGround — uniquement les haies ici
        drawMazeHedges();
        return;
    }

    if (map === 'river') {
        // Anneau aux berges douces, en eau turquoise, à contour doré et herbeux.
        const riverR = RIVER_RING_R;
        const waterW = RIVER_WATER_HALF * 2;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.arc(CAMP_X, CAMP_Y, riverR, 0, Math.PI * 2);
        ctx.lineWidth = waterW + 82;
        ctx.strokeStyle = '#579365';
        ctx.stroke();
        ctx.lineWidth = waterW + 48;
        ctx.strokeStyle = '#9bc879';
        ctx.stroke();
        ctx.lineWidth = waterW + 19;
        ctx.strokeStyle = '#e0e9a8';
        ctx.stroke();
        const waterGradient = ctx.createLinearGradient(CAMP_X - riverR, CAMP_Y - riverR, CAMP_X + riverR, CAMP_Y + riverR);
        waterGradient.addColorStop(0, '#55c9df');
        waterGradient.addColorStop(0.48, '#7be0e5');
        waterGradient.addColorStop(1, '#54bdd8');
        ctx.lineWidth = waterW;
        ctx.strokeStyle = waterGradient;
        ctx.stroke();
        drawRiverSurfaceTexture();

        // Reflets doux aux deux rives et petits détails de jardin enchanté.
        ctx.lineCap = 'butt';
        ctx.lineWidth = 5;
        ctx.strokeStyle = 'rgba(255,255,221,.82)';
        ctx.beginPath(); ctx.arc(CAMP_X, CAMP_Y, riverR - RIVER_WATER_HALF, 0, Math.PI * 2); ctx.stroke();
        ctx.beginPath(); ctx.arc(CAMP_X, CAMP_Y, riverR + RIVER_WATER_HALF, 0, Math.PI * 2); ctx.stroke();
        ctx.lineCap = 'round';
        ctx.lineWidth = waterW * 0.34;
        ctx.strokeStyle = 'rgba(205,255,244,.29)';
        ctx.beginPath(); ctx.arc(CAMP_X, CAMP_Y, riverR + 8, 0, Math.PI * 2); ctx.stroke();
        drawRiverBankFlowers();
        drawRiverRipples();
        drawRiverLilies();

        // Les planches suivent l'axe radial : chaque passerelle relie réellement les deux rives.
        for (const [index, bridge] of riverBridgeZones().entries()) drawCuteRiverBridge(bridge, index);

        drawZoneLabel('RIVIÈRE AUX LUCIOLES', '3 PASSERELLES FLEURIES · TOUT LE MONDE PEUT TRAVERSER', CAMP_X, CAMP_Y - riverR - 235);
        drawZoneLabel('CAMP', 'ÎLOT DE DÉFENSE', CAMP_X, CAMP_Y - 280);
        return;
    }

    if (map === 'lycee') {
        // Le fond illustré contient déjà les rues, les passages piétons et les maisons.
        const gateX = CAMP_X;
        const gateY = state.core?.y + 35 || WORLD_H - 245;
        drawImage(images.lyceeGate, gateX, gateY, 505, 520);
        drawZoneLabel('PORTE DU LYCÉE', 'OBJECTIF À DÉFENDRE', gateX, gateY - 325);
        return;
    }

    // ===== MAP CAMP CLASSIQUE (code d'origine) =====
    // Rivière diagonale/verticale séparant le nord industriel du sud rural.
    const river = new Path2D();
    river.moveTo(3150, -100);
    river.bezierCurveTo(2920, 420, 3340, 760, 3060, 1160);
    river.bezierCurveTo(2780, 1540, 3160, 1940, 2860, 2360);
    river.bezierCurveTo(2700, 2590, 2880, 2870, 2750, 3300);
    river.lineWidth = 250;
    ctx.strokeStyle = '#347f9d';
    ctx.stroke(river);
    river.lineWidth = 205;
    ctx.strokeStyle = '#58b5ca';
    ctx.stroke(river);
    river.lineWidth = 8;
    ctx.strokeStyle = 'rgba(220,255,255,.45)';
    ctx.stroke(river);

    // Routes principales.
    ctx.lineCap = 'round';
    ctx.lineWidth = 92;
    ctx.strokeStyle = '#6c6558';
    for (const pts of [
        [[100, 650], [1500, 850], [2450, 1450], [5000, 520]],
        [[300, 2700], [1500, 2250], [2550, 1600], [4900, 2650]],
        [[2600, 100], [2600, 800], [2600, 1600], [2600, 3100]]
    ]) {
        ctx.beginPath(); ctx.moveTo(...pts[0]);
        for (let i=1;i<pts.length;i++) ctx.lineTo(...pts[i]);
        ctx.stroke();
    }
    ctx.lineWidth = 12;
    ctx.setLineDash([36, 28]);
    ctx.strokeStyle = 'rgba(245,222,154,.78)';
    for (const pts of [
        [[100, 650], [1500, 850], [2450, 1450], [5000, 520]],
        [[300, 2700], [1500, 2250], [2550, 1600], [4900, 2650]],
        [[2600, 100], [2600, 800], [2600, 1600], [2600, 3100]]
    ]) {
        ctx.beginPath(); ctx.moveTo(...pts[0]);
        for (let i=1;i<pts.length;i++) ctx.lineTo(...pts[i]);
        ctx.stroke();
    }
    ctx.setLineDash([]);

    // Nord-ouest — usines (remplace l'ancien asset forêt istockphoto)
    const factoryImgNW = images.mapFactory;
    if (factoryImgNW?.complete && factoryImgNW.naturalWidth) {
        ctx.globalAlpha = 0.95;
        ctx.drawImage(factoryImgNW, 200, 140, 380, 570);
        ctx.drawImage(factoryImgNW, 620, 180, 360, 540);
        ctx.drawImage(factoryImgNW, 1040, 140, 400, 600);
        ctx.drawImage(factoryImgNW, 280, 700, 360, 540);
        ctx.drawImage(factoryImgNW, 720, 740, 380, 570);
        ctx.drawImage(factoryImgNW, 1180, 680, 360, 540);
        ctx.globalAlpha = 1;
    } else {
        ctx.fillStyle = 'rgba(101,91,78,.26)';
        ctx.fillRect(180, 120, 1800, 1050);
    }

    // Zone industrielle nord-est — usines
    const factoryImg = images.mapFactory;
    if (factoryImg?.complete && factoryImg.naturalWidth) {
        ctx.globalAlpha = 0.95;
        ctx.drawImage(factoryImg, 3500, 200, 420, 630);
        ctx.drawImage(factoryImg, 4000, 280, 380, 570);
        ctx.drawImage(factoryImg, 4450, 220, 400, 600);
        ctx.drawImage(factoryImg, 3600, 780, 360, 540);
        ctx.drawImage(factoryImg, 4150, 820, 400, 600);
        ctx.globalAlpha = 1;
    } else {
        ctx.fillStyle = 'rgba(101,91,78,.26)';
        ctx.fillRect(3450, 220, 1450, 1150);
    }

    // Village sud-ouest
    const villageImg = images.mapVillage;
    if (villageImg?.complete && villageImg.naturalWidth) {
        ctx.globalAlpha = 0.94;
        ctx.drawImage(villageImg, 280, 2000, 720, 506);
        ctx.drawImage(villageImg, 980, 2100, 680, 478);
        ctx.drawImage(villageImg, 420, 2480, 640, 450);
        ctx.globalAlpha = 1;
    } else {
        ctx.fillStyle = 'rgba(198,164,107,.18)';
        ctx.fillRect(250, 1980, 1650, 850);
    }

}

function drawSouthEntrance() {
    const warning = Boolean(state.waveAlert);
    const pulse = warning ? 0.68 + Math.sin(state.time * 8) * 0.2 : 0.48;
    const color = warning ? '#ff6b70' : '#ffe16b';
    const y = WORLD_H - 72;
    const panelX = (WORLD_W - 510) / 2;
    ctx.save();
    if (state.map === 'lycee') {
        const northLine = WORLD_H - 990;
        ctx.globalAlpha = pulse;
        ctx.strokeStyle = color;
        ctx.lineWidth = warning ? 7 : 4;
        ctx.setLineDash([34, 18]);
        ctx.beginPath();
        ctx.moveTo(110, northLine);
        ctx.lineTo(WORLD_W - 110, northLine);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.textAlign = 'center';
        ctx.fillStyle = '#fffbe0';
        ctx.font = '900 13px Orbitron';
        ctx.fillText(warning ? '⚠ ASSAUT DES CRS ⚠' : 'RUE DU LYCÉE · AXE NORD', WORLD_W / 2, northLine - 17);
        ctx.fillStyle = color;
        ctx.font = '800 9px Inter';
        ctx.fillText(warning ? 'ILS ARRIVENT AU-DESSUS DES POUBELLES' : 'DÉFENSE : DEUX LIGNES DE POUBELLES', WORLD_W / 2, northLine + 3);
        for (const x of [400, 1500, 2600, 3700, 4800]) {
            ctx.beginPath();
            ctx.moveTo(x, northLine + 12);
            ctx.lineTo(x - 15, northLine + 36);
            ctx.lineTo(x + 15, northLine + 36);
            ctx.closePath();
            ctx.fillStyle = color;
            ctx.fill();
        }
        ctx.restore();
        return;
    }
    ctx.globalAlpha = pulse;
    ctx.strokeStyle = color;
    ctx.lineWidth = warning ? 7 : 4;
    ctx.setLineDash([34, 18]);
    ctx.beginPath();
    ctx.moveTo(105, y);
    ctx.lineTo(WORLD_W - 105, y);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.textAlign = 'center';
    ctx.fillStyle = '#fffbe0';
    ctx.font = '900 22px Orbitron';
    ctx.fillText(warning ? '⚠  ALERTE — ASSAUT MULTI-AXES  ⚠' : 'ENTRÉE SUD  ·  AXE D\'ASSAUT', WORLD_W / 2, WORLD_H - 85);
    ctx.fillStyle = color;
    ctx.font = '800 9px Inter';
    ctx.fillText(warning ? 'SUD · OUEST · EST' : 'APPROCHE POLICIÈRE', WORLD_W / 2, WORLD_H - 57);
    for (const x of [400, 1000, 2200, 2800]) {
        ctx.beginPath();
        ctx.moveTo(x, WORLD_H - 32);
        ctx.lineTo(x - 18, WORLD_H - 55);
        ctx.lineTo(x + 18, WORLD_H - 55);
        ctx.closePath();
        ctx.fillStyle = color;
        ctx.fill();
    }
    ctx.restore();
}

function draw() {
    // Une seule transformation monde -> écran. Tous les sprites, le sol et les décors
    // restent donc solidaires, quelle que soit la position ou le zoom de la caméra.
    ctx.save();
    ctx.scale(camera.zoom, camera.zoom);
    ctx.translate(-camera.x, -camera.y);
    drawGround();
    drawBloodStains();
    drawSouthEntrance();
    drawNodes();
    drawWeaponDrops();
    drawLootDrops();
    drawFireZones();
    drawGasZones();
    drawWaterZones();
    drawBuildings();
    drawProjectiles();
    drawEggs();
    drawEnemies();
    drawWorkers();
    drawMedics();
    drawAllies();
    drawPlayer();
    drawParticles();
    drawBuildGhost();
    ctx.restore();
    drawVignette();
    drawCursor();
}

function drawNodes() {
    for (const node of state.nodes) {
        if (node.amount <= 0 || !isWorldPointVisible(node.x, node.y, 250)) continue;
        ctx.fillStyle = 'rgba(0,0,0,.3)';
        ctx.beginPath();
        ctx.ellipse(node.x, node.y + 50, 100, 40, 0, 0, Math.PI * 2);
        ctx.fill();
        const nodeImage = { wood: images.resourceWood, stone: images.resourceStone, scrap: images.resourceScrap, fuel: images.resourceFuel, glass: images.resourceGlass }[node.type] || images.resource;
        if (!drawImage(nodeImage, node.x, node.y, 230, 210)) {
            ctx.fillStyle = '#98764e';
            ctx.fillRect(node.x - 70, node.y - 60, 140, 120);
        }
        const color = resourceInfo[node.type]?.color || '#b7b7aa';
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.arc(node.x + 70, node.y - 70, 18, 0, Math.PI * 2);
        ctx.fill();
        const nearbyPlayers = state.players.filter((player) => player.hp > 0 && distance(node, player) < 100);
        if (nearbyPlayers.length) {
            ctx.font = '700 15px Inter';
            ctx.textAlign = 'center';
            ctx.fillStyle = '#fff';
            ctx.fillText(`${nearbyPlayers.map((player) => `J${player.id + 1} · ${player.gamepad ? 'B' : ['E', 'ENTRÉE', 'O', '0'][player.id]}`).join(' / ')} · ${resourceInfo[node.type]?.prompt || 'FOUILLER'}`, node.x, node.y - 120);
            const harvestingPlayer = nearbyPlayers.find((player) => player.harvestNode === node);
            if (harvestingPlayer) {
                ctx.fillStyle = '#102020';
                ctx.fillRect(node.x - 60, node.y - 108, 120, 9);
                ctx.fillStyle = harvestingPlayer.color;
                ctx.fillRect(node.x - 60, node.y - 108, 120 * harvestingPlayer.harvest / Math.max(0.18, 0.55 * (1 - (harvestingPlayer.harvestPower || 0))), 7);
            }
        }
    }
}

function drawWeaponDrops() {
    const interactKeys = ['E', 'ENTRÉE', 'O', '0'];
    for (const drop of state.weaponDrops) {
        const color = drop.weapon === 'policeFlashball' ? '#ffdc71' : '#ff5268';
        const label = drop.weapon === 'policeFlashball' ? 'FLASHBALL' : 'LBD';
        const pulse = 1 + Math.sin(state.time * 6 + drop.pulse) * 0.1;
        ctx.save();
        ctx.fillStyle = 'rgba(0,0,0,.38)';
        ctx.beginPath();
        ctx.ellipse(drop.x, drop.y + 20, 30, 13, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = Math.min(1, drop.life / 2.5);
        ctx.fillStyle = `${color}33`;
        ctx.beginPath();
        ctx.arc(drop.x, drop.y, 31 * pulse, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = color;
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(drop.x, drop.y, 25 * pulse, 0, Math.PI * 2);
        ctx.stroke();
        ctx.translate(drop.x, drop.y);
        ctx.rotate(-0.42);
        ctx.fillStyle = '#18282a';
        ctx.fillRect(-16, -7, 31, 14);
        ctx.fillRect(8, -4, 20, 7);
        ctx.fillRect(-7, 5, 9, 15);
        ctx.fillStyle = color;
        ctx.fillRect(-13, -4, 22, 7);
        ctx.restore();

        ctx.save();
        ctx.textAlign = 'center';
        ctx.font = '900 13px Orbitron';
        ctx.fillStyle = color;
        ctx.fillText(`${label} · ${Math.ceil(drop.life)} s`, drop.x, drop.y - 39);
        const nearbyPlayers = state.players.filter((player) => player.hp > 0 && distance(drop, player) <= 125);
        if (nearbyPlayers.length) {
            ctx.font = '800 12px Inter';
            ctx.fillStyle = '#fffbe0';
            ctx.fillText(nearbyPlayers.map((player) => `J${player.id + 1} · ${player.gamepad ? 'B' : interactKeys[player.id]}`).join(' / ') + ' · RAMASSER', drop.x, drop.y + 48);
        }
        ctx.restore();
    }
}

function drawLootDrops() {
    const interactKeys = ['E', 'ENTRÉE', 'O', '0'];
    const colors = { heal: '#ff7b8d', speed: '#ffe16b', resources: '#8ff0b0', invulnerability: '#8ad9ff' };
    const labels = { heal: 'SOIN', speed: 'VITESSE', resources: 'RESSOURCES', invulnerability: 'INVULNÉRABILITÉ' };
    for (const drop of state.lootDrops) {
        if (drop.life <= 0) continue;
        const color = colors[drop.type] || '#8ff0b0';
        const pulse = 1 + Math.sin(state.time * 5 + (drop.pulse || 0)) * 0.12;
        ctx.save();
        ctx.globalAlpha = Math.min(1, drop.life / 3);
        ctx.fillStyle = 'rgba(0,0,0,.35)';
        ctx.beginPath();
        ctx.ellipse(drop.x, drop.y + 16, 26, 11, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = `${color}44`;
        ctx.beginPath();
        ctx.arc(drop.x, drop.y, 28 * pulse, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = color;
        ctx.lineWidth = 3.5;
        ctx.beginPath();
        ctx.arc(drop.x, drop.y, 22 * pulse, 0, Math.PI * 2);
        ctx.stroke();
        // Icône simple selon le type
        ctx.fillStyle = color;
        if (drop.type === 'heal') {
            ctx.fillRect(drop.x - 3, drop.y - 11, 6, 22);
            ctx.fillRect(drop.x - 11, drop.y - 3, 22, 6);
        } else if (drop.type === 'speed') {
            ctx.beginPath();
            ctx.moveTo(drop.x - 10, drop.y + 8);
            ctx.lineTo(drop.x, drop.y - 12);
            ctx.lineTo(drop.x + 10, drop.y + 8);
            ctx.closePath();
            ctx.fill();
        } else if (drop.type === 'invulnerability') {
            ctx.beginPath();
            ctx.arc(drop.x, drop.y, 9, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#0a1a22';
            ctx.beginPath();
            ctx.arc(drop.x, drop.y, 5, 0, Math.PI * 2);
            ctx.fill();
        } else {
            ctx.fillRect(drop.x - 9, drop.y - 7, 18, 14);
            ctx.fillStyle = '#0a1a22';
            ctx.fillRect(drop.x - 5, drop.y - 3, 10, 6);
        }
        ctx.font = '900 12px Orbitron';
        ctx.fillStyle = color;
        ctx.textAlign = 'center';
        ctx.fillText(labels[drop.type], drop.x, drop.y - 34);
        ctx.restore();
    }
}

function drawWaterZones() {
    for (const zone of state.waterZones) {
        if (zone.life <= 0) continue;
        const pulse = 0.92 + Math.sin(state.time * 7) * 0.08;
        const alpha = Math.min(1, zone.life / 0.4) * 0.55;
        ctx.save();
        ctx.globalAlpha = alpha * 0.45;
        ctx.fillStyle = '#5ec8ff';
        ctx.beginPath();
        ctx.arc(zone.x, zone.y, zone.radius * pulse, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = alpha;
        ctx.strokeStyle = '#b8ecff';
        ctx.lineWidth = 5;
        ctx.setLineDash([14, 10]);
        ctx.beginPath();
        ctx.arc(zone.x, zone.y, zone.radius * 0.92, 0, Math.PI * 2);
        ctx.stroke();
        ctx.setLineDash([]);
        // Gouttes / éclaboussures
        for (let i = 0; i < 6; i++) {
            const a = state.time * 3 + i * 1.1;
            const r = zone.radius * (0.55 + 0.35 * Math.sin(a));
            ctx.globalAlpha = alpha * 0.7;
            ctx.fillStyle = '#e0f7ff';
            ctx.beginPath();
            ctx.arc(zone.x + Math.cos(a) * r * 0.7, zone.y + Math.sin(a) * r * 0.7, 6 + 3 * Math.sin(a * 2), 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.restore();
    }
}

function drawFireZones() {
    for (const zone of state.fireZones) {
        const pulse = 0.9 + Math.sin(state.time * 8) * 0.1;
        ctx.save();
        ctx.globalAlpha = 0.2 * Math.min(1, zone.life);
        ctx.fillStyle = '#ff6a32';
        ctx.beginPath();
        ctx.arc(zone.x, zone.y, zone.radius * pulse, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 0.65;
        ctx.strokeStyle = '#ff9c36';
        ctx.lineWidth = 4;
        ctx.stroke();
        ctx.restore();
    }
}

function drawGasZones() {
    for (const zone of state.gasZones) {
        const pulse = 0.92 + Math.sin(state.time * 5) * 0.08;
        ctx.save();
        ctx.globalAlpha = 0.22 * Math.min(1, zone.life);
        ctx.fillStyle = '#b6dc65';
        ctx.beginPath();
        ctx.arc(zone.x, zone.y, zone.radius * pulse, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 0.65;
        ctx.strokeStyle = '#d8ef8a';
        ctx.setLineDash([12, 10]);
        ctx.lineWidth = 3;
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.restore();
    }
}

function drawCore() {
    ctx.save();
    ctx.translate(state.core.x, state.core.y);
    ctx.fillStyle = 'rgba(255,225,107,.18)';
    ctx.beginPath();
    ctx.arc(0, 0, 175 + Math.sin(state.time * 2) * 7, 0, Math.PI * 2);
    ctx.fill();
    if (!drawImage(images.core, 0, 0, 285, 285)) {
        ctx.fillStyle = '#5f4430';
        ctx.beginPath();
        ctx.arc(0, 0, 100, 0, Math.PI * 2);
        ctx.fill();
    }
    ctx.restore();
}

function drawBuildings() {
    for (const building of state.buildings) {
        if (!isWorldPointVisible(building.x, building.y, 260)) continue;
        const isBuildingCabin = isCabin(building.type);
        const level = building.level || 1;
        const stats = isBuildingCabin ? getCabinStats(building.type, level) : null;
        const upgradeCost = isBuildingCabin ? cabinUpgradeCost(building) : null;
        const isUpgradeRange = isBuildingCabin && distance(building, state.player) <= CABIN_UPGRADE_RANGE;
        ctx.fillStyle = 'rgba(0,0,0,.35)';
        ctx.beginPath();
        ctx.ellipse(building.x, building.y + building.radius * 0.45, building.radius, building.radius * 0.35, 0, 0, Math.PI * 2);
        ctx.fill();
        const barricadeHealth = building.hp / building.maxHp;
        const image = state.map === 'lycee'
            ? building.type === 'barricade'
                ? images.lyceeBins
                : building.type === 'treehouse'
                    ? images.lyceeNeighbor
                    : building.type === 'medicShack'
                        ? images.lyceeInfirmary
                        : building.type === 'guardShack'
                            ? images.lyceeClassroom
                            : images.lyceeCdi
            : building.type === 'barricade'
                ? barricadeHealth <= 0.28 ? images.barricadeRuined : barricadeHealth <= 0.62 ? images.barricadeWorn : images.barricade
                : building.type === 'treehouse'
                    ? images.treehouse
                    : building.type === 'medicShack'
                        ? images.medicCabin
                        : images.shack;
        const size = state.map === 'lycee'
            ? building.type === 'barricade' ? [245, 112] : building.type === 'treehouse' ? [200, 250] : [230, 208]
            : building.type === 'barricade' ? [175, 145] : building.type === 'treehouse' ? [245, 278] : [225, 215];
        drawImage(image, building.x, building.y, size[0], size[1]);
        if (building.type === 'treehouse') {
            ctx.save();
            ctx.globalAlpha = 0.12;
            ctx.fillStyle = '#8ff0b0';
            ctx.beginPath();
            ctx.arc(building.x, building.y, stats.range, 0, Math.PI * 2);
            ctx.fill();
            ctx.globalAlpha = 0.5;
            ctx.strokeStyle = '#8ff0b0';
            ctx.setLineDash([14, 14]);
            ctx.lineWidth = 3;
            ctx.stroke();
            ctx.setLineDash([]);
            ctx.restore();
        }
        ctx.textAlign = 'center';
        if (isBuildingCabin) {
            ctx.font = '900 12px Orbitron';
            ctx.fillStyle = level >= CABIN_MAX_LEVEL ? '#8ff0b0' : '#ffe16b';
            ctx.fillText(`NIV. ${level} / ${CABIN_MAX_LEVEL}`, building.x, building.y - building.radius - 28);
        }
        if (building.type === 'shack') {
            const limit = stats.workers;
            ctx.font = '800 12px Inter';
            ctx.fillStyle = '#ffd0a0';
            ctx.fillText(`COLLECTEURS ${building.workerCount || 0}/${limit}`, building.x, building.y + building.radius + 29);
            if ((building.workerCount || 0) < limit) {
                ctx.fillStyle = 'rgba(16,20,20,.22)';
                ctx.fillRect(building.x - 38, building.y + building.radius + 36, 76, 4);
                ctx.fillStyle = '#ef944d';
                ctx.fillRect(building.x - 38, building.y + building.radius + 36, 76 * Math.min(1, (building.recruitTimer || 0) / stats.recruitTime), 5);
            }
        }
        if (building.type === 'guardShack') {
            const limit = stats.guards;
            ctx.font = '800 12px Inter';
            ctx.fillStyle = '#f4d88b';
            ctx.fillText(`GUERRIERS ${building.guardCount || 0}/${limit}`, building.x, building.y + building.radius + 29);
            if ((building.guardCount || 0) < limit) {
                ctx.fillStyle = 'rgba(16,20,20,.22)';
                ctx.fillRect(building.x - 38, building.y + building.radius + 36, 76, 4);
                ctx.fillStyle = '#f4b942';
                ctx.fillRect(building.x - 38, building.y + building.radius + 36, 76 * Math.min(1, (building.recruitTimer || 0) / stats.recruitTime), 5);
            }
        }
        if (building.type === 'medicShack') {
            const limit = stats.medics;
            ctx.font = '800 12px Inter';
            ctx.fillStyle = '#f4f1d0';
            ctx.fillText(`MÉDECINS ${building.medicCount || 0}/${limit}`, building.x, building.y + building.radius + 29);
            if ((building.medicCount || 0) < limit) {
                ctx.fillStyle = 'rgba(16,20,20,.22)';
                ctx.fillRect(building.x - 38, building.y + building.radius + 36, 76, 4);
                ctx.fillStyle = '#f4f1d0';
                ctx.fillRect(building.x - 38, building.y + building.radius + 36, 76 * Math.min(1, (building.recruitTimer || 0) / stats.recruitTime), 5);
            }
        }
        if (building.type === 'treehouse') {
            ctx.font = '800 12px Inter';
            ctx.fillStyle = '#b8f0da';
            ctx.fillText(`TOUR · PORTÉE ${Math.round(stats.range)}`, building.x, building.y + building.radius + 29);
        }
        if (isUpgradeRange) {
            ctx.font = '700 10px Inter';
            ctx.fillStyle = upgradeCost ? '#fff0a8' : '#8ff0b0';
            ctx.fillText(upgradeCost ? `U · AMÉLIORER · ${formatCost(upgradeCost)}` : 'NIVEAU MAXIMUM', building.x, building.y + building.radius + 49);
        }
        const nearbyRepairer = state.players.find((player) => player.hp > 0 && distance(building, player) <= repairRange);
        if ((building.type === 'barricade' || isBuildingCabin) && building.hp < building.maxHp && nearbyRepairer) {
            const repairingPlayer = state.players.find((player) => player.repairTarget === building && player.repairProgress > 0);
            const repairing = Boolean(repairingPlayer);
            const blockedPlayer = state.players.find((player) => player.repairBlocked && distance(building, player) <= repairRange);
            ctx.save();
            ctx.textAlign = 'center';
            ctx.font = '800 13px Inter';
            ctx.fillStyle = repairing ? '#fff4cf' : blockedPlayer ? '#ffb19a' : '#fff4cf';
            ctx.fillText(
                repairing ? `${repairingPlayer.label} · RÉPARATION EN COURS` : blockedPlayer ? `${blockedPlayer.label} · RELÂCHEZ POUR REPRENDRE` : `${nearbyRepairer.label} · ${nearbyRepairer.gamepad ? 'R1' : ['E', 'ENTRÉE', 'O', '0'][nearbyRepairer.id]} · RÉPARER GRATUITEMENT`,
                building.x,
                building.y - building.radius - 29
            );
            if (repairingPlayer) {
                ctx.fillStyle = 'rgba(16,20,20,.22)';
                ctx.fillRect(building.x - 58, building.y - building.radius - 20, 116, 5);
                ctx.fillStyle = repairingPlayer.color;
                ctx.fillRect(building.x - 58, building.y - building.radius - 20, 116 * Math.min(1, repairingPlayer.repairProgress / repairDuration), 8);
            }
            ctx.restore();
        }
    }
}

function drawPlayer() {
    for (const player of state.players) {
        ctx.save();
        ctx.globalAlpha = player.hp > 0 ? 1 : 0.38;
        ctx.fillStyle = 'rgba(0,0,0,.45)';
        ctx.beginPath();
        ctx.ellipse(player.x, player.y + 25, 32, 14, 0, 0, Math.PI * 2);
        ctx.fill();
        const playerSkin = images[`player${player.id + 1}`] || images.player;
        if (!drawImage(playerSkin, player.x, player.y - 8, 78, 165)) {
            ctx.fillStyle = player.color;
            ctx.beginPath();
            ctx.arc(player.x, player.y, 28, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.strokeStyle = player.color;
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.arc(player.x, player.y, 34, 0, Math.PI * 2);
        ctx.stroke();
        ctx.fillStyle = '#101414';
        ctx.fillRect(player.x - 35, player.y - 58, 70, 6);
        ctx.fillStyle = player.stun > 0 ? '#f7f5dc' : player.color;
        ctx.fillRect(player.x - 35, player.y - 58, 70 * Math.max(0, player.hp / player.maxHp), 6);
        ctx.textAlign = 'center';
        ctx.font = '900 12px Orbitron';
        ctx.fillStyle = player.color;
        ctx.fillText(`J${player.id + 1}`, player.x, player.y - 70);
        if (player.downed) {
            const arrowY = player.y - 122;
            const pulse = 1 + Math.sin(state.time * 6) * 0.08;
            ctx.save();
            ctx.globalAlpha = 0.95;
            ctx.fillStyle = '#ff2f3f';
            ctx.shadowColor = '#7a0008';
            ctx.shadowBlur = 0;
            ctx.beginPath();
            ctx.moveTo(player.x, arrowY + 22 * pulse);
            ctx.lineTo(player.x - 13 * pulse, arrowY);
            ctx.lineTo(player.x + 13 * pulse, arrowY);
            ctx.closePath();
            ctx.fill();
            ctx.restore();
            ctx.font = '900 11px Orbitron';
            ctx.fillStyle = '#ff7770';
            ctx.fillText(`À TERRE · ${Math.ceil(player.downedTimer)} s`, player.x, player.y - 84);
            const reviver = state.players.find((candidate) => candidate.hp > 0 && distance(candidate, player) <= PLAYER_REVIVE_RANGE);
            const rescuer = state.players.find((candidate) => candidate.reviveTarget === player && candidate.reviveProgress > 0);
            if (rescuer) {
                ctx.font = '800 11px Inter';
                ctx.fillStyle = '#fff4cf';
                ctx.fillText(`${rescuer.label} · RÉANIMATION`, player.x, player.y + 60);
                ctx.fillStyle = '#101414';
                ctx.fillRect(player.x - 48, player.y + 66, 96, 7);
                ctx.fillStyle = rescuer.color;
                ctx.fillRect(player.x - 48, player.y + 66, 96 * Math.min(1, rescuer.reviveProgress / PLAYER_REVIVE_DURATION), 7);
            } else if (reviver) {
                const key = reviver.gamepad ? 'R1' : ['E', 'ENTRÉE', 'O', '0'][reviver.id];
                ctx.font = '800 11px Inter';
                ctx.fillStyle = '#fff4cf';
                ctx.fillText(`${key} · MAINTENIR POUR RÉANIMER`, player.x, player.y + 60);
            }
        } else if (player.stun > 0 || player.slow > 0 || player.marked > 0) {
            ctx.font = '900 10px Inter';
            ctx.fillStyle = player.stun > 0 ? '#fff2b0' : player.marked > 0 ? '#ff6262' : '#d8ef8a';
            ctx.fillText(player.stun > 0 ? 'ÉTOURDI·E' : player.marked > 0 ? 'REPÉRÉ·E' : 'RALENTI·E', player.x, player.y - 82);
        }
        if (player.hp > 0) {
            const aimX = playerUsesPointerAim(player) ? input.mouseX - player.x : player.facingX;
            const aimY = playerUsesPointerAim(player) ? input.mouseY - player.y : player.facingY;
            const angle = Math.atan2(aimY, aimX);
            ctx.strokeStyle = player.color;
            ctx.globalAlpha *= 0.72;
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(player.x, player.y);
            ctx.lineTo(player.x + Math.cos(angle) * 52, player.y + Math.sin(angle) * 52);
            ctx.stroke();
        }
        ctx.restore();
    }
}

function drawEggs() {
    if (!state.eggs || !state.eggs.length) return;
    const eggImg = images.oeuf;
    for (const egg of state.eggs) {
        if (!isWorldPointVisible(egg.x, egg.y, 80)) continue;
        // Ombre
        ctx.fillStyle = 'rgba(0,0,0,.3)';
        ctx.beginPath();
        ctx.ellipse(egg.x, egg.y + 18, 18, 8, 0, 0, Math.PI * 2);
        ctx.fill();
        // Œuf (pulse légèrement pendant l'incubation)
        const pulse = 1 + Math.sin(state.time * 8) * 0.06 * (1 - egg.hatchTimer);
        const size = 48 * pulse;
        if (eggImg) {
            drawImage(eggImg, egg.x, egg.y - 8, size, size * 1.15, 0.95);
        } else {
            ctx.fillStyle = '#4a9eff';
            ctx.beginPath();
            ctx.ellipse(egg.x, egg.y, 20, 26, 0, 0, Math.PI * 2);
            ctx.fill();
        }
        // Barre d'éclosion
        const progress = 1 - Math.max(0, egg.hatchTimer);
        ctx.fillStyle = 'rgba(0,0,0,.4)';
        ctx.fillRect(egg.x - 22, egg.y + 28, 44, 5);
        ctx.fillStyle = '#4a9eff';
        ctx.fillRect(egg.x - 22, egg.y + 28, 44 * progress, 5);
    }
}

const enemyVisuals = {
    officer: { image: 'officer', width: 104, height: 132, offset: 10 },
    shield_crs: { image: 'riotOfficer', width: 126, height: 185, offset: 20 },
    flashball: { image: 'flashball', width: 104, height: 150, offset: 15 },
    water_cannon: { image: 'waterCannon', width: 250, height: 190, offset: 8 },
    infiltrator: { image: 'infiltrator', width: 100, height: 142, offset: 12 },
    bac: { image: 'bac', width: 104, height: 150, offset: 16 },
    canine: { image: 'dogHandler', width: 104, height: 155, offset: 16 },
    dog: { image: 'dog', width: 116, height: 150, offset: 14 },
    moto: { image: 'moto', width: 170, height: 154, offset: 12 },
    quad: { image: 'quad', width: 164, height: 146, offset: 10 },
    drone: { image: 'drone', width: 170, height: 105, offset: 48 },
    megaphone: { image: 'megaphone', width: 104, height: 152, offset: 15 },
    sniper: { image: 'sniper', width: 112, height: 158, offset: 15 },
    demineur: { image: 'demineur', width: 132, height: 148, offset: 13 },
    flamethrower: { image: 'flamethrower', width: 124, height: 164, offset: 18 },
    van: { image: 'van', width: 175, height: 145, offset: 0 },
    bonusVan: { image: 'bonusVan', width: 195, height: 164, offset: 0 },
    tank: { image: 'tank', width: 205, height: 185, offset: 0 },
    helicopter: { image: 'helicopter', width: 215, height: 155, offset: 42 },
    macron: { image: 'macron', width: 140, height: 180, offset: 18 },
    grenadier: { image: 'grenadier', width: 110, height: 155, offset: 14 }
};

function drawEnemies() {
    const specialColors = {
        shield_crs: '#dce9f0', flashball: '#ffdd76', water_cannon: '#8ad9ff', infiltrator: '#f0b27a',
        bac: '#e28a67', canine: '#c99362', dog: '#a98255', moto: '#e95b52', quad: '#ff654f',
        drone: '#f4d45f', megaphone: '#bb8cff', sniper: '#ff3f4e', demineur: '#e7e7ee', flamethrower: '#ff7137', bonusVan: '#8ad9ff',
        macron: '#ffd700', grenadier: '#ff8c42'
    };
    const left = camera.x - ENEMY_DRAW_MARGIN;
    const right = camera.x + W / camera.zoom + ENEMY_DRAW_MARGIN;
    const top = camera.y - ENEMY_DRAW_MARGIN;
    const bottom = camera.y + H / camera.zoom + ENEMY_DRAW_MARGIN;
    const crowd = state.enemies.length;
    const lightFx = crowd > CROWD_LIGHT_FX_LIMIT;
    // Caméra centrée : on priorise les barres de vie proches du joueur.
    const camCX = camera.x + (W / camera.zoom) * 0.5;
    const camCY = camera.y + (H / camera.zoom) * 0.5;
    const nearHpR2 = lightFx ? 520 * 520 : Infinity;
    for (const enemy of state.enemies) {
        if (enemy.x < left || enemy.x > right || enemy.y < top || enemy.y > bottom) continue;
        const hiddenInfiltrator = enemy.infiltrator && !enemy.revealed;
        const visual = enemyVisuals[enemy.type] || enemyVisuals.officer;
        const enemyImage = images[visual.image];
        const alpha = hiddenInfiltrator ? 0.22 : enemy.flash > 0 ? 0.35 : 1;
        // Toujours le sprite (plus de points gris en grosse foule).
        // On drop seulement l'ombre ellipse, trop chère en masse.
        if (!lightFx || enemy.type !== 'officer') {
            ctx.fillStyle = 'rgba(0,0,0,.35)';
            ctx.beginPath();
            ctx.ellipse(enemy.x, enemy.y + (enemy.air ? 8 : 24), enemy.radius, enemy.radius * 0.43, 0, 0, Math.PI * 2);
            ctx.fill();
        }
        drawImage(enemyImage, enemy.x, enemy.y - visual.offset, visual.width, visual.height, alpha);
        const color = specialColors[enemy.type] || (enemy.type === 'helicopter' ? '#f4b942' : '#ff6454');
        const isSpecial = enemy.type !== 'officer';
        if (enemy.bonusVan) {
            ctx.save();
            ctx.globalAlpha = 0.55 + Math.sin(state.time * 6) * 0.2;
            ctx.strokeStyle = '#8ad9ff';
            ctx.lineWidth = 6;
            ctx.setLineDash([16, 10]);
            ctx.beginPath();
            ctx.arc(enemy.x, enemy.y, enemy.radius + 24 + Math.sin(state.time * 5) * 5, 0, Math.PI * 2);
            ctx.stroke();
            ctx.setLineDash([]);
            ctx.restore();
        }
        if (enemy.type === 'shield_crs') {
            ctx.save();
            ctx.translate(enemy.x, enemy.y);
            ctx.rotate(Math.atan2(enemy.facingY, enemy.facingX));
            ctx.strokeStyle = enemy.guardDown > 0 ? '#ffb36c' : '#e4f1f7';
            ctx.lineWidth = 8;
            ctx.beginPath();
            ctx.arc(0, 0, enemy.radius + 10, -Math.PI * 0.72, Math.PI * 0.72);
            ctx.stroke();
            ctx.restore();
        }
        // Anneau de soutien : seulement hors grosse foule (FX secondaire).
        if (enemy.supported && !lightFx) {
            ctx.strokeStyle = '#bf91ff99';
            ctx.lineWidth = 5;
            ctx.setLineDash([9, 8]);
            ctx.beginPath();
            ctx.arc(enemy.x, enemy.y, enemy.radius + 13 + Math.sin(state.time * 5) * 2, 0, Math.PI * 2);
            ctx.stroke();
            ctx.setLineDash([]);
        }
        const markedPlayer = enemy.nearestPlayer || null;
        if (enemy.drone && markedPlayer?.marked > 0) {
            ctx.fillStyle = 'rgba(255,244,147,.12)';
            ctx.beginPath();
            ctx.moveTo(enemy.x, enemy.y + 12);
            ctx.lineTo(markedPlayer.x - 100, markedPlayer.y + 80);
            ctx.lineTo(markedPlayer.x + 100, markedPlayer.y + 80);
            ctx.closePath();
            ctx.fill();
        }
        if (enemy.sniper && enemy.aimTime > 0 && enemy.aimTarget) {
            ctx.strokeStyle = '#ff334f';
            ctx.globalAlpha = Math.min(1, enemy.aimTime / 3);
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(enemy.x, enemy.y);
            ctx.lineTo(enemy.aimTarget.x, enemy.aimTarget.y);
            ctx.stroke();
            ctx.globalAlpha = 1;
        }
        // Barres de vie : toujours pour les spéciaux / boss ; pour les flics de base
        // seulement s'ils sont proches du centre caméra en grosse foule.
        const showHp = isSpecial || enemy.boss || !lightFx ||
            ((enemy.x - camCX) * (enemy.x - camCX) + (enemy.y - camCY) * (enemy.y - camCY) < nearHpR2);
        if (showHp) {
            ctx.fillStyle = '#101414';
            ctx.fillRect(enemy.x - enemy.radius, enemy.y - enemy.radius - 18, enemy.radius * 2, 7);
            ctx.fillStyle = color;
            ctx.fillRect(enemy.x - enemy.radius, enemy.y - enemy.radius - 18, enemy.radius * 2 * Math.max(0, enemy.hp / enemy.maxHp), 7);
        }
        const label = SPECIAL_ENEMY_LABELS[enemy.type];
        if (label && (!hiddenInfiltrator || enemy.revealed) && (enemy.nearestPlayerDistance < 780 || enemy.boss || enemy.bonusVan)) {
            ctx.textAlign = 'center';
            ctx.font = enemy.boss ? '900 16px Orbitron' : '800 11px Inter';
            ctx.fillStyle = color;
            ctx.fillText(label, enemy.x, enemy.y - enemy.radius - 25);
        }
    }
}

function drawWorkers() {
    for (const worker of state.workers) {
        if (!isWorldPointVisible(worker.x, worker.y, 120)) continue;
        ctx.fillStyle = 'rgba(0,0,0,.3)';
        ctx.beginPath();
        ctx.ellipse(worker.x, worker.y + 19, 21, 9, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.save();
        ctx.globalAlpha = worker.flash > 0 ? 0.4 : 1;
        const workerSprite = state.map === 'lycee' ? images.lyceeCollector : images.player;
        drawImage(workerSprite, worker.x, worker.y - 8, state.map === 'lycee' ? 52 : 66, 88);
        ctx.restore();
        ctx.strokeStyle = worker.carryType ? '#f4b942' : '#ef944d';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(worker.x, worker.y, worker.radius + 5, 0, Math.PI * 2);
        ctx.stroke();
        if (worker.carryType) {
            ctx.fillStyle = resourceInfo[worker.carryType]?.color || '#f4b942';
            ctx.beginPath();
            ctx.arc(worker.x + 18, worker.y - 18, 7, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.fillStyle = '#101414';
        ctx.fillRect(worker.x - 24, worker.y - 46, 48, 5);
        ctx.fillStyle = worker.stun > 0 ? '#f7f5dc' : '#ef944d';
        ctx.fillRect(worker.x - 24, worker.y - 46, 48 * Math.max(0, worker.hp / worker.maxHp), 5);
        if (nearestPlayerDistance(worker) < 720) {
            ctx.textAlign = 'center';
            ctx.font = '800 10px Inter';
            ctx.fillStyle = worker.carryType ? '#ffe29a' : '#ffd0a0';
            ctx.fillText(worker.carryType ? `COLLECTEUR · ${resourceInfo[worker.carryType].short}` : 'COLLECTEUR', worker.x, worker.y - 55);
        }
    }
}

function drawMedics() {
    for (const medic of state.medics) {
        const healing = medic.target && distance(medic, medic.target) <= medic.radius + medic.target.radius + 24;
        ctx.fillStyle = 'rgba(0,0,0,.3)';
        ctx.beginPath();
        ctx.ellipse(medic.x, medic.y + 21, 22, 9, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.save();
        ctx.globalAlpha = medic.flash > 0 ? 0.4 : 1;
        drawImage(images.medic, medic.x, medic.y - 9, 72, 112);
        ctx.restore();
        ctx.strokeStyle = healing ? '#8ff0b0' : '#f4f1d0';
        ctx.lineWidth = healing ? 4 : 3;
        ctx.beginPath();
        ctx.arc(medic.x, medic.y, medic.radius + 5 + (healing ? Math.sin(state.time * 9) * 2 : 0), 0, Math.PI * 2);
        ctx.stroke();
        ctx.fillStyle = '#101414';
        ctx.fillRect(medic.x - 25, medic.y - 50, 50, 5);
        ctx.fillStyle = medic.stun > 0 ? '#f7f5dc' : '#f4f1d0';
        ctx.fillRect(medic.x - 25, medic.y - 50, 50 * Math.max(0, medic.hp / medic.maxHp), 5);
        ctx.textAlign = 'center';
        ctx.font = '800 11px Inter';
        ctx.fillStyle = '#fff9df';
        ctx.fillText('MÉDECIN', medic.x, medic.y - 62);
        if (healing) {
            ctx.font = '900 12px Orbitron';
            ctx.fillStyle = '#8ff0b0';
            ctx.fillText('+ SOINS', medic.x, medic.y - 78);
        }
    }
}

function drawAllies() {
    for (const ally of state.allies) {
        if (!isWorldPointVisible(ally.x, ally.y, 140)) continue;
        ctx.fillStyle = 'rgba(0,0,0,.3)';
        ctx.beginPath();
        ctx.ellipse(ally.x, ally.y + 19, 21, 9, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.save();
        ctx.globalAlpha = ally.flash > 0 ? 0.4 : 1;
        // Même format que les collecteurs (66×88), skin guerrier dédié
        const allySprite = state.map === 'lycee'
            ? images.lyceeWarrior
            : (images.warrior?.complete ? images.warrior : images.player);
        const allyWidth = state.map === 'lycee' ? 52 : 66;
        const allyHeight = state.map === 'lycee' ? 88 : 88;
        drawImage(allySprite, ally.x, ally.y - 8, allyWidth, allyHeight);
        ctx.restore();
        ctx.strokeStyle = ally.veteran ? '#f4b942' : '#72b9a2';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(ally.x, ally.y, ally.radius + 5, 0, Math.PI * 2);
        ctx.stroke();
        ctx.fillStyle = '#101414';
        ctx.fillRect(ally.x - 24, ally.y - 46, 48, 5);
        ctx.fillStyle = ally.veteran ? '#f4b942' : '#72b9a2';
        ctx.fillRect(ally.x - 24, ally.y - 46, 48 * Math.max(0, ally.hp / ally.maxHp), 5);
        ctx.textAlign = 'center';
        ctx.font = '800 11px Inter';
        ctx.fillStyle = ally.veteran ? '#ffe29a' : '#b8f0da';
        ctx.fillText(ally.home?.type === 'guardShack' ? 'GUERRIER' : 'ALLIÉ', ally.x, ally.y - 56);
    }
}

function drawProjectiles() {
    for (const projectile of state.projectiles) {
        if (projectile.melee) {
            ctx.save();
            ctx.translate(projectile.x, projectile.y);
            ctx.rotate(projectile.angle || 0);
            ctx.lineCap = 'round';
            ctx.strokeStyle = '#172426';
            ctx.lineWidth = 20;
            ctx.beginPath();
            ctx.moveTo(-50, 0);
            ctx.lineTo(50, 0);
            ctx.stroke();
            ctx.strokeStyle = '#b9c8c7';
            ctx.lineWidth = 13;
            ctx.beginPath();
            ctx.moveTo(-50, 0);
            ctx.lineTo(50, 0);
            ctx.stroke();
            ctx.strokeStyle = '#eef6e8';
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(-40, -3);
            ctx.lineTo(40, -3);
            ctx.stroke();
            ctx.fillStyle = '#637779';
            ctx.beginPath();
            ctx.arc(-50, 0, 10, 0, Math.PI * 2);
            ctx.arc(50, 0, 10, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
            continue;
        }
        if (projectile.firework) {
            ctx.strokeStyle = '#ffb5dc';
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(projectile.x, projectile.y);
            ctx.lineTo(projectile.x - projectile.vx * 0.025, projectile.y - projectile.vy * 0.025);
            ctx.stroke();
            ctx.fillStyle = projectile.color;
            ctx.beginPath();
            ctx.arc(projectile.x, projectile.y, projectile.radius, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#ffe27a';
            ctx.beginPath();
            ctx.arc(projectile.x, projectile.y, 4, 0, Math.PI * 2);
            ctx.fill();
            continue;
        }
        if (projectile.grenadeF4) {
            // Grenade F4 : clignote de plus en plus vite avant l'explosion (fuse 3 s).
            const fuseRatio = Math.max(0, projectile.fuse / F4_GRENADE_FUSE);
            const blinkSpeed = 4 + (1 - fuseRatio) * 14;
            const blink = 0.45 + 0.55 * (0.5 + 0.5 * Math.sin(state.time * blinkSpeed * Math.PI * 2));
            const danger = 1 - fuseRatio;
            ctx.save();
            // Ombre au sol (point d'impact prévu)
            ctx.globalAlpha = 0.35 + danger * 0.25;
            ctx.fillStyle = '#000';
            ctx.beginPath();
            ctx.ellipse(projectile.targetX, projectile.targetY + 8, 22 + danger * 18, 10 + danger * 6, 0, 0, Math.PI * 2);
            ctx.fill();
            // Cercle d'avertissement qui pulse
            ctx.globalAlpha = 0.25 + danger * 0.45 * blink;
            ctx.strokeStyle = danger > 0.55 ? '#ff3b2f' : '#ff9a3c';
            ctx.lineWidth = 3 + danger * 4;
            ctx.beginPath();
            ctx.arc(projectile.targetX, projectile.targetY, F4_GRENADE_RADIUS * (0.35 + danger * 0.55), 0, Math.PI * 2);
            ctx.stroke();
            // Corps de la grenade en vol
            ctx.globalAlpha = 0.85 + blink * 0.15;
            ctx.fillStyle = danger > 0.6 ? `rgba(255, ${Math.floor(60 + 80 * blink)}, 40, 1)` : '#ff6b45';
            ctx.beginPath();
            ctx.arc(projectile.x, projectile.y, projectile.radius + 2 * blink, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#ffe27a';
            ctx.beginPath();
            ctx.arc(projectile.x - 3, projectile.y - 3, 3.5, 0, Math.PI * 2);
            ctx.fill();
            // Petite flamme / détonateur qui clignote
            if (blink > 0.7) {
                ctx.fillStyle = '#fff';
                ctx.beginPath();
                ctx.arc(projectile.x + 5, projectile.y - 6, 2.5, 0, Math.PI * 2);
                ctx.fill();
            }
            ctx.restore();
            continue;
        }
        ctx.strokeStyle = 'rgba(255,236,196,.35)';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(projectile.x, projectile.y);
        ctx.lineTo(projectile.x - projectile.vx * 0.025, projectile.y - projectile.vy * 0.025);
        ctx.stroke();
        ctx.fillStyle = projectile.color || '#e0dccb';
        ctx.beginPath();
        ctx.arc(projectile.x, projectile.y, projectile.radius, 0, Math.PI * 2);
        ctx.fill();
    }
}

function drawParticles() {
    for (const particle of state.particles) {
        ctx.globalAlpha = Math.max(0, particle.life / particle.maxLife);
        ctx.fillStyle = particle.color;
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fill();
    }
    ctx.globalAlpha = 1;
    ctx.textAlign = 'center';
    ctx.font = '800 16px Orbitron';
    for (const floater of state.floaters) {
        ctx.globalAlpha = Math.max(0, floater.life);
        ctx.fillStyle = '#f4d88b';
        ctx.fillText(floater.text, floater.x, floater.y);
    }
    ctx.globalAlpha = 1;
}

function drawBuildGhost() {
    if (!running) return;
    for (const player of state.players) {
        const type = player.selectedBuild;
        if (!type || player.hp <= 0) continue;
        const target = getBuildTarget(player);
        const { x, y } = target;
        const reason = !canAfford(type, player)
            ? `MANQUE ${Object.entries(buildingCost(type)).filter(([key, amount]) => player.inventory[key] < amount).map(([key]) => resourceInfo[key]?.label || key).join(' + ')}`
            : placementBlockReason(x, y, type, player);
        const valid = !reason;
        const radius = buildingRadius(type);
        ctx.strokeStyle = '#ff3b3b';
        ctx.fillStyle = valid ? 'rgba(255,59,59,.10)' : 'rgba(255,59,59,.14)';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        const image = state.map === 'lycee'
            ? type === 'barricade'
                ? images.lyceeBins
                : type === 'treehouse'
                    ? images.lyceeNeighbor
                    : type === 'medicShack'
                        ? images.lyceeInfirmary
                        : type === 'guardShack'
                            ? images.lyceeClassroom
                            : images.lyceeCdi
            : type === 'barricade'
                ? images.barricade
                : type === 'treehouse'
                    ? images.treehouse
                    : type === 'medicShack'
                        ? images.medicCabin
                        : images.shack;
        const size = state.map === 'lycee'
            ? type === 'barricade' ? [245, 112] : type === 'treehouse' ? [200, 250] : [230, 208]
            : type === 'barricade' ? [175, 145] : type === 'treehouse' ? [245, 278] : [225, 215];
        drawImage(image, x, y, size[0], size[1], valid ? 0.48 : 0.24);

        const placeControl = player.gamepad ? 'STICK DROIT · CROIX POSER · ROND ANNULER' : player.id === 0 ? 'CLIC / ESPACE POUR PLACER' : 'TIRER POUR PLACER';
        const label = `J${player.id + 1} · ${valid ? placeControl : reason}`;
        const cost = `COÛT · ${formatCost(buildingCost(type)).toUpperCase()}`;
        const targetDistance = `DISTANCE JOUEUR · ${Math.round(distance(player, target))} / 330`;
        ctx.save();
        ctx.textAlign = 'center';
        ctx.font = '900 12px Orbitron';
        const labelWidth = ctx.measureText(label).width;
        ctx.font = '800 11px Inter';
        const costWidth = ctx.measureText(cost).width;
        const rangeWidth = ctx.measureText(targetDistance).width;
        const panelWidth = Math.max(labelWidth, costWidth, rangeWidth) + 22;
        const panelY = y + radius + 5;
        ctx.fillStyle = 'rgba(6,20,18,.16)';
        ctx.fillRect(x - panelWidth / 2, panelY, panelWidth, 55);
        ctx.fillStyle = '#ff5a5a';
        ctx.font = '900 12px Orbitron';
        ctx.fillText(label, x, panelY + 14);
        ctx.fillStyle = '#fffbe0';
        ctx.font = '800 11px Inter';
        ctx.fillText(cost, x, panelY + 31);
        ctx.fillStyle = '#b9cec7';
        ctx.fillText(targetDistance, x, panelY + 47);
        ctx.restore();
    }
}

function drawCursor() {
    if (!input.pointerInside || state.player.gamepad) return;
    const x = input.screenMouseX;
    const y = input.screenMouseY;
    const isBuildMode = Boolean(state.selectedBuild);
    const isValid = isBuildMode && validPlacement(input.mouseX, input.mouseY, state.selectedBuild) && canAfford(state.selectedBuild);
    const color = isBuildMode ? (isValid ? '#82f0b5' : '#ff6b62') : '#ffe16b';
    const pulse = 1 + Math.sin(performance.now() * 0.008) * 0.08;
    const outerRadius = 34 * pulse;
    const crosshairPath = () => {
        ctx.beginPath();
        ctx.moveTo(-60, 0);
        ctx.lineTo(-38, 0);
        ctx.moveTo(38, 0);
        ctx.lineTo(60, 0);
        ctx.moveTo(0, -60);
        ctx.lineTo(0, -38);
        ctx.moveTo(0, 38);
        ctx.lineTo(0, 60);
        ctx.stroke();
    };
    ctx.save();
    ctx.translate(x, y);
    ctx.lineCap = 'round';
    ctx.shadowColor = '#061412';
    ctx.shadowBlur = 0;
    ctx.strokeStyle = '#061412';
    ctx.lineWidth = 13;
    ctx.beginPath();
    ctx.arc(0, 0, outerRadius, 0, Math.PI * 2);
    ctx.stroke();
    ctx.shadowBlur = 0;
    ctx.strokeStyle = '#fffbe0';
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.arc(0, 0, outerRadius, 0, Math.PI * 2);
    ctx.stroke();
    ctx.strokeStyle = color;
    ctx.lineWidth = 4;
    ctx.setLineDash([20, 11]);
    ctx.beginPath();
    ctx.arc(0, 0, outerRadius, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.strokeStyle = '#061412';
    ctx.lineWidth = 10;
    crosshairPath();
    ctx.strokeStyle = '#fffbe0';
    ctx.lineWidth = 6;
    crosshairPath();
    ctx.strokeStyle = color;
    ctx.lineWidth = 3;
    crosshairPath();
    ctx.fillStyle = '#061412';
    ctx.beginPath();
    ctx.arc(0, 0, 12, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(0, 0, 7, 0, Math.PI * 2);
    ctx.fill();
    if (isBuildMode) {
        ctx.font = '900 11px Inter';
        ctx.textAlign = 'center';
        ctx.fillStyle = '#061412';
        ctx.fillText(isValid ? 'PLACER' : 'BLOQUÉ', 0, 76);
    }
    ctx.restore();
}

function drawVignette() {
    // Vignette légère sans gradient (très coûteux en canvas 2D)
    ctx.fillStyle = 'rgba(10,86,55,0.10)';
    ctx.fillRect(0, 0, W, 48);
    ctx.fillRect(0, H - 48, W, 48);
    ctx.fillRect(0, 0, 48, H);
    ctx.fillRect(W - 48, 0, 48, H);
    const blindedPlayer = state.players.filter((player) => player.hp > 0 && player.blind > 0)
        .sort((a, b) => b.blind - a.blind)[0];
    if (blindedPlayer) {
        ctx.fillStyle = `rgba(255,255,245,${Math.min(0.92, blindedPlayer.blind / 3.5)})`;
        ctx.fillRect(0, 0, W, H);
        ctx.textAlign = 'center';
        ctx.font = '900 26px Orbitron';
        ctx.fillStyle = '#26383a';
        ctx.fillText(`FLASHBANG · ${blindedPlayer.label} ÉTOURDI·E`, W / 2, H / 2);
    } else if (state.players.some((player) => player.hp > 0 && player.slow > 0)) {
        ctx.fillStyle = 'rgba(174,220,101,.08)';
        ctx.fillRect(0, 0, W, H);
    }
}

function loop(now) {
    const dt = Math.min((now - lastTime) / 1000, 0.033);
    lastTime = now;
    if (state) state.lastFrameDt = dt;
    try {
        pollGamepads();
        update(dt);
        draw();
    } catch (err) {
        console.error('[BLOCUS] erreur frame:', err);
        showToast('ERREUR TECHNIQUE — VOIR CONSOLE (F12)');
    }
    requestAnimationFrame(loop);
}

// ─── Transport P2P WebRTC (jumelage manuel, sans serveur de jeu) ───
const p2p = { pc: null, channel: null };
let p2pRemote = document.querySelector('#p2p-remote');
let p2pLocal = document.querySelector('#p2p-local');
let p2pStatus = document.querySelector('#p2p-status');
function setP2PStatus(message) { if (p2pStatus) p2pStatus.textContent = `État : ${message}`; }
function waitIceGathering(pc) {
    if (pc.iceGatheringState === 'complete') return Promise.resolve();
    return new Promise(resolve => {
        const done = () => { if (pc.iceGatheringState === 'complete') { pc.removeEventListener('icegatheringstatechange', done); resolve(); } };
        pc.addEventListener('icegatheringstatechange', done);
        // Certains navigateurs ne terminent pas la collecte en réseau restreint : on libère le champ après 8 s.
        setTimeout(resolve, 8000);
    });
}
function createPeerConnection(isHost) {
    if (p2p.pc) { try { p2p.pc.close(); } catch {} }
    p2p.pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
    p2p.pc.onconnectionstatechange = () => setP2PStatus(`WebRTC ${p2p.pc.connectionState} · liaison directe, synchronisation du jeu non activée`);
    p2p.pc.ondatachannel = event => { p2p.channel = event.channel; setupP2PChannel(); };
    if (isHost) { p2p.channel = p2p.pc.createDataChannel('bocus-p2p', { ordered: true }); setupP2PChannel(); }
    return p2p.pc;
}
function setupP2PChannel() {
    if (!p2p.channel) return;
    p2p.channel.onopen = () => setP2PStatus('canal P2P direct connecté · les commandes et états de jeu ne sont pas encore synchronisés');
    p2p.channel.onclose = () => setP2PStatus('canal fermé');
    p2p.channel.onerror = () => setP2PStatus('erreur du canal P2P');
    p2p.channel.onmessage = event => {
        try {
            const msg = JSON.parse(event.data);
            if (msg?.type === 'ping') p2p.channel.send(JSON.stringify({ type: 'pong', at: msg.at }));
        } catch { /* Ignore les paquets de diagnostic invalides. */ }
    };
}
async function createP2POffer() {
    try {
        const pc = createPeerConnection(true);
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        setP2PStatus('préparation de l’invitation…');
        await waitIceGathering(pc);
        p2pLocal.value = JSON.stringify(pc.localDescription);
        setP2PStatus('invitation prête : envoie le code à l’invité, puis colle sa réponse dans le champ du haut');
    } catch (error) { setP2PStatus(`échec de création : ${error.message}`); }
}
async function createP2PAnswer() {
    try {
        const offer = JSON.parse(p2pRemote.value.trim());
        if (offer.type !== 'offer' || !offer.sdp) throw new Error('Le champ reçu ne contient pas une invitation valide.');
        const pc = createPeerConnection(false);
        await pc.setRemoteDescription(offer);
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        setP2PStatus('préparation de la réponse…');
        await waitIceGathering(pc);
        p2pLocal.value = JSON.stringify(pc.localDescription);
        setP2PStatus('réponse prête : renvoie le code à l’hôte et attends sa validation');
    } catch (error) { setP2PStatus(`échec de réponse : ${error.message}`); }
}
async function applyP2PAnswer() {
    try {
        if (!p2p.pc) throw new Error('Crée d’abord une invitation avec le bouton hôte.');
        const answer = JSON.parse(p2pRemote.value.trim());
        if (answer.type !== 'answer' || !answer.sdp) throw new Error('Le champ reçu ne contient pas une réponse valide.');
        await p2p.pc.setRemoteDescription(answer);
        setP2PStatus('réponse acceptée ; établissement du canal direct…');
    } catch (error) { setP2PStatus(`échec de validation : ${error.message}`); }
}
function attachP2PMenuListeners() {
    // Le menu est recréé via innerHTML : rafraîchir les références vers les nouveaux nœuds.
    p2pRemote = document.querySelector('#p2p-remote');
    p2pLocal = document.querySelector('#p2p-local');
    p2pStatus = document.querySelector('#p2p-status');
    document.querySelector('#p2p-create-offer')?.addEventListener('click', createP2POffer);
    document.querySelector('#p2p-create-answer')?.addEventListener('click', createP2PAnswer);
    document.querySelector('#p2p-apply-answer')?.addEventListener('click', applyP2PAnswer);
}
attachP2PMenuListeners();

resetGame();
requestAnimationFrame(loop);