const projectFiles = [
  'package.json',
  'electron/main.mjs',
  'README.md',
  'index.html',
  'main.js',
  'rosebud-game-defaults.css',
  'rosebud-game-defaults.js',
  'art_direction.md',
  'sound_direction.md',
  'download-project.html',
  'download-project.js',
  'assets/audio/makeshift-build.mp3',
  'assets/audio/night-resistance.mp3',
  'assets/audio/stone-impact.mp3',
  'assets/bac-interceptor.webp',
  'assets/brav-m-motorcycle.webp',
  'assets/camp-core.webp',
  'assets/camp-shack.webp',
  'assets/chatgpt-image-25-sept-2026-21_15_01.png',
  'assets/cute-bac-officer.webp',
  'assets/cute-barricade-ruined.webp',
  'assets/cute-barricade-worn.webp',
  'assets/cute-barricade.webp',
  'assets/cute-camp-core.webp',
  'assets/cute-camp-shack.webp',
  'assets/cute-officer.webp',
  'assets/cute-police-helicopter.webp',
  'assets/cute-police-tank.webp',
  'assets/cute-police-van.webp',
  'assets/cute-resource-crate.webp',
  'assets/cute-survivor.webp',
  'assets/cute-waste-pile.webp',
  'assets/field-medic.webp',
  'assets/grass-bright.webp',
  'assets/lycee-angry-neighbor.webp',
  'assets/lycee-bin-barricade.webp',
  'assets/lycee-cdi-building.webp',
  'assets/lycee-classroom-building.webp',
  'assets/lycee-infirmary-building.webp',
  'assets/lycee-school-gate.webp',
  'assets/lycee-warrior-blackbloc.webp',
  'assets/lycee-collector-supervisor.webp',
  'assets/lycee-street-ground.webp',
  'assets/lycee-street-map.webp',
  'assets/medic-cabin.webp',
  'assets/police-demineur.webp',
  'assets/police-dog-handler.webp',
  'assets/police-dog.webp',
  'assets/police-drone.webp',
  'assets/police-flamethrower.webp',
  'assets/police-flashball.webp',
  'assets/police-helicopter.webp',
  'assets/police-infiltrator.webp',
  'assets/police-megaphone.webp',
  'assets/police-quad.webp',
  'assets/police-sniper.webp',
  'assets/police-tank.webp',
  'assets/police-van.webp',
  'assets/resource-crate.webp',
  'assets/riot-officer.webp',
  'assets/river-current-tile.webp',
  'assets/river-wooden-footbridge.webp',
  'assets/scrap-barricade.webp',
  'assets/squatter-survivor.webp',
  'assets/terrain-night.webp',
  'assets/treehouse-watchtower.webp',
  'assets/waste-pile.webp',
  'assets/water-cannon-truck.webp',
];

const encoder = new TextEncoder();
const crcTable = new Uint32Array(256);
for (let n = 0; n < 256; n += 1) {
  let value = n;
  for (let bit = 0; bit < 8; bit += 1) {
    value = (value & 1) ? (0xedb88320 ^ (value >>> 1)) : (value >>> 1);
  }
  crcTable[n] = value >>> 0;
}

function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) crc = crcTable[(crc ^ byte) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

function dosDateTime(date) {
  const year = Math.max(1980, date.getFullYear());
  const time = (date.getHours() << 11) | (date.getMinutes() << 5) | Math.floor(date.getSeconds() / 2);
  const day = ((year - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate();
  return { time, day };
}

function makeHeader(size, writeFields) {
  const bytes = new Uint8Array(size);
  const view = new DataView(bytes.buffer);
  writeFields(view);
  return bytes;
}

function createZip(files) {
  const localParts = [];
  const centralParts = [];
  let localOffset = 0;
  const stamp = dosDateTime(new Date());

  for (const file of files) {
    const name = encoder.encode(file.name);
    const data = file.data;
    const checksum = crc32(data);
    const localHeader = makeHeader(30, (view) => {
      view.setUint32(0, 0x04034b50, true);
      view.setUint16(4, 20, true);
      view.setUint16(6, 0x0800, true);
      view.setUint16(8, 0, true);
      view.setUint16(10, stamp.time, true);
      view.setUint16(12, stamp.day, true);
      view.setUint32(14, checksum, true);
      view.setUint32(18, data.length, true);
      view.setUint32(22, data.length, true);
      view.setUint16(26, name.length, true);
      view.setUint16(28, 0, true);
    });
    localParts.push(localHeader, name, data);

    const centralHeader = makeHeader(46, (view) => {
      view.setUint32(0, 0x02014b50, true);
      view.setUint16(4, 20, true);
      view.setUint16(6, 20, true);
      view.setUint16(8, 0x0800, true);
      view.setUint16(10, 0, true);
      view.setUint16(12, stamp.time, true);
      view.setUint16(14, stamp.day, true);
      view.setUint32(16, checksum, true);
      view.setUint32(20, data.length, true);
      view.setUint32(24, data.length, true);
      view.setUint16(28, name.length, true);
      view.setUint16(30, 0, true);
      view.setUint16(32, 0, true);
      view.setUint16(34, 0, true);
      view.setUint16(36, 0, true);
      view.setUint32(38, 0, true);
      view.setUint32(42, localOffset, true);
    });
    centralParts.push(centralHeader, name);
    localOffset += localHeader.length + name.length + data.length;
  }

  const centralSize = centralParts.reduce((sum, part) => sum + part.length, 0);
  const endRecord = makeHeader(22, (view) => {
    view.setUint32(0, 0x06054b50, true);
    view.setUint16(4, 0, true);
    view.setUint16(6, 0, true);
    view.setUint16(8, files.length, true);
    view.setUint16(10, files.length, true);
    view.setUint32(12, centralSize, true);
    view.setUint32(16, localOffset, true);
    view.setUint16(20, 0, true);
  });
  return new Blob([...localParts, ...centralParts, endRecord], { type: 'application/zip' });
}

const button = document.querySelector('#download');
const status = document.querySelector('#status');

button.addEventListener('click', async () => {
  button.disabled = true;
  status.classList.remove('error');
  const zipFiles = [];
  const failures = [];
  try {
    for (let index = 0; index < projectFiles.length; index += 1) {
      const path = projectFiles[index];
      status.textContent = `Récupération des fichiers : ${index + 1}/${projectFiles.length} — ${path}`;
      try {
        const response = await fetch(`./${path}`, { cache: 'no-store' });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        zipFiles.push({ name: `Zone-Libre/${path}`, data: new Uint8Array(await response.arrayBuffer()) });
      } catch (error) {
        failures.push(`${path} (${error.message})`);
      }
    }

    if (failures.length) {
      throw new Error(`Certains fichiers n’ont pas pu être téléchargés :\n${failures.join('\n')}`);
    }

    const readme = [
      'ZONE LIBRE — ARCHIVE DU PROJET',
      '',
      'Le dossier assets contient les images et les sons utilisés par le jeu, dont les nouveaux courants bleus et ponts en bois de la carte Rivière, ainsi que les sprites exclusifs du Lycée.',
      'Conservez la structure du dossier et le dossier assets à la racine.',
      'Pour lancer le jeu dans une fenêtre Electron : installez Node.js 20+, ouvrez un terminal dans ce dossier, puis lancez npm install et npm start.',
      'Le jeu fonctionne avec ses fichiers locaux ; aucun serveur web ni étape de compilation ne sont nécessaires.',
    ].join('\n');
    zipFiles.push({ name: 'Zone-Libre/LISEZ-MOI.txt', data: encoder.encode(readme) });

    status.textContent = 'Création de l’archive ZIP…';
    const blob = createZip(zipFiles);
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'Zone-Libre-projet.zip';
    document.body.append(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
    status.textContent = `ZIP téléchargé : ${zipFiles.length} fichiers inclus.`;
  } catch (error) {
    status.classList.add('error');
    status.textContent = error.message;
  } finally {
    button.disabled = false;
  }
});
