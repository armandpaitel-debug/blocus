# BLOCUS

## Lancer le jeu avec Electron

Prérequis : **Node.js 20 ou supérieur** (npm est inclus avec Node.js).

Depuis la racine du dossier du projet, ouvrez un terminal puis exécutez :

```bash
npm install
npm start
```

`npm install` installe Electron ; `npm start` ouvre ensuite BLOCUS dans une fenêtre de bureau. Aucun serveur web, bundler ou étape de compilation n'est nécessaire. Le dossier `assets` doit rester à la racine, à côté de `index.html`.

La première installation nécessite une connexion Internet pour télécharger Electron. Une fois installé, le jeu et ses images/sons sont chargés depuis les fichiers locaux du projet.

## Commandes

- J1 : WASD / ZQSD, E pour interagir, clic ou Espace pour tirer/placer
- B, H, G, N et T : choisir une construction ; Échap : annuler
- Jusqu'à quatre joueurs en local avec claviers dédiés et manettes
- Le bouton ♪ active ou coupe le son

La version navigateur reste disponible en ouvrant `index.html` depuis un serveur web local.


## Refonte du menu BLOCUS
- `menu.css` : habillage responsive du menu et des écrans secondaires.
- `menu.js` : navigation entre titre, préparation, options, classement et connexion expérimentale.
- Le menu conserve les identifiants de jeu `#overlay`, `#start`, `.mode-card[data-map]`, `.mode-card[data-mode]`, `#local-ranking-list`, `#pause-overlay`, `#resume` et `#pause-main-menu`.
- Les options audio affichent des contrôles d’interface ; les volumes ne sont pas reliés au moteur audio dans cette livraison.
- Le P2P reste expérimental et ne synchronise pas les parties.
